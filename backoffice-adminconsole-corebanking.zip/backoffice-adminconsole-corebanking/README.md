# backoffice-adminconsole-corebanking
Repositorio dedicado al módulo administrativo de los clientes asociados a la solución "Core Banking"
