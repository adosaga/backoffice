$(document).ready(function () {
    var email = false;
    var natId = false;

    $('#email').keyup(function () {
        
        if($('#email').val()){
            
            email = true;
            if(email == true && natId == true){
                $('#next').removeAttr("disabled").removeClass("disabled");
            }
            
        }else{
            email = false;
            $('#next').attr("disabled",true).addClass("disabled");

        }  
    });

    $('#natId').keyup(function () {
        
        if($('#natId').val()){
            
            natId = true;
            if(email == true && natId == true){
                $('#next').removeAttr("disabled").removeClass("disabled");
            }
            
        }else{
            natId = false;
            $('#next').attr("disabled",true).addClass("disabled");

        }  
    });
});