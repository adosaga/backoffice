//Se utiliza para que el campo de texto solo acepte numeros
function SoloNumeros(evt){
    if(window.event){//asignamos el valor de la tecla a keynum
        keynum = evt.keyCode; //IE
    }
    else{
        keynum = evt.which; //FF
    }
    //comprobamos si se encuentra en el rango numérico y que teclas no recibirá.
    if((keynum > 47 && keynum < 58) || keynum == 8 || keynum == 13 || keynum == 6){
        return true;
    }
    else{
        return false;
    }
};

//Para eliminar la barra espaciadora
function sinespacios(evt){
    if(window.event){//asignamos el valor de la tecla a keynum
        keynum = evt.keyCode; //IE
    }
    else{
        keynum = evt.which; //FF
    }
    //comprobamos si se encuentra en el rango numérico y que teclas no recibirá.
    if( keynum == 32 ){
        return false;
    }
    else{
        return true;
    }
};

//Se utiliza para que el campo de texto solo acepte letras
function soloLetras(e) {
    key = e.keyCode || e.which;
    tecla = String.fromCharCode(key).toString();
    letras = " áéíóúabcdefghijklmnñopqrstuvwxyzÁÉÍÓÚABCDEFGHIJKLMNÑOPQRSTUVWXYZ";//Se define todo el abecedario que se quiere que se muestre.
    especiales = [8, 37, 39, 46, 6, 9]; //Es la validación del KeyCodes, que teclas recibe el campo de texto.

    tecla_especial = false
    for(var i in especiales) {
        if(key == especiales[i]) {
            tecla_especial = true;
            break;
        }else{
            tecla_especial = false;
            break;
        }
    }
    //key!=13 &&
    if(letras.indexOf(tecla) == -1 && !tecla_especial){
        return false;
    }
};

/*Para adquirir letras, números, espacios y dos caracteres especiales*/
function letrasnumeros(e) {
    key = e.keyCode || e.which;
    tecla = String.fromCharCode(key).toString();
    letras = "áéíóúabcdefghijklmnñopqrstuvwxyzÁÉÍÓÚABCDEFGHIJKLMNÑOPQRSTUVWXYZ0123456789-_ ";//Se define todo el abecedario que se quiere que se muestre.
    especiales = [8, 37, 39, 46, 6, 9]; //Es la validación del KeyCodes, que teclas recibe el campo de texto.

    tecla_especial = false
    for(var i in especiales) {
        if(key == especiales[i]) {
            tecla_especial = true;
            break;
        }else{
            tecla_especial = false;
            break;
        }
    }
    //key!=13 &&
    if(letras.indexOf(tecla) == -1 && !tecla_especial){
        return false;
    }
};

//Se utiliza para que el campo de texto solo acepte letras y números
function soloLetrasNumber(e) {
    key = e.keyCode || e.which;
    tecla = String.fromCharCode(key).toString();
    letras = " áéíóúabcdefghijklmnñopqrstuvwxyzÁÉÍÓÚABCDEFGHIJKLMNÑOPQRSTUVWXYZ0123456789-_";//Se define todo el abecedario que se quiere que se muestre.
    especiales = [8, 37, 39, 46, 6, 9]; //Es la validación del KeyCodes, que teclas recibe el campo de texto.

    if( key == 32 ){
        return false;
    }else{
        tecla_especial = false
        for(var i in especiales) {
            if(key == especiales[i]) {
                tecla_especial = true;
                break;
            }else {
                tecla_especial = false;
                break;
            }
        }
    }
    //key!=13 &&
    if(letras.indexOf(tecla) == -1 && !tecla_especial){
        return false;
    }
};

var form = document.getElementById('planillaForm');

if(form){

        form.addEventListener("submit", function(event){
            event.preventDefault();
        
            var ready = true;
            
            for (let index = 1; index < 4; index++) {

                var authform1 = document.getElementsByClassName('authActive' + index);

                if (authform1.length != 0){

                    var first_name_auth  = document.getElementById('first_name_auth' + index);
                    var last_name_auth = document.getElementById('last_name_auth' + index);
                    var national_id_auth = document.getElementById('national_id_auth' + index);
                    var email_address_auth = document.getElementById('email_address_auth' + index);
                    var postal_region_auth = document.getElementById('postal_region_auth' + index);
                    var postal_city_auth = document.getElementById('postal_city_auth' + index);
                    var postal_code_auth = document.getElementById('postal_code_auth' + index);
                    var postal_address1_auth = document.getElementById('postal_address1_auth' + index);
                    var postal_address2_auth = document.getElementById('postal_address2_auth' + index);
                    var telephone_number_auth = document.getElementById('telephone_number_auth' + index);
                
                    if(first_name_auth.value.length == 0){
                        first_name_auth.className += " alert-danger";
                        ready=false;    
                    }
                    if(last_name_auth.value.length == 0){
                            last_name_auth.className += " alert-danger"; 
                            ready=false;  
                        }
                            if(national_id_auth.value.length == 0){
                                national_id_auth.className += " alert-danger";
                                ready=false;  
                            } 
                                if(email_address_auth.value.length == 0){
                                    email_address_auth.className += " alert-danger";
                                    ready=false;  
                                }
                                    if(postal_region_auth.value.length == 0){
                                        postal_region_auth.className += " alert-danger";
                                        ready=false;  
                                    }
                                        if(postal_city_auth.value.length == 0){
                                            postal_city_auth.className += " alert-danger";
                                            ready=false;   
                                        }
                                            if(postal_code_auth.value.length == 0){
                                                postal_code_auth.className += " alert-danger";
                                                ready=false;   
                                            }
                                                if(postal_address1_auth.value.length == 0){
                                                    postal_address1_auth.className += " alert-danger";
                                                    ready=false;  
                                                }
                                                    if(postal_address2_auth.value.length == 0){
                                                        postal_address2_auth.className += " alert-danger";
                                                        ready=false;  
                                                    } 
                                                        if(telephone_number_auth.value.length == 0){
                                                            telephone_number_auth.className += " alert-danger";
                                                            ready=false;  
                                                        }
                                    }
                }

            if (ready){
                this.submit();
            }
            else{
                var errorAuth = document.getElementById('errorAuth');
                errorAuth.setAttribute("role", "alert");
                errorAuth.className = "alert alert-danger alert-dismissible fade show";
                errorAuth.innerText = "Errores en campos de Autorizados";
                errorAuth.innerHTML += "<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>"; 
                $('#modalSend').modal('hide');
            }
        }, false);

}