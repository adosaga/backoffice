//Se utiliza para que el campo de texto solo acepte numeros
function SoloNumeros(evt){
    if(window.event){//asignamos el valor de la tecla a keynum
        keynum = evt.keyCode; //IE
    }
    else{
        keynum = evt.which; //FF
    }
    //comprobamos si se encuentra en el rango numérico y que teclas no recibirá.
    if((keynum > 47 && keynum < 58) || keynum == 8 || keynum == 13 || keynum == 6){
        return true;
    }
    else{
        return false;
    }
};

//Se utiliza para que el campo de texto solo acepte letras
function soloLetras(e) {
    key = e.keyCode || e.which;
    tecla = String.fromCharCode(key).toString();
    letras = " áéíóúabcdefghijklmnñopqrstuvwxyzÁÉÍÓÚABCDEFGHIJKLMNÑOPQRSTUVWXYZ";//Se define todo el abecedario que se quiere que se muestre.
    especiales = [8, 37, 39, 46, 6, 9]; //Es la validación del KeyCodes, que teclas recibe el campo de texto.

    tecla_especial = false
    for(var i in especiales) {
        if(key == especiales[i]) {
            tecla_especial = true;
            break;
        }else{
            tecla_especial = false;
            break;
        }
    }
    //key!=13 &&
    if(letras.indexOf(tecla) == -1 && !tecla_especial){
        return false;
    }
};

$(document).ready(function () {
    
    var name = true;
    var description = true;
    var inAcc = true;
    var finAcc = true;
    var fecExp = true;
    var cardProgram = true;
    var servCode = true;
    var cardProd = true;

    // Validacion para crear
    $('#name').keyup(function () {
       
        if($.trim(this.value).length){
            name = true;
            $(this).removeClass('alert-danger');
            $('#errorName').html('');

            if(name == true && description == true && fecExp == true && cardProgram == true && servCode == true && cardProd == true && inAcc == true && finAcc == true){
                    $('#create').removeAttr("disabled").removeClass("disabled");
            }

        }else{
            name = false;
            $('#create').attr("disabled",true).addClass("disabled");
            $(this).addClass('alert-danger');
            $('#errorName').html('El nombre es requerido');
        }
    });

    $('#description').keyup(function () {
       
        if($.trim(this.value).length){
            description = true;
            $(this).removeClass('alert-danger');
            $('#errorDesc').html('');

            if(name == true && description == true && fecExp == true && cardProgram == true && servCode == true && cardProd == true && inAcc == true && finAcc == true){
                $('#create').removeAttr("disabled").removeClass("disabled");
            }

        }else{
            description = false;
            $('#create').attr("disabled",true).addClass("disabled");
            $(this).addClass('alert-danger');
            $('#errorDesc').html('La descripción es requerida');
        }
    });

    $('#inAcc').keyup(function () {
       
        if($.trim(this.value).length){
            inAcc = true;
            $(this).removeClass('alert-danger');
            $('#errorInAcc').html('');

            if(name == true && description == true && fecExp == true && cardProgram == true && servCode == true && cardProd == true && inAcc == true && finAcc == true){
                $('#create').removeAttr("disabled").removeClass("disabled");
            }

        }else{
            inAcc = false;
            $('#create').attr("disabled",true).addClass("disabled");
            $(this).addClass('alert-danger');
            $('#errorInAcc').html('El número inicial de cuenta es requerido');
        }
    });

    $('#finAcc').keyup(function () {
       
        if($.trim(this.value).length){
            finAcc = true;
            $(this).removeClass('alert-danger');
            $('#errorFinAcc').html('');

            if(name == true && description == true && fecExp == true && cardProgram == true && servCode == true && cardProd == true && inAcc == true && finAcc == true){
                $('#create').removeAttr("disabled").removeClass("disabled");
            }

        }else{
            finAcc = false;
            $('#create').attr("disabled",true).addClass("disabled");
            $(this).addClass('alert-danger');
            $('#errorFinAcc').html('El número final de cuenta es requerido');
        }
    });

    $('#fecExp').keyup(function () {
       
        if($.trim(this.value).length){
            fecExp = true;
            $(this).removeClass('alert-danger');
            $('#errorFecExp').html('');

            if(name == true && description == true && fecExp == true && cardProgram == true && servCode == true && cardProd == true && inAcc == true && finAcc == true){
                $('#create').removeAttr("disabled").removeClass("disabled");
            }

        }else{
            fecExp = false;
            $('#create').attr("disabled",true).addClass("disabled");
            $(this).addClass('alert-danger');
            $('#errorFecExp').html('La fecha de expiración es requerida');
        }
    });

    $('#cardProgram').keyup(function () {
       
        if($.trim(this.value).length){
            cardProgram = true;
            $(this).removeClass('alert-danger');
            $('#errorCardP').html('');

            if(name == true && description == true && fecExp == true && cardProgram == true && servCode == true && cardProd == true && inAcc == true && finAcc == true){
                $('#create').removeAttr("disabled").removeClass("disabled");
            }

        }else{
            cardProgram = false;
            $('#create').attr("disabled",true).addClass("disabled");
            $(this).addClass('alert-danger');
            $('#errorCardP').html('El programa es requerido');
        }
    });

    $('#servCode').keyup(function () {
       
        if($.trim(this.value).length){
            servCode = true;
            $(this).removeClass('alert-danger');
            $('#errorServCode').html('');

            if(name == true && description == true && fecExp == true && cardProgram == true && servCode == true && cardProd == true && inAcc == true && finAcc == true){
                $('#create').removeAttr("disabled").removeClass("disabled");
            }

        }else{
            servCode = false;
            $('#create').attr("disabled",true).addClass("disabled");
            $(this).addClass('alert-danger');
            $('#errorServCode').html('El código de servicio es requerido');
        }
    });

    $('#cardProd').keyup(function () {
       
        if($.trim(this.value).length){
            cardProd = true;
            $(this).removeClass('alert-danger');
            $('#errorcardProd').html('');

            if(name == true && description == true && fecExp == true && cardProgram == true && servCode == true && cardProd == true && inAcc == true && finAcc == true){
                    $('#create').removeAttr("disabled").removeClass("disabled");
            }

        }else{
            cardProd = false;
            $('#create').attr("disabled",true).addClass("disabled");
            $(this).addClass('alert-danger');
            $('#errorcardProd').html('El card product es requerido');
        }
    });

});