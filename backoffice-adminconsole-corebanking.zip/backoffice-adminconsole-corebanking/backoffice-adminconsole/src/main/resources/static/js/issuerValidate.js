//Se utiliza para que el campo de texto solo acepte numeros
function SoloNumeros(evt){
    if(window.event){//asignamos el valor de la tecla a keynum
        keynum = evt.keyCode; //IE
    }
    else{
        keynum = evt.which; //FF
    }
    //comprobamos si se encuentra en el rango numérico y que teclas no recibirá.
    if((keynum > 47 && keynum < 58) || keynum == 8 || keynum == 13 || keynum == 6){
        return true;
    }
    else{
        return false;
    }
};

//Se utiliza para que el campo de texto solo acepte letras
function soloLetras(e) {
    key = e.keyCode || e.which;
    tecla = String.fromCharCode(key).toString();
    letras = " áéíóúabcdefghijklmnñopqrstuvwxyzÁÉÍÓÚABCDEFGHIJKLMNÑOPQRSTUVWXYZ";//Se define todo el abecedario que se quiere que se muestre.
    especiales = [8, 37, 39, 46, 6, 9]; //Es la validación del KeyCodes, que teclas recibe el campo de texto.

    tecla_especial = false
    for(var i in especiales) {
        if(key == especiales[i]) {
            tecla_especial = true;
            break;
        }else{
            tecla_especial = false;
            break;
        }
    }
    //key!=13 &&
    if(letras.indexOf(tecla) == -1 && !tecla_especial){
        return false;
    }
};

$(document).ready(function () {
    
    var name = false;
    var id = false;
    var custFirstname = false;
    var custLastname = false;
    var email = false;
    var phone = false;
    var bAd1 = false;
    var bCity = false;
    var cardAd1 = false;
    var cardCity = false;
    var pinAd1 = false;
    var pinCity = false;

    var regex = /[\w-\.]{2,}@([\w-]{2,}\.)*([\w-]{2,}\.)[\w-]{2,4}/;

    // Validacion para crear
    $('#name').keyup(function () {
       
        if($.trim(this.value).length){
            name = true;
            $(this).removeClass('alert-danger');
            $('#errorName').html('');

            if(name == true && id == true && custFirstname == true && custLastname == true && email == true 
                && phone == true && bAd1 == true && bCity == true && cardAd1 == true && cardCity == true && pinAd1 == true && pinCity == true){
                    $('#create').removeAttr("disabled").removeClass("disabled");
            }

        }else{
            name = false;
            $('#create').attr("disabled",true).addClass("disabled");
            $(this).addClass('alert-danger');
            $('#errorName').html('El nombre es requerido');
        }
    });

    $('#idIssuer').keyup(function () {
       
        if($.trim(this.value).length){
            id = true;
            $(this).removeClass('alert-danger');
            $('#errorId').html('');

            if(name == true && id == true && custFirstname == true && custLastname == true && email == true 
                && phone == true && bAd1 == true && bCity == true && cardAd1 == true && cardCity == true && pinAd1 == true && pinCity == true){
                    $('#create').removeAttr("disabled").removeClass("disabled");
            }

        }else{
            id = false;
            $('#create').attr("disabled",true).addClass("disabled");
            $(this).addClass('alert-danger');
            $('#errorId').html('El id es requerido');
        }
    });

    $('#custFirstname').keyup(function () {
       
        if($.trim(this.value).length){
            custFirstname = true;
            $(this).removeClass('alert-danger');
            $('#errorFirstName').html('');

            if(name == true && id == true && custFirstname == true && custLastname == true && email == true 
                && phone == true && bAd1 == true && bCity == true && cardAd1 == true && cardCity == true && pinAd1 == true && pinCity == true){
                    $('#create').removeAttr("disabled").removeClass("disabled");
            }

        }else{
            custFirstname = false;
            $('#create').attr("disabled",true).addClass("disabled");
            $(this).addClass('alert-danger');
            $('#errorFirstName').html('El primer nombre es requerido');
        }
    });

    $('#custLastname').keyup(function () {
       
        if($.trim(this.value).length){
            custLastname = true;
            $(this).removeClass('alert-danger');
            $('#errorLastName').html('');

            if(name == true && id == true && custFirstname == true && custLastname == true && email == true 
                && phone == true && bAd1 == true && bCity == true && cardAd1 == true && cardCity == true && pinAd1 == true && pinCity == true){
                    $('#create').removeAttr("disabled").removeClass("disabled");
            }

        }else{
            custLastname = false;
            $('#create').attr("disabled",true).addClass("disabled");
            $(this).addClass('alert-danger');
            $('#errorLastName').html('El primer apellido es requerido');
        }
    });

    $('#email').keyup(function () {
       
        if($.trim(this.value).length && regex.test($.trim(this.value))){
            email = true;
            $(this).removeClass('alert-danger');
            $('#errorEmail').html('');

            if(name == true && id == true && custFirstname == true && custLastname == true && email == true 
                && phone == true && bAd1 == true && bCity == true && cardAd1 == true && cardCity == true && pinAd1 == true && pinCity == true){
                    $('#create').removeAttr("disabled").removeClass("disabled");
            }

        }else{
            email = false;
            $('#create').attr("disabled",true).addClass("disabled");
            $(this).addClass('alert-danger');
            $('#errorEmail').html('El formato del email es incorrecto');
        }
    });

    $('#phone').keyup(function () {
       
        if($.trim(this.value).length){
            phone = true;
            $(this).removeClass('alert-danger');
            $('#errorPhone').html('');

            if(name == true && id == true && custFirstname == true && custLastname == true && email == true 
                && phone == true && bAd1 == true && bCity == true && cardAd1 == true && cardCity == true && pinAd1 == true && pinCity == true){
                    $('#create').removeAttr("disabled").removeClass("disabled");
            }

        }else{
            phone = false;
            $('#create').attr("disabled",true).addClass("disabled");
            $(this).addClass('alert-danger');
            $('#errorPhone').html('El teléfono fijo es requerido');
        }
    });

    $('#bAd1').keyup(function () {
       
        if($.trim(this.value).length){
            bAd1 = true;
            $(this).removeClass('alert-danger');
            $('#errorbAd1').html('');

            if(name == true && id == true && custFirstname == true && custLastname == true && email == true 
                && phone == true && bAd1 == true && bCity == true && cardAd1 == true && cardCity == true && pinAd1 == true && pinCity == true){
                    $('#create').removeAttr("disabled").removeClass("disabled");
            }

        }else{
            bAd1 = false;
            $('#create').attr("disabled",true).addClass("disabled");
            $(this).addClass('alert-danger');
            $('#errorbAd1').html('La dirección1 es requerida');
        }
    });

    $('#bCity').keyup(function () {
       
        if($.trim(this.value).length){
            bCity = true;
            $(this).removeClass('alert-danger');
            $('#errorbCity').html('');

            if(name == true && id == true && custFirstname == true && custLastname == true && email == true 
                && phone == true && bAd1 == true && bCity == true && cardAd1 == true && cardCity == true && pinAd1 == true && pinCity == true){
                    $('#create').removeAttr("disabled").removeClass("disabled");
            }

        }else{
            bCity = false;
            $('#create').attr("disabled",true).addClass("disabled");
            $(this).addClass('alert-danger');
            $('#errorbCity').html('La ciudad es requerida');
        }
    });

    $('#cardAd1').keyup(function () {
       
        if($.trim(this.value).length){
            cardAd1 = true;
            $(this).removeClass('alert-danger');
            $('#errorcardAd1').html('');

            if(name == true && id == true && custFirstname == true && custLastname == true && email == true 
                && phone == true && bAd1 == true && bCity == true && cardAd1 == true && cardCity == true && pinAd1 == true && pinCity == true){
                    $('#create').removeAttr("disabled").removeClass("disabled");
            }

        }else{
            cardAd1 = false;
            $('#create').attr("disabled",true).addClass("disabled");
            $(this).addClass('alert-danger');
            $('#errorcardAd1').html('La dirección 1 es requerida');
        }
    });

    $('#cardCity').keyup(function () {
       
        if($.trim(this.value).length){
            cardCity = true;
            $(this).removeClass('alert-danger');
            $('#errorcardCity').html('');

            if(name == true && id == true && custFirstname == true && custLastname == true && email == true 
                && phone == true && bAd1 == true && bCity == true && cardAd1 == true && cardCity == true && pinAd1 == true && pinCity == true){
                    $('#create').removeAttr("disabled").removeClass("disabled");
            }

        }else{
            cardCity = false;
            $('#create').attr("disabled",true).addClass("disabled");
            $(this).addClass('alert-danger');
            $('#errorcardCity').html('La ciudad es requerida');
        }
    });

    $('#pinAd1').keyup(function () {
       
        if($.trim(this.value).length){
            pinAd1 = true;
            $(this).removeClass('alert-danger');
            $('#errorpinAd1').html('');

            if(name == true && id == true && custFirstname == true && custLastname == true && email == true 
                && phone == true && bAd1 == true && bCity == true && cardAd1 == true && cardCity == true && pinAd1 == true && pinCity == true){
                    $('#create').removeAttr("disabled").removeClass("disabled");
            }

        }else{
            pinAd1 = false;
            $('#create').attr("disabled",true).addClass("disabled");
            $(this).addClass('alert-danger');
            $('#errorpinAd1').html('La dirección 1 es requerida');
        }
    });

    $('#pinCity').keyup(function () {
       
        if($.trim(this.value).length){
            pinCity = true;
            $(this).removeClass('alert-danger');
            $('#errorpinCity').html('');

            if(name == true && id == true && custFirstname == true && custLastname == true && email == true 
                && phone == true && bAd1 == true && bCity == true && cardAd1 == true && cardCity == true && pinAd1 == true && pinCity == true){
                    $('#create').removeAttr("disabled").removeClass("disabled");
            }

        }else{
            pinCity = false;
            $('#create').attr("disabled",true).addClass("disabled");
            $(this).addClass('alert-danger');
            $('#errorpinCity').html('La ciudad es requerida');
        }
    });

});