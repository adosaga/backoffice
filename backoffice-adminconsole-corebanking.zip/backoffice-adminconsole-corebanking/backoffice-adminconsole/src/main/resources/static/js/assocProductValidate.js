//Se utiliza para que el campo de texto solo acepte numeros
function SoloNumeros(evt){
    if(window.event){//asignamos el valor de la tecla a keynum
        keynum = evt.keyCode; //IE
    }
    else{
        keynum = evt.which; //FF
    }
    //comprobamos si se encuentra en el rango numérico y que teclas no recibirá.
    if((keynum > 47 && keynum < 58) || keynum == 8 || keynum == 13 || keynum == 6){
        return true;
    }
    else{
        return false;
    }
};

function SoloNumerosyPunto(evt){
    if(window.event){//asignamos el valor de la tecla a keynum
        keynum = evt.keyCode; //IE
    }
    else{
        keynum = evt.which; //FF
    }
    //comprobamos si se encuentra en el rango numérico y que teclas no recibirá.
    if((keynum > 47 && keynum < 58) || keynum == 8 || keynum == 13 || keynum == 6 || keynum == 46){
        return true;
    }
    else{
        return false;
    }
};

$(document).ready(function () {

    $('#confirm').on('click', function (event) {
        event.preventDefault();

        var minLimDay = false;
        var maxLimDay = false;
        var maxTransDay = false;
        var minLimWeek = false;
        var maxLimkWeek = false;
        var maxTransWeek = false;
        var minLimMonth = false;
        var maxLimMonth = false;
        var maxTransMonth = false;
        var comission = false;
        var comissionregex = /^[0-1]\.?[0-9]$/;
        var min = 0;
        var max = 1;

        // Se valida cada uno de los campos
        if($.trim($('#minLimDay').val()).length){
            minLimDay = true;
            $('#minLimDay').removeClass('alert-danger');
            $('#errorMinDay').html('');

        }else{
            minLimDay = false;
            $('#minLimDay').addClass('alert-danger');
            $('#errorMinDay').html('Este campo es requerido');
        }

        if($.trim($('#maxLimDay').val()).length){
            maxLimDay = true;
            $('#maxLimDay').removeClass('alert-danger');
            $('#errorMaxDay').html('');

        }else{
            maxLimDay = false;
            $('#maxLimDay').addClass('alert-danger');
            $('#errorMaxDay').html('Este campo es requerido');
        }
       
        if($.trim($('#maxTransDay').val()).length){
            maxTransDay = true;
            $('#maxTransDay').removeClass('alert-danger');
            $('#errorMaxTransDay').html('');

        }else{
            maxTransDay = false;
            $('#maxTransDay').addClass('alert-danger');
            $('#errorMaxTransDay').html('Este campo es requerido');
        }   
       
        if($.trim($('#minLimWeek').val()).length){
            minLimWeek = true;
            $('#minLimWeek').removeClass('alert-danger');
            $('#errorMinWeek').html('');

        }else{
            minLimWeek = false;
            $('#minLimWeek').addClass('alert-danger');
            $('#errorMinWeek').html('Este campo es requerido');
        }
       
        if($.trim($('#maxLimkWeek').val()).length){
            maxLimkWeek = true;
            $('#maxLimkWeek').removeClass('alert-danger');
            $('#errorMaxWeek').html('');

        }else{
            maxLimkWeek = false;
            $('#maxLimkWeek').addClass('alert-danger');
            $('#errorMaxWeek').html('Este campo es requerido');
        }

        if($.trim($('#maxTransWeek').val()).length){
            maxTransWeek = true;
            $('#maxTransWeek').removeClass('alert-danger');
            $('#errorMaxTransWeek').html('');

        }else{
            maxTransWeek = false;
            $('#maxTransWeek').addClass('alert-danger');
            $('#errorMaxTransWeek').html('Este campo es requerido');
        }

        if($.trim($('#minLimMonth').val()).length){
            minLimMonth = true;
            $('#minLimMonth').removeClass('alert-danger');
            $('#errorMinMonth').html('');

        }else{
            minLimMonth = false;
            $('#minLimMonth').addClass('alert-danger');
            $('#errorMinMonth').html('Este campo es requerido');
        }

        if($.trim($('#maxLimMonth').val()).length){
            maxLimMonth = true;
            $('#maxLimMonth').removeClass('alert-danger');
            $('#errorMaxMonth').html('');

        }else{
            maxLimMonth = false;
            $('#maxLimMonth').addClass('alert-danger');
            $('#errorMaxMonth').html('Este campo es requerido');
        }

        if($.trim($('#maxTransMonth').val()).length){
            maxTransMonth = true;
            $('#maxTransMonth').removeClass('alert-danger');
            $('#errorMaxTransMonth').html('');

        }else{
            maxTransMonth = false;
            $('#maxTransMonth').addClass('alert-danger');
            $('#errorMaxTransMonth').html('Este campo es requerido');
        }

        var decimal = $.trim($('#comission').val());

        if(decimal.length){
 
            if (comissionregex.test(decimal)) {
                
                var decfloat = parseFloat(decimal);

                if (decfloat >= min && decfloat <= max) {
                    comission = true;
                    $('#comission').removeClass('alert-danger');
                    $('#errorComission').html('');
                }else{ 
                    comission = false;
                    $('#comission').addClass('alert-danger');
                    $('#errorComission').html('La comisión debe estar entre el rango de 0.0 a 1.0');
                }
            }else{
                comission = false;
                $('#comission').addClass('alert-danger');
                $('#errorComission').html('La comisión debe estar entre el rango de 0.0 a 1.0');
            }

        }else{
            comission = false;
            $('#comission').addClass('alert-danger');
            $('#errorComission').html('Este campo es requerido');
        }

        if(minLimDay == true && maxLimDay == true && maxTransDay == true && minLimWeek == true && maxLimkWeek == true 
            && maxTransWeek == true && minLimMonth == true && maxLimMonth == true && maxTransMonth == true && comission == true){
                
                $('#confirm').prop('disabled', 'disabled').text('Asociando operación ...');

                // seteo del objeto que se envia en la peticion
                var requestObject = {};
                requestObject['productId'] = $('#productId').val();
                requestObject['productName'] = $('#productName').val();
                requestObject['productDescription'] = $('#productDescription').val();
                requestObject['productTypeId'] = $('#productTypeId').val();
                requestObject['issuerId'] = $('#issuerId').val();
                requestObject['initialAccount'] = $('#initialAccount').val();
                requestObject['finalAccount'] = $('#finalAccount').val();
                requestObject['embozable'] = $('#embozable').val();
                requestObject['isInnominated'] = $('#isInnominated').val();
                requestObject['isChip'] = $('#isChip').val();
                requestObject['cardProgram'] = $('#cardProgram').val();
                requestObject['productStatus'] = $('#productStatus').val();
                requestObject['brandCode'] = $('#brandCode').val();
                requestObject['serviceCode'] = $('#serviceCode').val();
                requestObject['currencyCode'] = $('#currencyCode').val();
                requestObject['fecExp'] = $('#fecExp').val();

                
                var operationObject= {};
                operationObject['operationId'] = $('#opId').val();
                operationObject['maxLimMonth'] = $('#maxLimMonth').val();
                operationObject['minLimMonth'] = $('#minLimMonth').val();
                operationObject['maxLimkWeek'] = $('#maxLimkWeek').val();
                operationObject['minLimWeek'] = $('#minLimWeek').val();
                operationObject['maxLimDay'] = $('#maxLimDay').val();
                operationObject['minLimDay'] = $('#minLimDay').val();
                operationObject['maxTransDay'] = $('#maxTransDay').val();
                operationObject['maxTransWeek'] = $('#maxTransWeek').val();
                operationObject['maxTransMonth'] = $('#maxTransMonth').val();
                operationObject['comission'] = $('#comission').val();
                
                var operationList = [];
                operationList.push(operationObject);

                requestObject['operationList'] = operationList;
                console.log(requestObject);

                $.ajax({
                    type: 'POST',
                    contentType: 'application/json',
                    url: '/config/configProducto/asociar/nuevo',
                    data: JSON.stringify(requestObject),
                    cache:false,
                    success: function (data) { 

                        // se redirecciona 
                        window.location.replace('/config/configProducto/asociar/' + $('#productId').val() + '?assoc=true');

                     },
                     error: function (error) { 

                        var response = error['responseJSON'];

                        var alert = '<div class="alert alert-danger alert-dismissible fade show" role="alert">' + 
                                    '<button type="button" class="close" data-dismiss="alert" aria-label="Close">' +
                                    '<span aria-hidden="true">&times;</span></button>' + response['msg'] + '</div>';

                        $('#msgAjax').html(alert);

                        setTimeout(() => {
                            $('#msgAjax .alert').alert('close');
                        }, 4000);

                        $('#confirm').prop('disabled', false).text('Confirmar asociación');
                        $('#ModalAsociar').modal('hide');
                     }
                });


                
                

        }else{

            $('#ModalAsociar').modal('hide');
        }
    });

});