$(document).ready(function () {
    
    var name = false;
    var desc = false;
    
    // Validacion para crear
    $('#name').keyup(function () {
       
        if($('#name').val()){
            name = true;
            if(name == true && desc == true){
                $('#create').removeAttr("disabled").removeClass("disabled");
            }

        }else{
            name = false;
            $('#create').attr("disabled",true).addClass("disabled");
        }
    });

    $('#desc').keyup(function () {
       
        if($('#desc').val()){
            desc = true;
            if(name == true && desc == true){
                $('#create').removeAttr("disabled").removeClass("disabled");
            }

        }else{
            desc = false;
            $('#create').attr("disabled",true).addClass("disabled");
        }
    });
});