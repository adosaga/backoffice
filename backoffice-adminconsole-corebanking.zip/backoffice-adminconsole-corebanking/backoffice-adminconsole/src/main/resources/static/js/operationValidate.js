//Se utiliza para que el campo de texto solo acepte numeros
function SoloNumeros(evt){
    if(window.event){//asignamos el valor de la tecla a keynum
        keynum = evt.keyCode; //IE
    }
    else{
        keynum = evt.which; //FF
    }
    //comprobamos si se encuentra en el rango numérico y que teclas no recibirá.
    if((keynum > 47 && keynum < 58) || keynum == 8 || keynum == 13 || keynum == 6){
        return true;
    }
    else{
        return false;
    }
};

//Se utiliza para que el campo de texto solo acepte letras
function soloLetras(e) {
    key = e.keyCode || e.which;
    tecla = String.fromCharCode(key).toString();
    letras = " áéíóúabcdefghijklmnñopqrstuvwxyzÁÉÍÓÚABCDEFGHIJKLMNÑOPQRSTUVWXYZ";//Se define todo el abecedario que se quiere que se muestre.
    especiales = [8, 37, 39, 46, 6, 9]; //Es la validación del KeyCodes, que teclas recibe el campo de texto.

    tecla_especial = false
    for(var i in especiales) {
        if(key == especiales[i]) {
            tecla_especial = true;
            break;
        }else{
            tecla_especial = false;
            break;
        }
    }
    //key!=13 &&
    if(letras.indexOf(tecla) == -1 && !tecla_especial){
        return false;
    }
};

$(document).ready(function () {
    
    var name = false;
    var desc = false;
    var minLimDay = false;
    var maxLimDay = false;
    var maxTransDay = false;
    var minLimWeek = false;
    var maxLimkWeek = false;
    var maxTransWeek = false;
    var minLimMonth = false;
    var maxLimMonth = false;
    var maxTransMonth = false;

    // Validacion para crear
    $('#name').keyup(function () {
       
        if($.trim(this.value).length){
            name = true;
            $(this).removeClass('alert-danger');
            $('#errorName').html('');

            if(name == true && desc == true && minLimDay == true && maxLimDay == true && maxTransDay == true && minLimWeek == true && maxLimkWeek == true 
                && maxTransWeek == true && minLimMonth == true && maxLimMonth == true && maxTransMonth == true){
                $('#create').removeAttr("disabled").removeClass("disabled");
            }

        }else{
            name = false;
            $('#create').attr("disabled",true).addClass("disabled");
            $(this).addClass('alert-danger');
            $('#errorName').html('El nombre es requerido');
        }
    });

    $('#desc').keyup(function () {
       
        if($.trim(this.value).length){
            desc = true;
            $(this).removeClass('alert-danger');
            $('#errorDesc').html('');

            if(name == true && desc == true && minLimDay == true && maxLimDay == true && maxTransDay == true && minLimWeek == true && maxLimkWeek == true 
                && maxTransWeek == true && minLimMonth == true && maxLimMonth == true && maxTransMonth == true){
                $('#create').removeAttr("disabled").removeClass("disabled");
            }

        }else{
            desc = false;
            $('#create').attr("disabled",true).addClass("disabled");
            $(this).addClass('alert-danger');
            $('#errorDesc').html('La descripción es requerida');
        }
    });

    $('#minLimDay').keyup(function () {
       
        if($.trim(this.value).length){
            minLimDay = true;
            $(this).removeClass('alert-danger');
            $('#errorMinDay').html('');

            if(name == true && desc == true && minLimDay == true && maxLimDay == true && maxTransDay == true && minLimWeek == true && maxLimkWeek == true 
                && maxTransWeek == true && minLimMonth == true && maxLimMonth == true && maxTransMonth == true){
                    $('#create').removeAttr("disabled").removeClass("disabled");
            }

        }else{
            minLimDay = false;
            $('#create').attr("disabled",true).addClass("disabled");
            $(this).addClass('alert-danger');
            $('#errorMinDay').html('Este campo es requerido');
        }
    });

    $('#maxLimDay').keyup(function () {
       
        if($.trim(this.value).length){
            maxLimDay = true;
            $(this).removeClass('alert-danger');
            $('#errorMaxDay').html('');

            if(name == true && desc == true && minLimDay == true && maxLimDay == true && maxTransDay == true && minLimWeek == true && maxLimkWeek == true  
                && maxTransWeek == true && minLimMonth == true && maxLimMonth == true && maxTransMonth == true){
                    $('#create').removeAttr("disabled").removeClass("disabled");
            }

        }else{
            maxLimDay = false;
            $('#create').attr("disabled",true).addClass("disabled");
            $(this).addClass('alert-danger');
            $('#errorMaxDay').html('Este campo es requerido');
        }
    });

    $('#maxTransDay').keyup(function () {
       
        if($.trim(this.value).length){
            maxTransDay = true;
            $(this).removeClass('alert-danger');
            $('#errorMaxTransDay').html('');

            if(name == true && desc == true && minLimDay == true && maxLimDay == true && maxTransDay == true && minLimWeek == true && maxLimkWeek == true  
                && maxTransWeek == true && minLimMonth == true && maxLimMonth == true && maxTransMonth == true){
                    $('#create').removeAttr("disabled").removeClass("disabled");
            }

        }else{
            maxTransDay = false;
            $('#create').attr("disabled",true).addClass("disabled");
            $(this).addClass('alert-danger');
            $('#errorMaxTransDay').html('Este campo es requerido');
        }
    });

    $('#minLimWeek').keyup(function () {
       
        if($.trim(this.value).length){
            minLimWeek = true;
            $(this).removeClass('alert-danger');
            $('#errorMinWeek').html('');

            if(name == true && desc == true && minLimDay == true && maxLimDay == true && maxTransDay == true && minLimWeek == true && maxLimkWeek == true  
                && maxTransWeek == true && minLimMonth == true && maxLimMonth == true && maxTransMonth == true){
                    $('#create').removeAttr("disabled").removeClass("disabled");
            }

        }else{
            minLimWeek = false;
            $('#create').attr("disabled",true).addClass("disabled");
            $(this).addClass('alert-danger');
            $('#errorMinWeek').html('Este campo es requerido');
        }
    });

    $('#maxLimkWeek').keyup(function () {
       
        if($.trim(this.value).length){
            maxLimkWeek = true;
            $(this).removeClass('alert-danger');
            $('#errorMaxWeek').html('');

            if(name == true && desc == true && minLimDay == true && maxLimDay == true && maxTransDay == true && minLimWeek == true && maxLimkWeek == true  
                && maxTransWeek == true && minLimMonth == true && maxLimMonth == true && maxTransMonth == true){
                    $('#create').removeAttr("disabled").removeClass("disabled");
            }

        }else{
            maxLimkWeek = false;
            $('#create').attr("disabled",true).addClass("disabled");
            $(this).addClass('alert-danger');
            $('#errorMaxWeek').html('Este campo es requerido');
        }
    });

    $('#maxTransWeek').keyup(function () {
       
        if($.trim(this.value).length){
            maxTransWeek = true;
            $(this).removeClass('alert-danger');
            $('#errorMaxTransWeek').html('');

            if(name == true && desc == true && minLimDay == true && maxLimDay == true && maxTransDay == true && minLimWeek == true && maxLimkWeek == true  
                && maxTransWeek == true && minLimMonth == true && maxLimMonth == true && maxTransMonth == true){
                    $('#create').removeAttr("disabled").removeClass("disabled");
            }

        }else{
            maxTransWeek = false;
            $('#create').attr("disabled",true).addClass("disabled");
            $(this).addClass('alert-danger');
            $('#errorMaxTransWeek').html('Este campo es requerido');
        }
    });

    $('#minLimMonth').keyup(function () {
       
        if($.trim(this.value).length){
            minLimMonth = true;
            $(this).removeClass('alert-danger');
            $('#errorMinMonth').html('');

            if(name == true && desc == true && minLimDay == true && maxLimDay == true && maxTransDay == true && minLimWeek == true && maxLimkWeek == true  
                && maxTransWeek == true && minLimMonth == true && maxLimMonth == true && maxTransMonth == true){
                    $('#create').removeAttr("disabled").removeClass("disabled");
            }

        }else{
            minLimMonth = false;
            $('#create').attr("disabled",true).addClass("disabled");
            $(this).addClass('alert-danger');
            $('#errorMinMonth').html('Este campo es requerido');
        }
    });

    $('#maxLimMonth').keyup(function () {
       
        if($.trim(this.value).length){
            maxLimMonth = true;
            $(this).removeClass('alert-danger');
            $('#errorMaxMonth').html('');

            if(name == true && desc == true && minLimDay == true && maxLimDay == true && maxTransDay == true && minLimWeek == true && maxLimkWeek == true  
                && maxTransWeek == true && minLimMonth == true && maxLimMonth == true && maxTransMonth == true){
                    $('#create').removeAttr("disabled").removeClass("disabled");
            }

        }else{
            maxLimMonth = false;
            $('#create').attr("disabled",true).addClass("disabled");
            $(this).addClass('alert-danger');
            $('#errorMaxMonth').html('Este campo es requerido');
        }
    });

    $('#maxTransMonth').keyup(function () {
       
        if($.trim(this.value).length){
            maxTransMonth = true;
            $(this).removeClass('alert-danger');
            $('#errorMaxTransMonth').html('');

            if(name == true && desc == true && minLimDay == true && maxLimDay == true && maxTransDay == true && minLimWeek == true && maxLimkWeek == true  
                && maxTransWeek == true && minLimMonth == true && maxLimMonth == true && maxTransMonth == true){
                    $('#create').removeAttr("disabled").removeClass("disabled");
            }

        }else{
            maxTransMonth = false;
            $('#create').attr("disabled",true).addClass("disabled");
            $(this).addClass('alert-danger');
            $('#errorMaxTransMonth').html('Este campo es requerido');
        }
    });

});