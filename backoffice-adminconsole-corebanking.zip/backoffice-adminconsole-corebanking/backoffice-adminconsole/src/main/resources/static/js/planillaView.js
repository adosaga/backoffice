$(document).ready(function(){
	// Cerrar los formularios
	$('#closeauth1').on('click', function () {
        $('#authform1').fadeOut();
        $('#authform1').removeClass('authActive1');
        $('#showauth1').fadeIn();
        $('#showauth2').fadeOut();
    });
	
	$('#closeauth2').on('click', function () {
        $('#authform2').fadeOut();
        $('#authform2').removeClass('authActive2');
        $('#showauth2').fadeIn();
        $('#showauth3').fadeOut();
        $('#closeauth1').fadeIn();
    });
	
	$('#closeauth3').on('click', function () {
        $('#authform3').fadeOut();
        $('#authform3').removeClass('authActive3');
        $('#showauth3').fadeIn();
        $('#closeauth2').fadeIn();
    });
	
	// Mostrar los formularios
	$('#showauth1').on('click', function () {
        $('#authform1').fadeIn();
        $('#authform1').addClass('authActive1');
        $('#first_name_auth1').focus();
        $('#showauth2').fadeIn();
        $('#showauth1').fadeOut();
        
    });
	
	$('#showauth2').on('click', function () {
        $('#authform2').fadeIn();
        $('#authform2').addClass('authActive2');
        $('#first_name_auth2').focus();
        $('#closeauth1').fadeOut();
        $('#showauth3').fadeIn();
        $('#showauth2').fadeOut();
    });
	
	$('#showauth3').on('click', function () {
        $('#authform3').fadeIn();
        $('#authform3').addClass('authActive3');
        $('#first_name_auth3').focus();
        $('#closeauth2').fadeOut();
        $('#showauth3').fadeOut();
    });
	
});