$(document).ready(function () {
    var fechaIn = false;
    var fechaFin = false;
    var formato =['D/M/YY'];


    $('#fechaIn').keyup(function () { 
        
        if($(this).val()){

            // validar el formato de la fecha
            if(moment($(this).val(), formato, true).isValid()){
                
                $('#fechaIn').removeClass('alert-danger');
                fechaIn = true;

                if(fechaIn == true && fechaFin == true){
                    $('#searchButton').removeAttr('disabled').removeClass('disabled');
                }

            }else{
                fechaIn = false;
                $('#searchButton').attr('disabled', true).addClass('disabled');
                $('#fechaIn').addClass('alert-danger');
            }

        }else{
            $('#searchButton').attr('disabled', true).addClass('disabled');
            fechaIn = false;
        }
        
    });

    $('#fechaFin').keyup(function () { 
  
        if($(this).val()){

            // validar el formato de la fecha
            if(moment($(this).val(), formato, true).isValid()){
                $('#fechaFin').removeClass('alert-danger');
                fechaFin = true;

                if(fechaIn == true && fechaFin == true){
                    $('#searchButton').removeAttr('disabled').removeClass('disabled');
                }

            }else{
                fechaFin = false;
                $('#searchButton').attr('disabled', true).addClass('disabled');
                $('#fechaFin').addClass('alert-danger');
            }
            
        }else{
            $('#searchButton').attr('disabled', true).addClass('disabled');
            fechaFin = false;
        }
        
    });
});