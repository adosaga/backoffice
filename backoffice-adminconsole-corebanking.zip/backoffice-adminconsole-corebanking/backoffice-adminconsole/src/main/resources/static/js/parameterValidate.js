    //Se utiliza para que el campo de texto solo acepte letras
    function soloLetras(e) {
        key = e.keyCode || e.which;
        tecla = String.fromCharCode(key).toString();
        letras = "áéíóúabcdefghijklmnñopqrstuvwxyzÁÉÍÓÚABCDEFGHIJKLMNÑOPQRSTUVWXYZ ";//Se define todo el abecedario que se quiere que se muestre.
        especiales = [8, 37, 39, 46, 6, 9]; //Es la validación del KeyCodes, que teclas recibe el campo de texto.
    
        tecla_especial = false
        for(var i in especiales) {
            if(key == especiales[i]) {
                tecla_especial = true;
                break;
            }else{
                tecla_especial = false;
                break;
            }
        }
        //key!=13 &&
        if(letras.indexOf(tecla) == -1 && !tecla_especial){
            return false;
        }
    };

    //Se utiliza para que el campo de texto solo acepte numeros
function SoloNumeros(evt){
    if(window.event){//asignamos el valor de la tecla a keynum
        keynum = evt.keyCode; //IE
    }
    else{
        keynum = evt.which; //FF
    }
    //comprobamos si se encuentra en el rango numérico y que teclas no recibirá.
    if((keynum > 47 && keynum < 58) || keynum == 8 || keynum == 13 || keynum == 6){
        return true;
    }
    else{
        return false;
    }
};

function SoloCantidad(evt){
    if(window.event){//asignamos el valor de la tecla a keynum
        keynum = evt.keyCode; //IE
    }
    else{
        keynum = evt.which; //FF
        
    }
    console.log('keynum: ', keynum);

    //comprobamos si se encuentra en el rango numérico y que teclas no recibirá.
    if((keynum > 47 && keynum < 58) || keynum == 8 || keynum == 13 || keynum == 6 || keynum == 46 ){
        return true;
    }
    else{
        return false;
    }
};

$(document).ready(function () {
    
    var name = false;
    var desc = false;
    var value = false;

    // --------------------------------- validacion para crear parametro  ------------------------------------------
    $('#parameterName').keyup(function () {
       
        if($('#parameterName').val()){
            name = true;
            if(name == true && desc == true && value == true ){
                $('#createParam').removeAttr("disabled").removeClass("disabled");
            }

        }else{
            name = false;
            $('#createParam').attr("disabled",true).addClass("disabled");
        }
    });

    $('#parameterDesc').keyup(function () {
       
        if($('#parameterDesc').val()){
            desc = true;
            if(name == true && desc == true && value == true){
                $('#createParam').removeAttr("disabled").removeClass("disabled");
            }

        }else{
            desc = false;
            $('#createParam').attr("disabled",true).addClass("disabled");
        }
    });

    $('#parameterVal').keyup(function () {
       
        if($('#parameterVal').val()){
            value = true;
            if(name == true && desc == true && value == true){
                $('#createParam').removeAttr("disabled").removeClass("disabled");
            }

        }else{
            value = false;
            $('#createParam').attr("disabled",true).addClass("disabled");
        }
    });

    $('#parameterVal').attr("onkeypress" , "return SoloNumeros(event);");

    // validaciones para valor de parametro al crear nuevo
    $('#configType').change(function () {
       var typeId = $(this).val();
      
       // valor flag
       if(typeId == "8"){

            $('#parameterVal').attr("onkeypress" , "return soloLetras(event);").attr("maxlength" , "2").val("").removeClass('alert-danger');
            $('#parameterMsg').attr("hidden", false).text("Los valores requeridos son: SI o NO");
            
       }else if(typeId == "7"){ 

            $('#parameterVal').attr("onkeypress" , "return SoloCantidad(event);").removeAttr("maxlength").val("").removeClass('alert-danger');
            $('#parameterMsg').attr("hidden", true).text();
       }else{

            $('#parameterVal').attr("onkeypress" , "return SoloNumeros(event);").removeAttr("maxlength").val("").removeClass('alert-danger');
            $('#parameterMsg').attr("hidden", true).text();
       } 
    });

     //validacion al hacer submit de creacion
     $('#buttonC').click(function (e) { 
        e.preventDefault();

        var array = ['SI','NO'];
        var typeId = $('#configType').val();
        var valid = false;

        if(typeId == "8"){

            var inputVal = $('#parameterVal').val().toUpperCase();
            
            array.forEach(function(value, index){

                if(inputVal == value){
                    $('#parameterVal').val(inputVal);
                    valid = true;
                    return false;
                }else{
                    
                }
            });

            if(valid){
                $('#newForm').submit();
            }else{
                $('#modalSend').modal('hide');
                $('#parameterVal').addClass('alert-danger');
            }
        }else{
            $('#newForm').submit();
        }
    });
    
    
    // ----------------------------   validaciones para editar parametro   -------------------------------------------------

    $('#editVal').keyup(function () {
       
        if($('#editVal').val()){
            
            $('#sendEdit').removeAttr("disabled").removeClass("disabled");
            
        }else{
            
            $('#sendEdit').attr("disabled",true).addClass("disabled");
        }
    });

    // validaciones para valor de parametro
    $('#configTypeEdit').change(function () {
       var typeId = $(this).val();
      
       // valor flag
       /*
       if(typeId == "8"){

            $('#editVal').attr("onkeypress" , "return soloLetras(event);").attr("maxlength" , "2").val("").removeClass('alert-danger');
            $('#parameterMsg').attr("hidden", false).text("Los valores requeridos son: SI o NO");
            $('#sendEdit').attr("disabled",true).addClass("disabled");
            
       }else if(typeId == "7"){ 

            $('#editVal').attr("onkeypress" , "return SoloCantidad(event);").removeAtwintr("maxlength").val("").removeClass('alert-danger');
            $('#parameterMsg').attr("hidden", true).text();
            $('#sendEdit').attr("disabled",true).addClass("disabled");
       }else{
       */

            $('#editVal').attr("onkeypress" , "return SoloNumeros(event);").removeAttr("maxlength").val("").removeClass('alert-danger');
            $('#parameterMsg').attr("hidden", true).text();
            $('#sendEdit').attr("disabled",true).addClass("disabled");
      // } 
    });

   //validacion al hacer submit de edicion
   $('#buttonE').click(function (e) { 
    e.preventDefault();

    var array = ['SI','NO'];
    var typeId = $('#configTypeEdit').val();
    var valid = false;

    if(typeId == "8"){

        var inputVal = $('#editVal').val().toUpperCase();
        
        array.forEach(function(value, index){

            if(inputVal == value){
                $('#editVal').val(inputVal);
                valid = true;
                return false;
            }else{
                
            }
        });

        if(valid){
            $('#editForm').submit();
        }else{
            $('#modalSend').modal('hide');
            $('#editVal').addClass('alert-danger');
        }
    }else{
        $('#editForm').submit();
    }
});

});