//Se utiliza para que el campo de texto solo acepte numeros
function SoloNumeros(evt){
    if(window.event){//asignamos el valor de la tecla a keynum
        keynum = evt.keyCode; //IE
    }
    else{
        keynum = evt.which; //FF
    }
    //comprobamos si se encuentra en el rango numérico y que teclas no recibirá.
    if((keynum > 47 && keynum < 58) || keynum == 8 || keynum == 13 || keynum == 6){
        return true;
    }
    else{
        return false;
    }
};

//Se utiliza para que el campo de texto solo acepte letras
function soloLetras(e) {
    key = e.keyCode || e.which;
    tecla = String.fromCharCode(key).toString();
    letras = " áéíóúabcdefghijklmnñopqrstuvwxyzÁÉÍÓÚABCDEFGHIJKLMNÑOPQRSTUVWXYZ";//Se define todo el abecedario que se quiere que se muestre.
    especiales = [8, 37, 39, 46, 6, 9]; //Es la validación del KeyCodes, que teclas recibe el campo de texto.

    tecla_especial = false
    for(var i in especiales) {
        if(key == especiales[i]) {
            tecla_especial = true;
            break;
        }else{
            tecla_especial = false;
            break;
        }
    }
    //key!=13 &&
    if(letras.indexOf(tecla) == -1 && !tecla_especial){
        return false;
    }
};

$(document).ready(function () {
    
    var name = false;
    var id = false;

    // Validacion para crear
    $('#name').keyup(function () {
       
        if($.trim(this.value).length){
            name = true;
            $(this).removeClass('alert-danger');
            $('#errorName').html('');

            if(name == true && id == true){
                $('#create').removeAttr("disabled").removeClass("disabled");
            }

        }else{
            name = false;
            $('#create').attr("disabled",true).addClass("disabled");
            $(this).addClass('alert-danger');
            $('#errorName').html('El nombre es requerido');
        }
    });

    $('#idInst').keyup(function () {
       
        if($.trim(this.value).length){
            id = true;
            $(this).removeClass('alert-danger');
            $('#errorId').html('');

            if(name == true && id == true){
                $('#create').removeAttr("disabled").removeClass("disabled");
            }

        }else{
            id = false;
            $('#create').attr("disabled",true).addClass("disabled");
            $(this).addClass('alert-danger');
            $('#errorId').html('El ID es requerido');
        }
    });

});