//Se utiliza para que el campo de texto solo acepte numeros
function SoloNumeros(evt){
    if(window.event){//asignamos el valor de la tecla a keynum
        keynum = evt.keyCode; //IE
    }
    else{
        keynum = evt.which; //FF
    }
    //comprobamos si se encuentra en el rango numérico y que teclas no recibirá.
    if((keynum > 47 && keynum < 58) || keynum == 8 || keynum == 13 || keynum == 6){
        return true;
    }
    else{
        return false;
    }
};

//Para eliminar la barra espaciadora
function sinespacios(evt){
    if(window.event){//asignamos el valor de la tecla a keynum
        keynum = evt.keyCode; //IE
    }
    else{
        keynum = evt.which; //FF
    }
    //comprobamos si se encuentra en el rango numérico y que teclas no recibirá.
    if( keynum == 32 ){
        return false;
    }
    else{
        return true;
    }
};

//Se utiliza para que el campo de texto solo acepte letras
function soloLetras(e) {
    key = e.keyCode || e.which;
    tecla = String.fromCharCode(key).toString();
    letras = " áéíóúabcdefghijklmnñopqrstuvwxyzÁÉÍÓÚABCDEFGHIJKLMNÑOPQRSTUVWXYZ";//Se define todo el abecedario que se quiere que se muestre.
    especiales = [8, 37, 39, 46, 6, 9]; //Es la validación del KeyCodes, que teclas recibe el campo de texto.

    tecla_especial = false
    for(var i in especiales) {
        if(key == especiales[i]) {
            tecla_especial = true;
            break;
        }else{
            tecla_especial = false;
            break;
        }
    }
    //key!=13 &&
    if(letras.indexOf(tecla) == -1 && !tecla_especial){
        return false;
    }
};

/*Para adquirir letras, números, espacios y dos caracteres especiales*/
function letrasnumeros(e) {
    key = e.keyCode || e.which;
    tecla = String.fromCharCode(key).toString();
    letras = "áéíóúabcdefghijklmnñopqrstuvwxyzÁÉÍÓÚABCDEFGHIJKLMNÑOPQRSTUVWXYZ0123456789-_ ";//Se define todo el abecedario que se quiere que se muestre.
    especiales = [8, 37, 39, 46, 6, 9]; //Es la validación del KeyCodes, que teclas recibe el campo de texto.

    tecla_especial = false
    for(var i in especiales) {
        if(key == especiales[i]) {
            tecla_especial = true;
            break;
        }else{
            tecla_especial = false;
            break;
        }
    }
    //key!=13 &&
    if(letras.indexOf(tecla) == -1 && !tecla_especial){
        return false;
    }
};

//Se utiliza para que el campo de texto solo acepte letras y números
function soloLetrasNumber(e) {
    key = e.keyCode || e.which;
    tecla = String.fromCharCode(key).toString();
    letras = " áéíóúabcdefghijklmnñopqrstuvwxyzÁÉÍÓÚABCDEFGHIJKLMNÑOPQRSTUVWXYZ0123456789-_";//Se define todo el abecedario que se quiere que se muestre.
    especiales = [8, 37, 39, 46, 6, 9]; //Es la validación del KeyCodes, que teclas recibe el campo de texto.

    if( key == 32 ){
        return false;
    }else{
        tecla_especial = false
        for(var i in especiales) {
            if(key == especiales[i]) {
                tecla_especial = true;
                break;
            }else {
                tecla_especial = false;
                break;
            }
        }
    }
    //key!=13 &&
    if(letras.indexOf(tecla) == -1 && !tecla_especial){
        return false;
    }
};

//Se utiliza para que el campo de texto solo acepte letras, números y caracteres . - _
function validateUsername(e) {
    key = e.keyCode || e.which;
    tecla = String.fromCharCode(key).toString();
    letras = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_.";//Se define todo el abecedario que se quiere que se muestre.
    especiales = [8, 37, 39, 46, 6, 9]; //Es la validación del KeyCodes, que teclas recibe el campo de texto.

    if( key == 32 ){
        return false;
    }else{
        tecla_especial = false
        for(var i in especiales) {
            if(key == especiales[i]) {
                tecla_especial = true;
                break;
            }else {
                tecla_especial = false;
                break;
            }
        }
    }
    //key!=13 &&
    if(letras.indexOf(tecla) == -1 && !tecla_especial){
        return false;
    }
};

$(document).ready(function () {

    $('#phone').intlTelInput({
        preferredCountries: ["co", "pr","us"]
    });
    $('#create').click(function(){
        var countryData = $("#phone").intlTelInput("getSelectedCountryData");
        var number = $("#phone").val();
        $("#code_hidden").val(countryData.dialCode);
        $("#phone_hidden").val(number);
    });

    $('#createUser').click(function (e) { 
        e.preventDefault();

        var ready = true;
        var regex = /[\w-\.]{2,}@([\w-]{2,}\.)*([\w-]{2,}\.)[\w-]{2,4}/;
        //var regexUsername = /([^\.\-\_])\w+(([\.\-\_])\w)*/;

        if ($('#user_id').val().length == 0) {
            ready = false;
            $('#user_id').addClass('alert-danger');
            $('#usernameError').html('El usuario es requerido'); 
        } else {
            $('#user_id').removeClass('alert-danger');
            $('#usernameError').html(''); 
            /*if (!regexUsername.test($.trim($('#user_id').val()))) {
                ready = false;
                $('#user_id').addClass('alert-danger');
                $('#usernameError').html('El formato del usuario es incorrecto'); 
            } else {
                $('#user_id').removeClass('alert-danger');
                $('#usernameError').html(''); 
            }*/
        }

        if ($('#national_id').val().length == 0) {
            ready = false;
            $('#national_id').addClass('alert-danger');
            $('#nationalError').html('El N° de Identificación es requerido'); 
        } else {
            $('#national_id').removeClass('alert-danger');
            $('#nationalError').html(''); 
        }

        if ($('#user_email').val().length == 0) {
            ready = false;
            $('#user_email').addClass('alert-danger');
            $('#emailError').html('El email es requerido'); 
        } else {

            if (!regex.test($.trim($('#user_email').val()))) {
                ready = false;
                $('#user_email').addClass('alert-danger');
                $('#emailError').html('El formato del email es incorrecto'); 
            } else {
                $('#user_email').removeClass('alert-danger');
                $('#emailError').html(''); 
            }
        }

        if ($('#user_firstname').val().length == 0) {
            ready = false;
            $('#user_firstname').addClass('alert-danger');
            $('#firstnameError').html('El Primer Nombre es requerido'); 
        } else {
            $('#user_firstname').removeClass('alert-danger');
            $('#firstnameError').html(''); 
        }

        if ($('#user_lastname').val().length == 0) {
            ready = false;
            $('#user_lastname').addClass('alert-danger');
            $('#lastnameError').html('El Primer Apellido es requerido'); 
        } else {
            $('#user_lastname').removeClass('alert-danger');
            $('#lastnameError').html(''); 
        }

        if (ready) {
            $('#userForm').submit();
        } else {
            
            $('#modalSend').modal('hide');

        }
    });

});

