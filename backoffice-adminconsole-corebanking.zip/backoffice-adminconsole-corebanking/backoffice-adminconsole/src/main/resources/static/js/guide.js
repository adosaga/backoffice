//Se utiliza para que el campo de texto solo acepte letras
function soloLetras(e) {
    key = e.keyCode || e.which;
    tecla = String.fromCharCode(key).toString();
    letras = " áéíóúabcdefghijklmnñopqrstuvwxyzÁÉÍÓÚABCDEFGHIJKLMNÑOPQRSTUVWXYZ";//Se define todo el abecedario que se quiere que se muestre.
    especiales = [8, 37, 39, 46, 6, 9]; //Es la validación del KeyCodes, que teclas recibe el campo de texto.

    tecla_especial = false
    for(var i in especiales) {
        if(key == especiales[i]) {
            tecla_especial = true;
            break;
        }else{
            tecla_especial = false;
            break;
        }
    }
    //key!=13 &&
    if(letras.indexOf(tecla) == -1 && !tecla_especial){
        return false;
    }
};

//Se utiliza para que el campo de texto solo acepte numeros
function SoloNumeros(evt){
    if(window.event){//asignamos el valor de la tecla a keynum
        keynum = evt.keyCode; //IE
    }
    else{
        keynum = evt.which; //FF
    }
    //comprobamos si se encuentra en el rango numérico y que teclas no recibirá.
    if((keynum > 47 && keynum < 58) || keynum == 8 || keynum == 13 || keynum == 6){
        return true;
    }
    else{
        return false;
    }
};



$(document).ready(function () {

    $('#reqInput').val("1");

    $('#addCard').click(function (e) { 
        
        $('#contenedor').append('<div id="cardInfo" class="form-group row rounded m-3 pb-3" style="background-color: #b6b6b691;"><div class="col-3"><label class="col-form-label">Titular de la tarjeta </label><input type="text" name="cardholder[]" class="form-control" placeholder="Winsor" onkeypress="return soloLetras(event);"/></div><div class="col-3"><label class="col-form-label">Número de identificación </label><input type="text" name="nationalId[]" class="form-control" placeholder="64789945" onkeypress="return SoloNumeros(event);"/></div><div class="col-3"><label class="col-form-label">Número de la tarjeta (PAN) </label><input type="text" name="pan[]" class="form-control" placeholder="1678922879632807" onkeypress="return SoloNumeros(event);"/></div><div class="col-2" id="req"><label class="col-form-label">Tipo de solicitud</label><input id="reqInput" type="text" name="reqType[]" value="1" hidden="hidden"/><select class="form-control" id="reqSelect"><option value="1">Emisión</option><option value="2">Reposición</option><option value="3">Renovación</option><option value="4">Repo. PIN</option></select></div><div class="col-1"><button type="button" id="removeCard" class="btn btn-danger closeCard"><i class="fas fa-times"></i></button></div></div>');

    });
    
    $('#contenedor').on('click','#removeCard', function (e) { 
    
        $(this).closest('#cardInfo').remove();
    });

    var phone = false;
    var contactName = false;
    var cardNumber = false;
    var pinNumber = false;

    //Validaciones de campos de informacion general
    $('#phone').keyup(function (e) { 
        
        if ($.trim(this.value).length) {
            
            phone = true;
            $('#phone').removeClass('alert-danger');
            $('#errorPhone').html('');
            
            if (phone == true && contactName == true && cardNumber == true && pinNumber == true) {
               $('#create').removeAttr('disabled').removeClass('disabled'); 
            }

        } else {
            phone = false;
            $('#phone').addClass('alert-danger');
            $('#errorPhone').html('El teléfono es requerido');
            $('#create').attr('disabled', true).addClass('disabled'); 
        }
    });

    $('#contactName').keyup(function (e) { 
        
        if ($.trim(this.value).length) {
            
            contactName = true;
            $('#contactName').removeClass('alert-danger');
            $('#errorContactName').html('');
            
            if (phone == true && contactName == true && cardNumber == true && pinNumber == true) {
               $('#create').removeAttr('disabled').removeClass('disabled'); 
            }

        } else {
            contactName = false;
            $('#contactName').addClass('alert-danger');
            $('#errorContactName').html('El nombre de contacto es requerido');
            $('#create').attr('disabled', true).addClass('disabled'); 
        }
    });

    $('#cardNumber').keyup(function (e) { 
        
        if ($.trim(this.value).length) {
            
            cardNumber = true;
            $('#cardNumber').removeClass('alert-danger');
            $('#errorCardNumber').html('');
            
            if (phone == true && contactName == true && cardNumber == true && pinNumber == true) {
               $('#create').removeAttr('disabled').removeClass('disabled'); 
            }

        } else {
            cardNumber = false;
            $('#cardNumber').addClass('alert-danger');
            $('#errorCardNumber').html('La cantidad de tarjetas es requerida');
            $('#create').attr('disabled', true).addClass('disabled'); 
        }
    });

    $('#pinNumber').keyup(function (e) { 
        
        if ($.trim(this.value).length) {
            
            pinNumber = true;
            $('#pinNumber').removeClass('alert-danger');
            $('#errorPinNumber').html('');
            
            if (phone == true && contactName == true && cardNumber == true && pinNumber == true) {
               $('#create').removeAttr('disabled').removeClass('disabled'); 
            }

        } else {
            pinNumber = false;
            $('#pinNumber').addClass('alert-danger');
            $('#errorPinNumber').html('La cantidad de pines es requerida');
            $('#create').attr('disabled', true).addClass('disabled'); 
        }
    });

    $('#contenedor').on('change','#reqSelect', function (e) { 
        var reqType = $(this).val();

        $(this).closest('div#req').find('input[name^=reqType]').val(reqType);
    });

    $('#createGuide').click(function (e) { 
        e.preventDefault();
        
        var cardholder = [];
        var checkC = false;
        var nationalId = [];
        var checkN = false;
        var pan = [];
        var checkP = false;
        var reqType = [];

        //Validaciones de campos de detalles de entrega
        $('input[name^=cardholder]').each(function () {

            if($(this).val().length == 0){
                checkC = true;
                $(this).addClass('alert-danger');
            }else{
                $(this).removeClass('alert-danger');
                cardholder.push($(this).val());
            }
        });

        $('input[name^=nationalId]').each(function () {
            if ($(this).val().length == 0) {
                checkN = true;
                $(this).addClass('alert-danger');
            } else {
                $(this).removeClass('alert-danger');
                nationalId.push($(this).val());
            }     
        });

        $('input[name^=pan]').each(function () {
            if ($(this).val().length == 0) {
                checkP = true;
                $(this).addClass('alert-danger');
            } else {
                $(this).removeClass('alert-danger');
                pan.push($(this).val());
            }
        });

        $('input[name^=reqType]').each(function () {
                
                reqType.push($(this).val());
        });

        if(checkC == true || checkN == true || checkP == true){
            
            $('#modalSend').modal('hide');

        }else{

            $('#listCardholder').val(cardholder);
            $('#listNationalId').val(nationalId);
            $('#listPan').val(pan);
            $('#listRequestType').val(reqType);

            $('#guideForm').submit();
        }
    });

});