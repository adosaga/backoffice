$(document).ready(function () {

var validateActual = false;
var validatePass = false;
var validateConfirm = false;
    //Validación de la creación del password
$('#password').keyup(function() {
    // set password variable
    var pswd = $(this).val();
    //validate the length
    if ( pswd.length < 8 || pswd.length > 15 ) {
        $('#length').removeClass('text-success').addClass('text-danger');
        longitud=false;
    } else {
        $('#length').removeClass('text-danger').addClass('text-success');
        longitud=true;
    }

    //validate letter
    if (pswd.match(/[A-z]/)) {
        $('#letter').removeClass('text-danger').addClass('text-success');
        mt=true;
    } else {
        $('#letter').removeClass('text-success').addClass('text-danger');
        mt=false;
    }

    //validate capital letter
    if (pswd.match(/[A-Z]/)) {
        $('#capital').removeClass('text-danger').addClass('text-success');
        cap=true;
    } else {
        $('#capital').removeClass('text-success').addClass('text-danger');
        cap=false;
    }

    //validate number
    if (!pswd.match(/((\w|[!@#$%])*\d(\w|[!@#$%])*\d(\w|[!@#$%])*\d(\w|[!@#\$%])*\d(\w|[!@#$%])*(\d)*)/) && pswd.match(/\d{1}/) ) {
        $('#number').removeClass('text-danger').addClass('text-success');
        car=true;
    } else {
        $('#number').removeClass('text-success').addClass('text-danger');
        car=false;
    }

    if (!pswd.match(/(.)\1{2,}/) ) {
        $('#consecutivo').removeClass('text-danger').addClass('text-success');
        cons=true;
    } else {
        $('#consecutivo').removeClass('text-success').addClass('text-danger');
        cons=false;
    }

    if ( pswd.match(/([!@\*\-\?¡¿+\/.,_#])/ )) {
        $('#especial').removeClass('text-danger').addClass('text-success');
        esp=true;
    } else {
        $('#especial').removeClass('text-success').addClass('text-danger');
        esp=false;
    }
    if((longitud==true)&& (mt==true) && (cap==true) && (car==true) &&  (cons==true) && (esp==true)){
        $('#password').removeClass('alert-danger');
        validatePass = true;

        if(validatePass == true && validateConfirm == true && validateActual == true){
            $('#send').removeAttr("disabled").removeClass("disabled");
        }
    }else{
        validatePass = false;
        $('#send').attr("disabled",true).addClass("disabled");
        $('#password').addClass('alert-danger');
    }

});

// validacion para la confirmacion de contraseña
$('#password_confirm').keyup(function () {
    
    if($('#password_confirm').val() == $('#password').val()){
        $('#password_confirm').removeClass('alert-danger');
        $('#error_confirm').attr("hidden",true).text();
        validateConfirm = true;
        
        if(validatePass == true && validateConfirm == true && validateActual == true){
            $('#send').removeAttr("disabled").removeClass("disabled");
        }
        
    }else{
        validateConfirm = false;
        $('#password_confirm').addClass('alert-danger');
        $('#send').attr("disabled",true).addClass("disabled");
        $('#error_confirm').attr("hidden",false).text("New passwords does not match");
    }  
});

// validacion para contraseña actual
$('#actual_password').keyup(function () {
    if($('#actual_password').val()){
        validateActual = true;

        if(validatePass == true && validateConfirm == true && validateActual == true){
            $('#send').removeAttr("disabled").removeClass("disabled");
        }

    }else{
        validateActual = false;
    }
});

});