$(document).ready(function(){
	// Cerrar los formularios
	$('#closeauth1').on('click', function () {
        $('#authform1').fadeOut();
        $('#authform1').removeClass('authActive1');
        $('#showauth1').fadeIn();
        $('#showauth2').fadeOut();
        
        // Resetear todos los campos de esa seccion
        $('#first_name_auth1').val('');
        $('#first_name_auth1').removeClass('alert-danger');
        $('#middle_name_auth1').val('');
        $('#middle_name_auth1').removeClass('alert-danger');
        $('#last_name_auth1').val('');
        $('#last_name_auth1').removeClass('alert-danger');
        $('#second_surname_auth1').val('');
        $('#second_surname_auth1').removeClass('alert-danger');
        $('#national_id_auth1').val('');
        $('#national_id_auth1').removeClass('alert-danger');
        $('#email_address_auth1').val('');
        $('#email_address_auth1').removeClass('alert-danger');
        $('#postal_region_auth1').val('');
        $('#postal_region_auth1').removeClass('alert-danger');
        $('#postal_city_auth1').val('');
        $('#postal_city_auth1').removeClass('alert-danger');
        $('#postal_code_auth1').val('');
        $('#postal_code_auth1').removeClass('alert-danger');
        $('#postal_address1_auth1').val('');
        $('#postal_address1_auth1').removeClass('alert-danger');
        $('#postal_address2_auth1').val('');
        $('#postal_address2_auth1').removeClass('alert-danger');
        $('#telephone_number_auth1').val('');
        $('#telephone_number_auth1').removeClass('alert-danger');
        $('#mobile_number_auth1').val('');
        $('#mobile_number_auth1').removeClass('alert-danger');
        $('#fax_number_auth1').val('');
        $('#fax_number_auth1').removeClass('alert-danger');
    });
	
	$('#closeauth2').on('click', function () {
        $('#authform2').fadeOut();
        $('#authform2').removeClass('authActive2');
        $('#showauth2').fadeIn();
        $('#showauth3').fadeOut();
        $('#closeauth1').fadeIn();
     
        // Resetear todos los campos de esa seccion
        $('#first_name_auth2').val('');
        $('#first_name_auth2').removeClass('alert-danger');
        $('#middle_name_auth2').val('');
        $('#middle_name_auth2').removeClass('alert-danger');
        $('#last_name_auth2').val('');
        $('#last_name_auth2').removeClass('alert-danger');
        $('#second_surname_auth2').val('');
        $('#second_surname_auth2').removeClass('alert-danger');
        $('#national_id_auth2').val('');
        $('#national_id_auth2').removeClass('alert-danger');
        $('#email_address_auth2').val('');
        $('#email_address_auth2').removeClass('alert-danger');
        $('#postal_region_auth2').val('');
        $('#postal_region_auth2').removeClass('alert-danger');
        $('#postal_city_auth2').val('');
        $('#postal_city_auth2').removeClass('alert-danger');
        $('#postal_code_auth2').val('');
        $('#postal_code_auth2').removeClass('alert-danger');
        $('#postal_address1_auth2').val('');
        $('#postal_address1_auth2').removeClass('alert-danger');
        $('#postal_address2_auth2').val('');
        $('#postal_address2_auth2').removeClass('alert-danger');
        $('#telephone_number_auth2').val('');
        $('#telephone_number_auth2').removeClass('alert-danger');
        $('#mobile_number_auth2').val('');
        $('#mobile_number_auth2').removeClass('alert-danger');
        $('#fax_number_auth2').val('');
        $('#fax_number_auth2').removeClass('alert-danger');
    });
	
	$('#closeauth3').on('click', function () {
        $('#authform3').fadeOut();
        $('#authform3').removeClass('authActive3');
        $('#showauth3').fadeIn();
        $('#closeauth2').fadeIn();
     
        // Resetear todos los campos de esa seccion
        $('#first_name_auth3').val('');
        $('#first_name_auth3').removeClass('alert-danger');
        $('#middle_name_auth3').val('');
        $('#middle_name_auth3').removeClass('alert-danger');
        $('#last_name_auth3').val('');
        $('#last_name_auth3').removeClass('alert-danger');
        $('#second_surname_auth3').val('');
        $('#second_surname_auth3').removeClass('alert-danger');
        $('#national_id_auth3').val('');
        $('#national_id_auth3').removeClass('alert-danger');
        $('#email_address_auth3').val('');
        $('#email_address_auth3').removeClass('alert-danger');
        $('#postal_region_auth3').val('');
        $('#postal_region_auth3').removeClass('alert-danger');
        $('#postal_city_auth3').val('');
        $('#postal_city_auth3').removeClass('alert-danger');
        $('#postal_code_auth3').val('');
        $('#postal_code_auth3').removeClass('alert-danger');
        $('#postal_address1_auth3').val('');
        $('#postal_address1_auth3').removeClass('alert-danger');
        $('#postal_address2_auth3').val('');
        $('#postal_address2_auth3').removeClass('alert-danger');
        $('#telephone_number_auth3').val('');
        $('#telephone_number_auth3').removeClass('alert-danger');
        $('#mobile_number_auth3').val('');
        $('#mobile_number_auth3').removeClass('alert-danger');
        $('#fax_number_auth3').val('');
        $('#fax_number_auth3').removeClass('alert-danger');
    
    });
	
	// Mostrar los formularios
	$('#showauth1').on('click', function () {
        $('#authform1').fadeIn();
        $('#authform1').addClass('authActive1');
        $('#first_name_auth1').focus();
        $('#showauth2').fadeIn();
        $('#showauth1').fadeOut();
        
    });
	
	$('#showauth2').on('click', function () {
        $('#authform2').fadeIn();
        $('#authform2').addClass('authActive2');
        $('#first_name_auth2').focus();
        $('#closeauth1').fadeOut();
        $('#showauth3').fadeIn();
        $('#showauth2').fadeOut();
    });
	
	$('#showauth3').on('click', function () {
        $('#authform3').fadeIn();
        $('#authform3').addClass('authActive3');
        $('#first_name_auth3').focus();
        $('#closeauth2').fadeOut();
        $('#showauth3').fadeOut();
    });
	
});