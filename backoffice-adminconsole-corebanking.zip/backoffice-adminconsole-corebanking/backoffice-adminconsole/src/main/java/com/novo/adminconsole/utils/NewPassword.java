package com.novo.adminconsole.utils;

public class NewPassword {

	private String actual_password;
	
	private String user_password;
	
	private String confirm_password;

	public String getUser_password() {
		return user_password;
	}

	public void setUser_password(String user_password) {
		this.user_password = user_password;
	}

	public String getConfirm_password() {
		return confirm_password;
	}

	public void setConfirm_password(String confirm_password) {
		this.confirm_password = confirm_password;
	}

	public String getActual_password() {
		return actual_password;
	}

	public void setActual_password(String actual_password) {
		this.actual_password = actual_password;
	}

}
