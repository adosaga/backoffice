package com.novo.adminconsole.models.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.novo.adminconsole.models.dao.IRoleDao;
import com.novo.adminconsole.models.entity.Role;
import com.novo.adminconsole.models.entity.UserRole;

@Repository
public class RoleDaoImpl implements IRoleDao {

	@PersistenceContext
	private EntityManager entityManager;
	
	private final Logger log = Logger.getLogger(RoleDaoImpl.class);
	
	@Override
	public String getRoleName(String userId) {
		// Buscar rol del usuario
		log.info("Buscando rol del usuario");
		
		String sql = "Select R.roleName from " + UserRole.class.getName() + " RN, " +  Role.class.getName() + " R where R.id = RN.roleId and RN.userId.id = :userId and RN.roleStatus.statusId = '9'";
		Query query = this.entityManager.createQuery(sql, String.class);
		query.setParameter("userId", userId);
		
		return (String) query.getSingleResult();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Role> getRoleList() {
		//Buscar todos los roles
		log.info("Buscando roles");
		
		//String sql = "Select R from " + Role.class.getName() + " R where NOT R.roleName = 'ROLE_MASTER'";
		String sql = "Select R from " + Role.class.getName() + " R where R.roleStatus.statusId = '9'";
		Query query = this.entityManager.createQuery(sql, Role.class);
		
		return (List<Role>) query.getResultList();
	}

	@Override
	public Role getRole(String roleId) {
		
		log.info("Buscando rol por id");
		
		String sql = "Select R from " + Role.class.getName() + " R where R.id = :roleId and R.roleStatus.statusId = '9'";
		Query query = this.entityManager.createQuery(sql, Role.class);
		query.setParameter("roleId", roleId);
		
		return (Role) query.getSingleResult();
	}

	@Override
	public String getRoleId(String userId) {
				
		String sql = "Select R.id from " + UserRole.class.getName() + " RN, " +  Role.class.getName() + " R where R.id = RN.roleId and RN.userId.id = :userId and RN.roleStatus.statusId = '9'";
		Query query = this.entityManager.createQuery(sql, String.class);
		query.setParameter("userId", userId);
				
		return (String) query.getSingleResult();
	}

	@Override
	public UserRole findDisabledRole(String userId) {
		log.info("Buscando usuario con rol inactivo");
		
		try {
			String sql = "Select RN from " + UserRole.class.getName() + " RN where RN.roleStatus.statusId = '11' and RN.userId.id = :userId";
			Query query = this.entityManager.createQuery(sql, UserRole.class);
			query.setParameter("userId", userId);
			
			return (UserRole) query.getSingleResult();
		} catch (NoResultException e) {
			log.info("error: " + e);
			
			return null;
		}	
	}
}
