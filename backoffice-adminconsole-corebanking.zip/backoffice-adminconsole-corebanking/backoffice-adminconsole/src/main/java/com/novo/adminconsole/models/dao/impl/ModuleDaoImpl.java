package com.novo.adminconsole.models.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.novo.adminconsole.models.dao.IModuleDao;
import com.novo.adminconsole.models.entity.AdmconsModules;

@Repository
public class ModuleDaoImpl implements IModuleDao{

	@PersistenceContext
	private EntityManager entityManager;
	
	private final Logger log = Logger.getLogger(ModuleDaoImpl.class);
	
	@SuppressWarnings("unchecked")
	@Override
	public List<String> getDisabledModules() {
		
		log.info("Obteniendo modulos para configurar menu");
		String sql = "Select M.name from " + AdmconsModules.class.getName() + " M where M.moduleStatus = '4'";
		Query query = entityManager.createQuery(sql, String.class);
		
		return (List<String>) query.getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getEnabledModules(String roleId) {
		
		String sql = "SELECT" +
					 " M.MODULE_NAME," + 
					 " M.MODULE_CODE" + 
					 " FROM ADMCONS_MODULES M" +
					 " INNER       JOIN ADMCONS_FUNCTIONS F" +
					 " ON          M.MODULE_CODE=F.MODULE_ID" +
					 " INNER JOIN  ADMCONS_ACCESS A" +
					 " ON          F.FUNCTION_ID=A.FUNCTION_ID" +
					 " WHERE       A.ROLE_ID= :roleId" +
					 " AND         M.MODULE_STATUS='1'" +
					 " AND         F.FUNCTION_STATUS='9'" +
					 " GROUP BY    M.MODULE_CODE,M.MODULE_NAME";
		
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter("roleId", roleId);
		
		return (List<Object[]>) query.getResultList();
	}

	@Override
	public List<Object[]> getListModules(String roleId) {
		String sql = "select b.module_name,b.module_code from\n" +
				"(SELECT\n" +
				"M.MODULE_NAME, \n" +
				"M.MODULE_CODE \n" +
				"FROM ADMCONS_MODULES M\n" +
				"INNER       JOIN ADMCONS_FUNCTIONS F\n" +
				"ON          M.MODULE_CODE=F.MODULE_ID\n" +
				"INNER JOIN  ADMCONS_ACCESS A\n" +
				"ON          F.FUNCTION_ID=A.FUNCTION_ID\n" +
				"WHERE       A.ROLE_ID= :roleId\n" +
				"AND         M.MODULE_STATUS='1'\n" +
				"AND         F.FUNCTION_STATUS='9'\n" +
				"GROUP BY    M.MODULE_CODE,M.MODULE_NAME\n" +
				"UNION SELECT 'LOGIN','' FROM DUAL) b order by b.module_name ASC";

		Query query = entityManager.createNativeQuery(sql);
		query.setParameter("roleId", roleId);
		return (List<Object[]>) query.getResultList();
	}
}
