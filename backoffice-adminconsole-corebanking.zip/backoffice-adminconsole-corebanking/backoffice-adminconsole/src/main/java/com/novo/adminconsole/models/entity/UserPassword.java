package com.novo.adminconsole.models.entity;

import java.io.Serializable;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "ADMCONS_USER_PASSWORDS")	
public class UserPassword implements Serializable{

	private static final long serialVersionUID = 1L;

	  @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "PASS_ID")
    private BigDecimal passId;

	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="User_Id", referencedColumnName="User_Id", foreignKey = @ForeignKey(name = "FK_USER_PASS_ID"), nullable = false)
	private UserApp userId;
	
	@Column(name = "User_Password", nullable=false, length=50)
	private String userPassword;
	
	@Column(nullable=false)
	private int attempts = 0;
	
	//Password Status Code
	@JoinColumn(name = "PASSW_STATUS", referencedColumnName = "STATUS_ID")
    @ManyToOne
    private AdmconsStatus passwStatus;
	
	//User Status Code
	// 0 - Deleted
	// 1 - Enable
	// 2 - Updated
	// 3 - Locked
	// 4 - Disable
	@JoinColumn(name = "USER_STATUS", referencedColumnName = "STATUS_ID")
    @ManyToOne
    private AdmconsStatus userStatus;

    @Column(name = "FROM_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date fromDate;
	
    @Column(name = "TO_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date toDate;
	
	public UserApp getUserId() {
		return userId;
	}

	public void setUserId(UserApp userId) {
		this.userId = userId;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public int getAttempts() {
		return attempts;
	}

	public void setAttempts(int attempts) {
		this.attempts = attempts;
	}

	public BigDecimal getPassId() {
		return passId;
	}

	public void setPassId(BigDecimal passId) {
		this.passId = passId;

	}

	public AdmconsStatus getPasswStatus() {
		return passwStatus;
	}

	public void setPasswStatus(AdmconsStatus passwStatus) {
		this.passwStatus = passwStatus;
	}

	public AdmconsStatus getUserStatus() {
		return userStatus;
	}

	public void setUserStatus(AdmconsStatus userStatus) {
		this.userStatus = userStatus;
	}

	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public Date getToDate() {
		return toDate;
	}

	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

	
	

}
