package com.novo.adminconsole.models.dao;


import com.novo.adminconsole.TO.ResponseTO;
import com.novo.adminconsole.models.entity.*;
import com.novo.adminconsole.utils.NewUser;

import java.util.List;

public interface IUserDao {

	// Buscar por username
	public UserApp findByUsername(String userName);
	
	// Buscar por email
	public UserApp findByEmail(String email);
	
	// Buscar por nationalId
	public UserApp findByNationalId(String nationalId);
	
	// Encontrar el branch_id del usuario
	public AdmconsUserBranchOffice findBranchId(String username);
	
	// Encontrar el issuer_id del usuario 
	public AdmconsBranchOffices findIssuerId(String branchId);
		
	//Insertar usuario nuevo en tabla Users
	public ResponseTO saveUser(NewUser user);
	
	//Insertar usuario nuevo en tabla User_Roles
	public ResponseTO saveUserRoles(Role rol, UserApp user);
	
	//Insertar usuario nuevo en tabla User_Passwords
	public ResponseTO saveUserPassword(UserApp userApp, String password);
	
	// Insertar nueva password deshabilitada
	public ResponseTO saveDisableUserPassword(UserApp userApp, String password);
	
	// Insertar nueva password deshabilitada
	public ResponseTO changeUserPassword(UserApp userApp, String password);
	
	//Insertar usuario nuevo en tabla User_BranchOffice
	public ResponseTO saveUserBranchOffice(UserApp userApp, AdmconsBranchOffices branchOffice);
	
	public ResponseTO editUser(NewUser user);
		
	public ResponseTO editUserRoles(Role rol, UserApp user);
		
	public ResponseTO editUserBranchOffice(UserApp userApp, AdmconsBranchOffices branchOffice);
	
	//Cambiar status de usuario a borrado
	public ResponseTO deleteUser(String username);
	
	//Cambiar status de rol a borrado
	public ResponseTO deleteUserRoles(String username);
	
	//Cambiar status de password
	public ResponseTO deleteUserPassword(String username);
	
	//Cambiar status de branch_office
	public ResponseTO deleteUserBranchOffice(String username);
	
	// Buscar lista de sucursales
	public List<AdmconsBranchOffices> getBranchOfficeList();
	
	// Buscar lista de emisores
	public List<AdmconsIssuers> getIssuerList();
	
	public List<Object[]> getUserList();

	public List<Object[]> getUsers();
	
	public AdmconsBranchOffices getBranchOffice(String branchId);
	
	public UserApp findBlockedUserAccess(String username);
	
	public ResponseTO blockUserAccess(String username);
	
	public ResponseTO unblockUserAccess(String username);
	
	// Guardar eventos del usuario
	public void saveEvent(String username, String eventId, String observation, String rc);

	public List<Object[]> getFinalUsersDetail(String tagpay);

	public List<Object[]> getEmailsUser(String tagpay);

	public List<Object[]> getPhonesUser(String tagpay);

	public List<Object[]> getDeviceUser(String tagpay);

	public Object getStatusUser(String status, String column);

}
