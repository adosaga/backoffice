package com.novo.adminconsole.models.dao.impl;


import java.util.Date;
import java.util.List;


import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;



import org.apache.log4j.Logger;



import org.springframework.stereotype.Repository;



import com.novo.adminconsole.models.dao.IUserPassDao;
import com.novo.adminconsole.models.entity.AdmconsStatus;
import com.novo.adminconsole.models.entity.UserApp;
import com.novo.adminconsole.models.entity.UserPassword;

@Repository
public class UserPassDaoImpl implements IUserPassDao {

	@PersistenceContext
	private EntityManager entityManager;
	
	private final Logger log = Logger.getLogger(UserPassDaoImpl.class);
	
	@Override
	public UserPassword findNoBlocked(String id) {
		
		log.info("Buscando usuarios no bloqueados");
		// Encontrar el usuario en la tabla UserPassword
		try {
		String sql = "SELECT u FROM " + UserPassword.class.getName() + " u WHERE u.userId.id = :id AND u.userStatus.statusId = '1' AND u.passwStatus.statusId = '1'";
		Query query = this.entityManager.createQuery(sql, UserPassword.class);
		query.setParameter("id", id);
		
		return (UserPassword) query.getSingleResult();
		} catch (NoResultException e) {
			log.info("error: " + e);
			return null;
		}
		
	}
	
	@Override
	public UserPassword findBlocked(String id) {
		
		log.info("Buscando usuarios bloqueados");
		// Encontrar el usuario en la tabla UserPassword
		try {

			String sql = "SELECT u FROM " + UserPassword.class.getName() + " u WHERE (u.userId.id = :id AND u.passwStatus.statusId = '3') OR (u.userId.id = :id AND u.userStatus.statusId = '3')";
			Query query = this.entityManager.createQuery(sql, UserPassword.class);
			query.setParameter("id", id);
			
			return (UserPassword) query.getSingleResult();
			} catch (Exception e) {
				log.info("error: " + e);
				return null;
		}
	}
	
	@Override
	public UserPassword findDisabledPassword(String id) {
		
		log.info("Buscando usuarios deshabilitados");
		// Encontrar el usuario en la tabla UserPassword
		try {
			String sql = "SELECT u FROM " + UserPassword.class.getName() + " u WHERE u.userId.id = :id AND u.passwStatus.statusId = '4'";

			Query query = this.entityManager.createQuery(sql, UserPassword.class);
			query.setParameter("id", id);
			
			return (UserPassword) query.getSingleResult();
			} catch (Exception e) {
				log.info("error: " + e);
				return null;
		}
	}
	

	@Override
	public void saveBlocked(UserApp us, String password) {
		
		//Almacenar en la tabla el usuario y sus intentos
		log.info("Almacenando usuario nuevo con intentos nuevos");
		
		AdmconsStatus statusPass = new AdmconsStatus();
		statusPass.setStatusId("1");
		AdmconsStatus statusUsr = new AdmconsStatus();
		statusUsr.setStatusId("1");
		
		Date now = new Date();
		
		UserPassword userPass = new UserPassword();
		userPass.setUserId(us);
		userPass.setUserPassword(password);
		userPass.setAttempts(1);
		userPass.setPasswStatus(statusPass);
		userPass.setUserStatus(statusUsr);
		userPass.setFromDate(now);
		userPass.setToDate(now);
		
		try {
			
			entityManager.persist(userPass);
			log.info("Usuario insertado en la bd");
		} catch (Exception e) {
			
			log.info("error: " + e);
			
		}
		
	}

	@Override
	public void unlockBlocked(String id) {
		// Reiniciar el contador si el usuario ingresa satisfactoriamente
		log.info("Reiniciando intentos de usuario " + id);
		try {
			String sql = "UPDATE ADMCONS_USER_PASSWORDS SET attempts = 0 WHERE User_Id = :id AND user_status = '1' AND passw_status = '1'";
			Query query = entityManager.createNativeQuery(sql);
			query.setParameter("id", id);
			query.executeUpdate();
			
		} catch (Exception e) {
			log.info("error: " + e);
		}
		
	}

	@Override
	public void updateBlocked(String id, int value) {
		log.info("Aumentanto el numero de intentos " + id);
		// Aumentar el valor del numero de intentos
		try {
			String sql = "UPDATE ADMCONS_USER_PASSWORDS SET attempts = :value WHERE User_Id = :id AND user_status = '1' AND passw_status = '1'";
			Query query = entityManager.createNativeQuery(sql);
			query.setParameter("value", value);
			query.setParameter("id", id);
			query.executeUpdate();
			
		} catch (Exception e) {
			log.info("error: " + e);
		}
		
	}

	@Override
	public void blockUser(String id, int max) {
		// Bloquear usaurio
		log.info("Bloqueando usuario " + id);
		Date now = new Date();
		try {
			String sql = "UPDATE ADMCONS_USER_PASSWORDS SET attempts = :max, user_status = '3', passw_status = '3', TO_DATE = :toDate WHERE User_Id = :id AND user_status = '1' AND passw_status = '1'";
			Query query = entityManager.createNativeQuery(sql);
			query.setParameter("max", max);
			query.setParameter("id", id);
			query.setParameter("toDate", now);
			query.executeUpdate();
			
		} catch (Exception e) {
			log.info("error: " + e);
		}
			
	}

	@Override
	public UserPassword findPassword(String id) {
		// Buscando pass de usuario
		log.info("Buscando password de usuario " + id);
		try {
			String sql = "SELECT u FROM " + UserPassword.class.getName() + " u WHERE u.userId.id = :id AND u.userStatus.statusId = '1' AND u.passwStatus.statusId = '1'";
			Query query = entityManager.createQuery(sql);
			query.setParameter("id", id);
			
			return (UserPassword) query.getSingleResult();
			
		} catch (Exception e) {
			log.info("error: " + e);
			return null;
		}
	}

	@Override
	public void disablePassword(String id) {
		// Deshabilitando password
		log.info("Deshabilitando password de usuario " + id);
		
		Date now = new Date();
		try {
			String sql = "UPDATE ADMCONS_USER_PASSWORDS SET attempts = :max, user_status = '4', passw_status = '4', TO_DATE = :toDate WHERE User_Id = :id AND user_status = '1' AND passw_status = '1'";
			Query query = entityManager.createNativeQuery(sql);
			//query.setParameter("max", max);
			query.setParameter("id", id);
			query.setParameter("toDate", now);
			query.executeUpdate();
			
		} catch (Exception e) {
			log.info("error: " + e);
		}
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> lastPasswords(String username, int rows) {
		// Buscando ultimas 3 pass
		log.info("Buscando ultimas 3 contraseñas de " + username);
		
		try {
			String sql = "SELECT USER_ID,USER_PASSWORD, FROM_DATE" + 
				    " FROM (SELECT USER_ID, USER_PASSWORD, FROM_DATE" +
				        " FROM ADMCONS_USER_PASSWORDS" +
				        " WHERE  USER_ID = :username" +
				        " ORDER BY FROM_DATE DESC)" +
				    " WHERE ROWNUM < :rows";
			/*
			String sql = "SELECT USER_ID, USER_PASSWORD, MAX(FROM_DATE) AS FECHA" + 
					" FROM ADMCONS_USER_PASSWORDS" + 
					" WHERE USER_ID = :username" + 
					" GROUP BY USER_ID,USER_PASSWORD ORDER BY FECHA DESC";*/
			
			Query query = entityManager.createNativeQuery(sql);
			query.setParameter("username", username);
			query.setParameter("rows", rows);
			
			return (List<Object[]>) query.getResultList();
			
		} catch (Exception e) {
			
			log.info("Error: " + e); 
			return null;
		}	
	}


}
