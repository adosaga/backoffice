package com.novo.adminconsole.models.service.impl;

import static com.novo.adminconsole.utils.Constants.PROPERTIES_FILE;

import java.util.Properties;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;
import com.novo.adminconsole.TO.ResponseAccessTO;
import com.novo.adminconsole.TO.ResponseModFuncTO;
import com.novo.adminconsole.TO.ResponseRoleAssocTO;
import com.novo.adminconsole.TO.ResponseRoleTO;
import com.novo.adminconsole.config.TokenOauth;
import com.novo.adminconsole.models.service.IRoleService;
import com.novo.adminconsole.utils.Role;
import com.novo.adminconsole.utils.RoleAssoc;
import com.novo.adminconsole.utils.Utils;

@Service
public class RoleServiceImpl implements IRoleService {

	private final Logger log = Logger.getLogger(RoleServiceImpl.class);

	@Autowired
	private TokenOauth tokenOauth;

	@Override
	public ResponseEntity<ResponseRoleTO> listarRoles() {
		
		log.info("listarRoles");

		Properties properties = Utils.getConfig(PROPERTIES_FILE);
		String countryHeader = properties.getProperty("country_header");
		String urlListRole = properties.getProperty("app.api.role.list");

		// get access token
		String accessTokn = tokenOauth.getRefreshedToken();

		if (accessTokn != null) {

			// request Headers
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.add("x-country", countryHeader);
			headers.add("Authorization", "Bearer " + accessTokn);

			// request Data
			HttpEntity<ResponseRoleTO> requestBody = new HttpEntity<ResponseRoleTO>(headers);

			try {
				RestTemplate restTemplate = new RestTemplate();
				return restTemplate.exchange(urlListRole, HttpMethod.GET, requestBody, ResponseRoleTO.class);
			} catch (RestClientException re) {

				log.error("Error llamando al API: " + re);
				return new ResponseEntity<ResponseRoleTO>(HttpStatus.CONFLICT);
			}

		} else {
			log.error("Access token is null");
			return new ResponseEntity<ResponseRoleTO>(HttpStatus.CONFLICT);
		}
	}

	@Override
	public ResponseEntity<ResponseRoleTO> crearRol(Role role) {

		log.info("crearRol");
		
		Properties properties = Utils.getConfig(PROPERTIES_FILE);
		String countryHeader = properties.getProperty("country_header");
		String urlCreateRole = properties.getProperty("app.api.role.create");

		// get access token
		String accessTokn = tokenOauth.getRefreshedToken();

		if (accessTokn != null) {

			// get Headers
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.add("x-country", countryHeader);
			headers.add("Authorization", "Bearer " + accessTokn);

			role.setRoleStatus("9");

			// request Data
			HttpEntity<Role> requestBody = new HttpEntity<>(role, headers);

			try {
				RestTemplate restTemplate = new RestTemplate();
				return restTemplate.exchange(urlCreateRole, HttpMethod.POST, requestBody, ResponseRoleTO.class);
			} catch (RestClientException re) {

				log.error("Error llamando al API: " + re);
				return new ResponseEntity<ResponseRoleTO>(HttpStatus.CONFLICT);
			}
		} else {
			log.error("Access token is null");
			return new ResponseEntity<ResponseRoleTO>(HttpStatus.CONFLICT);
		}
	}

	@Override
	public ResponseEntity<ResponseRoleTO> obtenerRol(Role role) {

		log.info("obtenerRol");
		
		Properties properties = Utils.getConfig(PROPERTIES_FILE);
		String countryHeader = properties.getProperty("country_header");
		String urlGetRole = properties.getProperty("app.api.role.getone");

		// Obteniendo el access token
		String accessTokn = tokenOauth.getRefreshedToken();

		if (accessTokn != null) {

			// request Headers
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.add("x-country", countryHeader);
			headers.add("Authorization", "Bearer " + accessTokn);

			// request Data
			HttpEntity<ResponseRoleTO> requestBody = new HttpEntity<ResponseRoleTO>(headers);

			try {
				RestTemplate restTemplate = new RestTemplate();
				return restTemplate.exchange(urlGetRole, HttpMethod.GET, requestBody, ResponseRoleTO.class,
						role.getRoleId());
			} catch (RestClientException re) {

				log.error("Error llamando al API: " + re);
				return new ResponseEntity<ResponseRoleTO>(HttpStatus.CONFLICT);
			}
		} else {
			log.error("Access token is null");
			return new ResponseEntity<ResponseRoleTO>(HttpStatus.CONFLICT);
		}
	}

	@Override
	public ResponseEntity<ResponseRoleTO> editarRol(Role role) {
		
		log.info("editarRol");

		Properties properties = Utils.getConfig(PROPERTIES_FILE);
		String countryHeader = properties.getProperty("country_header");
		String urlEditRole = properties.getProperty("app.api.role.edit");

		// get access token
		String accessTokn = tokenOauth.getRefreshedToken();

		if (accessTokn != null) {

			// request Headers
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.add("x-country", countryHeader);
			headers.add("Authorization", "Bearer " + accessTokn);

			role.setRoleStatus("9");

			// request Data
			HttpEntity<Role> requestBody = new HttpEntity<>(role, headers);

			try {
				RestTemplate restTemplate = new RestTemplate();
				return restTemplate.exchange(urlEditRole, HttpMethod.PUT, requestBody, ResponseRoleTO.class);
			} catch (RestClientException re) {

				log.error("Error llamando al API: " + re);
				return new ResponseEntity<ResponseRoleTO>(HttpStatus.CONFLICT);
			}

		} else {
			log.error("Access token is null");
			return new ResponseEntity<ResponseRoleTO>(HttpStatus.CONFLICT);
		}
	}

	@Override
	public ResponseEntity<ResponseRoleTO> activarRol(Role role) {
		
		log.info("activarRol");

		Properties properties = Utils.getConfig(PROPERTIES_FILE);
		String countryHeader = properties.getProperty("country_header");
		String urlStatusRole = properties.getProperty("app.api.role.status");

		// get access token
		String accessTokn = tokenOauth.getRefreshedToken();

		if (accessTokn != null) {

			// request Headers
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.add("x-country", countryHeader);
			headers.add("Authorization", "Bearer " + accessTokn);

			// request Data
			HttpEntity<Role> requestBody = new HttpEntity<>(role, headers);

			try {
				RestTemplate restTemplate = new RestTemplate();
				return restTemplate.exchange(urlStatusRole, HttpMethod.PUT, requestBody, ResponseRoleTO.class);
			} catch (RestClientException re) {

				log.error("Error llamando al API: " + re);
				return new ResponseEntity<ResponseRoleTO>(HttpStatus.CONFLICT);
			}
		} else {
			log.error("Access token is null");
			return new ResponseEntity<ResponseRoleTO>(HttpStatus.CONFLICT);
		}
	}

	@Override
	public ResponseEntity<ResponseRoleTO> desactivarRol(Role role) {
		
		log.info("desactivarRol");

		Properties properties = Utils.getConfig(PROPERTIES_FILE);
		String countryHeader = properties.getProperty("country_header");
		String urlStatusRole = properties.getProperty("app.api.role.status");

		// get access token
		String accessTokn = tokenOauth.getRefreshedToken();

		if (accessTokn != null) {

			// request Headers
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.add("x-country", countryHeader);
			headers.add("Authorization", "Bearer " + accessTokn);

			// request Data
			HttpEntity<Role> requestBody = new HttpEntity<>(role, headers);

			try {
				RestTemplate restTemplate = new RestTemplate();
				return restTemplate.exchange(urlStatusRole, HttpMethod.PUT, requestBody, ResponseRoleTO.class);
			} catch (RestClientException re) {

				log.error("Error llamando al API: " + re);
				return new ResponseEntity<ResponseRoleTO>(HttpStatus.CONFLICT);
			}
		} else {
			log.error("Access token is null");
			return new ResponseEntity<ResponseRoleTO>(HttpStatus.CONFLICT);
		}
	}

	@Override
	public ResponseEntity<ResponseRoleAssocTO> listarAsociados(String roleId) {
		
		log.info("listarAsociados");

		Properties properties = Utils.getConfig(PROPERTIES_FILE);
		String countryHeader = properties.getProperty("country_header");
		String urlListAssocRole = properties.getProperty("app.api.role.listassoc");

		// get access token
		String accessTokn = tokenOauth.getRefreshedToken();

		if (accessTokn != null) {

			// request Headers
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.add("x-country", countryHeader);
			headers.add("Authorization", "Bearer " + accessTokn);

			// request Data
			HttpEntity<ResponseRoleTO> requestBody = new HttpEntity<ResponseRoleTO>(headers);

			try {
				RestTemplate restTemplate = new RestTemplate();
				return restTemplate.exchange(urlListAssocRole, HttpMethod.GET, requestBody, ResponseRoleAssocTO.class,
						roleId);
			} catch (RestClientException re) {

				log.error("Error llamando al API: " + re);
				return new ResponseEntity<ResponseRoleAssocTO>(HttpStatus.CONFLICT);
			}
		} else {
			log.error("Access token is null");
			return new ResponseEntity<ResponseRoleAssocTO>(HttpStatus.CONFLICT);
		}
	}

	@Override
	public ResponseEntity<ResponseRoleAssocTO> asociarPermisos(RoleAssoc roleAssoc) {
		
		log.info("asociarPermisos");

		Properties properties = Utils.getConfig(PROPERTIES_FILE);
		String countryHeader = properties.getProperty("country_header");
		String urlAssociate = properties.getProperty("app.api.role.associate");

		// get access token
		String accessTokn = tokenOauth.getRefreshedToken();

		if (accessTokn != null) {

			// request Headers
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.add("x-country", countryHeader);
			headers.add("Authorization", "Bearer " + accessTokn);

			// request Data
			HttpEntity<RoleAssoc> requestBody = new HttpEntity<>(roleAssoc, headers);

			try {
				RestTemplate restTemplate = new RestTemplate();
				return restTemplate.exchange(urlAssociate, HttpMethod.POST, requestBody, ResponseRoleAssocTO.class);
			} catch (RestClientException re) {

				log.error("Error llamando al API: " + re);
				return new ResponseEntity<ResponseRoleAssocTO>(HttpStatus.CONFLICT);
			}

		} else {
			log.error("Access token is null");
			return new ResponseEntity<ResponseRoleAssocTO>(HttpStatus.CONFLICT);
		}
	}

	@Override
	public ResponseEntity<ResponseRoleAssocTO> activarAsociacion(RoleAssoc roleAssoc) {
		
		log.info("activarAsociacion");

		Properties properties = Utils.getConfig(PROPERTIES_FILE);
		String countryHeader = properties.getProperty("country_header");
		String urlStatusAssoc = properties.getProperty("app.api.role.associate.status");

		// get access token
		String accessTokn = tokenOauth.getRefreshedToken();

		if (accessTokn != null) {

			// request Headers
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.add("x-country", countryHeader);
			headers.add("Authorization", "Bearer " + accessTokn);

			// request Data
			HttpEntity<RoleAssoc> requestBody = new HttpEntity<>(roleAssoc, headers);

			try {
				RestTemplate restTemplate = new RestTemplate();
				return restTemplate.exchange(urlStatusAssoc, HttpMethod.PUT, requestBody, ResponseRoleAssocTO.class);
			} catch (RestClientException re) {

				log.error("Error llamando al API: " + re);
				return new ResponseEntity<ResponseRoleAssocTO>(HttpStatus.CONFLICT);
			}
		} else {
			log.error("Access token is null");
			return new ResponseEntity<ResponseRoleAssocTO>(HttpStatus.CONFLICT);
		}
	}

	@Override
	public ResponseEntity<ResponseRoleAssocTO> desactivarAsociacion(RoleAssoc roleAssoc) {
		
		log.info("desactivarAsociacion");

		Properties properties = Utils.getConfig(PROPERTIES_FILE);
		String countryHeader = properties.getProperty("country_header");
		String urlStatusAssoc = properties.getProperty("app.api.role.associate.status");

		// get access token
		String accessTokn = tokenOauth.getRefreshedToken();

		if (accessTokn != null) {

			// request Headers
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.add("x-country", countryHeader);
			headers.add("Authorization", "Bearer " + accessTokn);

			// request Data
			HttpEntity<RoleAssoc> requestBody = new HttpEntity<>(roleAssoc, headers);

			try {
				RestTemplate restTemplate = new RestTemplate();
				return restTemplate.exchange(urlStatusAssoc, HttpMethod.PUT, requestBody, ResponseRoleAssocTO.class);
			} catch (RestClientException re) {

				log.error("Error llamando al API: " + re);
				return new ResponseEntity<ResponseRoleAssocTO>(HttpStatus.CONFLICT);
			}
		} else {
			log.error("Access token is null");
			return new ResponseEntity<ResponseRoleAssocTO>(HttpStatus.CONFLICT);
		}
	}

	@Override
	public ResponseEntity<ResponseAccessTO> obtenerPermisos(String roleId, String moduleId) {
		
		log.info("obtenerPermisos");

		Properties properties = Utils.getConfig(PROPERTIES_FILE);
		String countryHeader = properties.getProperty("country_header");
		String urlAccess = properties.getProperty("app.api.role.access");

		// get access token
		String accessTokn = tokenOauth.getRefreshedToken();

		if (accessTokn != null) {

			// request Headers
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.add("x-country", countryHeader);
			headers.add("Authorization", "Bearer " + accessTokn);

			// request Data
			HttpEntity<ResponseAccessTO> requestBody = new HttpEntity<ResponseAccessTO>(headers);

			try {
				RestTemplate restTemplate = new RestTemplate();
				return restTemplate.exchange(urlAccess, HttpMethod.GET, requestBody, ResponseAccessTO.class, roleId,
						moduleId);
			} catch (RestClientException re) {

				log.error("Error llamando al API: " + re);
				return new ResponseEntity<ResponseAccessTO>(HttpStatus.CONFLICT);
			}
		} else {
			log.error("Access token is null");
			return new ResponseEntity<ResponseAccessTO>(HttpStatus.CONFLICT);
		}
	}

	@Override
	public ResponseEntity<ResponseModFuncTO> obtenerModulosyFunciones() {
		
		log.info("obtenerModulosyFunciones");

		Properties properties = Utils.getConfig(PROPERTIES_FILE);
		String countryHeader = properties.getProperty("country_header");
		String urlModFunc = properties.getProperty("app.api.role.modulesfunc");

		/// get access token
		String accessTokn = tokenOauth.getRefreshedToken();

		if (accessTokn != null) {

			// request Headers
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.add("x-country", countryHeader);
			headers.add("Authorization", "Bearer " + accessTokn);

			// request Data
			HttpEntity<ResponseModFuncTO> requestBody = new HttpEntity<ResponseModFuncTO>(headers);

			try {
				RestTemplate restTemplate = new RestTemplate();
				return restTemplate.exchange(urlModFunc, HttpMethod.GET, requestBody, ResponseModFuncTO.class);
			} catch (RestClientException re) {

				log.error("Error llamando al API: " + re);
				return new ResponseEntity<ResponseModFuncTO>(HttpStatus.CONFLICT);
			}
		} else {
			log.error("Access token is null");
			return new ResponseEntity<ResponseModFuncTO>(HttpStatus.CONFLICT);
		}
	}

	@Override
	public ResponseEntity<ResponseAccessTO> obtenerPermisosModulos(RoleAssoc roleAssoc) {
		
		log.info("obtenerPermisosModulos");

		Properties properties = Utils.getConfig(PROPERTIES_FILE);
		String countryHeader = properties.getProperty("country_header");
		String urlModuleAccess = properties.getProperty("app.api.role.moduleaccess");

		// get access token
		String accessTokn = tokenOauth.getRefreshedToken();

		if (accessTokn != null) {

			// request Headers
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.add("x-country", countryHeader);
			headers.add("Authorization", "Bearer " + accessTokn);

			// request Data
			HttpEntity<RoleAssoc> requestBody = new HttpEntity<>(roleAssoc, headers);

			try {
				RestTemplate restTemplate = new RestTemplate();
				return restTemplate.exchange(urlModuleAccess, HttpMethod.POST, requestBody, ResponseAccessTO.class);
			} catch (RestClientException re) {

				log.error("Error llamando al API: " + re);
				return new ResponseEntity<ResponseAccessTO>(HttpStatus.CONFLICT);
			}
		} else {
			log.error("Access token is null");
			return new ResponseEntity<ResponseAccessTO>(HttpStatus.CONFLICT);
		}
	}

}
