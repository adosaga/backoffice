package com.novo.adminconsole.models.service;

import org.springframework.http.ResponseEntity;

import com.novo.adminconsole.TO.ResponseAccessTO;
import com.novo.adminconsole.TO.ResponseModFuncTO;
import com.novo.adminconsole.TO.ResponseRoleAssocTO;
import com.novo.adminconsole.TO.ResponseRoleTO;
import com.novo.adminconsole.utils.Role;
import com.novo.adminconsole.utils.RoleAssoc;


public interface IRoleService {

	public ResponseEntity<ResponseRoleTO> listarRoles();
	
	public ResponseEntity<ResponseRoleTO> crearRol(Role role);
	
	public ResponseEntity<ResponseRoleTO> obtenerRol(Role role);
	
	public ResponseEntity<ResponseRoleTO> editarRol(Role role);
	
	public ResponseEntity<ResponseRoleTO> activarRol(Role role);
	
	public ResponseEntity<ResponseRoleTO> desactivarRol(Role role);
	
	public ResponseEntity<ResponseRoleAssocTO> listarAsociados(String roleId);
	
	public ResponseEntity<ResponseRoleAssocTO> asociarPermisos(RoleAssoc roleAssoc);
	
	public ResponseEntity<ResponseRoleAssocTO> activarAsociacion(RoleAssoc roleAssoc);
	
	public ResponseEntity<ResponseRoleAssocTO> desactivarAsociacion(RoleAssoc roleAssoc);
	
	public ResponseEntity<ResponseAccessTO> obtenerPermisos(String roleId, String moduleId);
	
	public ResponseEntity<ResponseModFuncTO> obtenerModulosyFunciones();
	
	public ResponseEntity<ResponseAccessTO> obtenerPermisosModulos(RoleAssoc roleAssoc);
	
}
