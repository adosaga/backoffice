package com.novo.adminconsole.utils;

public interface Constants {
	
	 String PROPERTIES_FILE = "AdminConsole_zenus.properties";
	
	 String ACCESO_GENERAL = "'91'";   // REPORT_MODULE_ID, PARAMETER_MODULE_ID, CONFIG_MODULE_ID
	
	 String REPORT_MODULE_ID = "8";
	 //Eventos de modulo de reportes
	 String GENERAR_REPORTE_ID = "'38'";
	 
	 String ONBOARDING_MODULE_ID="37";
	 
	 String GENERAL_PARAMETER_MODULE_ID = "9";
	 String PARAMETER_MODULE_ID = "28";
	 
	 //Eventos de modulo de parametros
	 String LISTAR_PARAMETRO_ID = "'15'";
	 String OBTENER_PARAMETRO_ID = "'16'"; 
	 String CREAR_PARAMETRO_ID = "'17'";
	 String EDITAR_PARAMETRO_ID = "'18'"; 
	 String ACTIVAR_PARAMETRO_ID = "'19'"; 
	 String DESACTIVAR_PARAMETRO_ID = "'20'"; 
	 String ELIMINAR_PARAMETRO_ID = "'21'";
	 
	 
	 
	 String CONFIG_MODULE_ID = "11";
	
	 String CONFIG_ROL_MODULE_ID = "13";
	 //Eventos de modulo de usuario
	 String LISTAR_ROLES_ID = "'95'";
	 String CREAR_ROLES_ID = "'97'";
	 String OBTENER_ROLES_ID = "'96'";
	 String EDITAR_ROLES_ID = "'98'"; 
	 String ACTIVAR_ROLES_ID = "'99'";
	 String DESACTIVAR_ROLES_ID = "'100'"; 
	 String ASOCIAR_PERMISO_ROLES_ID = "'101'";
	 String ACTIVAR_PERMISO_ROLES_ID = "'102'";
	 String DESACTIVAR_PERMISO_ROLES_ID = "'103'";
	
	
	 String CONFIG_OPERACIONES_MODULE_ID = "17";
	 //Eventos de modulo de usuario
	 String LISTAR_OPERACIONES_ID = "'62'";
	 String CREAR_OPERACIONES_ID = "'64'";
	 String OBTENER_OPERACIONES_ID = "'63'";
	 String EDITAR_OPERACIONES_ID = "'65'"; 
	 String ACTIVAR_OPERACIONES_ID = "'66'";
	 String DESACTIVAR_OPERACIONES_ID = "'67'"; 
	 String ELIMINAR_OPERACIONES_ID = "'68'";
	
	
	 String CONFIG_PRODUCTOS_MODULE_ID = "15";
	 //Eventos de modulo de usuario
	 String LISTAR_PRODUCTOS_ID = "'76'";
	 String CREAR_PRODUCTOS_ID = "'78'";
	 String OBTENER_PRODUCTOS_ID = "'77'";
	 String EDITAR_PRODUCTOS_ID = "'79'"; 
	 String ACTIVAR_PRODUCTOS_ID = "'80'";
	 String DESACTIVAR_PRODUCTOS_ID = "'81'"; 
	 String ELIMINAR_PRODUCTOS_ID = "'82'";
	 String ASOCIAR_OPERACION_PRODUCTOS_ID = "'90'";
	
	
	 String CONFIG_SUCURSAL_MODULE_ID = "25";
	 //Eventos de modulo de usuario
	 String LISTAR_SUCURSALES_ID = "'83'";
	 String CREAR_SUCURSALES_ID = "'85'";
	 String OBTENER_SUCURSALES_ID = "'84'";
	 String EDITAR_SUCURSALES_ID = "'86'"; 
	 String ACTIVAR_SUCURSALES_ID = "'87'";
	 String DESACTIVAR_SUCURSALES_ID = "'88'"; 
	 String ELIMINAR_SUCURSALES_ID = "'89'";
   
	 
	
	 String CONFIG_FINANCIERA_MODULE_ID = "24";
	 //Eventos de modulo de usuario
	 String LISTAR_INSTITUCION_ID = "'55'";
	 String CREAR_INSTITUCION_ID = "'57'";
	 String OBTENER_INSTITUCION_ID = "'56'";
	 String EDITAR_INSTITUCION_ID = "'58'"; 
	 String ACTIVAR_INSTITUCION_ID = "'59'";
	 String DESACTIVAR_INSTITUCION_ID = "'60'"; 
	 String ELIMINAR_INSTITUCION_ID = "'61'";
	
	
	 String CONFIG_EMISORES_MODULE_ID = "23";
	 //Eventos de modulo de usuario
	 String LISTAR_EMISORES_ID = "'69'";
	 String CREAR_EMISORES_ID = "'71'";
	 String OBTENER_EMISORES_ID = "'70'";
	 String EDITAR_EMISORES_ID = "'72'"; 
	 String ACTIVAR_EMISORES_ID = "'73'";
	 String DESACTIVAR_EMISORES_ID = "'74'"; 
	 String ELIMINAR_EMISORES_ID = "'75'";
	
	
	 String CONFIG_USER_MODULE_ID = "12";
	 //Eventos de modulo de usuario
	 String LISTAR_USUARIO_ID = "'13'"; 
	 String CREAR_USUARIO_ID = "'14'";
	 String EDITAR_USUARIO_ID = "'36'"; 
	 String BLOQUEAR_USUARIO_ID = "'47'";
	 String DESBLOQUEAR_USUARIO_ID = "'48'"; 
	 String ELIMINAR_USUARIO_ID = "'37'"; 
	 
	 
	 String CONFIG_CATEGORY_CATALOG_MODULE_ID = "18";
	 //Eventos de modulo de catalogo de categorias
	 String LISTAR_CATEGORY_CATALOG_ID = "'22'";
	 String CREAR_CATEGORY_CATALOG_ID = "'24'";
	 String OBTENER_CATEGORY_CATALOG_ID = "'23'";
	 String EDITAR_CATEGORY_CATALOG_ID = "'25'"; 
	 String ACTIVAR_CATEGORY_CATALOGN_ID = "'26'";
	 String DESACTIVAR_CATEGORY_CATALOG_ID = "'27'"; 
	 String ELIMINAR_CATEGORY_CATALOG_ID = "'28'";
	 
	 

	 String CONFIG_PRODUCT_CATALOG_MODULE_ID = "19";
	 //Eventos de modulo de catalogo de productos
	 String LISTAR_PRODUCT_CATALOG_ID = "'29'";
	 String CREAR_PRODUCT_CATALOG_ID = "'31'";
	 String OBTENER_PRODUCT_CATALOG_ID = "'30'";
	 String EDITAR_PRODUCT_CATALOG_ID = "'32'"; 
	 String ACTIVAR_PRODUCT_CATALOGN_ID = "'33'";
	 String DESACTIVAR_PRODUCT_CATALOG_ID = "'34'"; 
	 String ELIMINAR_PRODUCT_CATALOG_ID = "'35'";
	 
	 
	
}
