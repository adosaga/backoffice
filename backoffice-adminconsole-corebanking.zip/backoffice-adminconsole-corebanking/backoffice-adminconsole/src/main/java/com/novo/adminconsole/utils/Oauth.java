package com.novo.adminconsole.utils;

import org.apache.log4j.Logger;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.novo.adminconsole.TO.RefreshTokenTO;


public class Oauth {

	private RestTemplate restTemplate = new RestTemplate();
	
	private final Logger log = Logger.getLogger(Oauth.class);
	
	public ResponseEntity<RefreshTokenTO> refreshToken(String url, String refresh_token) {
		
		  String body = "refresh_token=" + refresh_token;
		
		//Headers de la peticion
		  HttpHeaders headers = new HttpHeaders();
	      headers.add("language", "es");
	      headers.add("Accept", "application/json");
	      headers.add("Content-Type", "application/x-www-form-urlencoded;charset=utf-8"); 
	      
		//Data enviada en el request
		HttpEntity<String> requestBody = new HttpEntity<>(body, headers);
		
		try {
			 
			 return restTemplate.postForEntity(url, requestBody, RefreshTokenTO.class);
		} catch (RestClientException re) {
			log.info("Error llamando a OAUTH: " + re.getMessage());
			return null;
		}
		
	}
	
}
