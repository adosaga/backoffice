package com.novo.adminconsole.TO;

import com.novo.adminconsole.utils.Parameter;

public class RequestParameterTO {

	private Parameter parametro;

	public Parameter getParametro() {
		return parametro;
	}

	public void setParametro(Parameter parametro) {
		this.parametro = parametro;
	}  

}
