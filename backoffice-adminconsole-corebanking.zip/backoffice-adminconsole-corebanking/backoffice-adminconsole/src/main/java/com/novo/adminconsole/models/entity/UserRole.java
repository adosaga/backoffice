package com.novo.adminconsole.models.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;

import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity
@Table(name="ADMCONS_USER_ROLES"/*, uniqueConstraints = {@UniqueConstraint(name="USER_ROLE_UK", columnNames = {"User_Id","Role_Id"})}*/)
public class UserRole implements Serializable{

	private static final long serialVersionUID = 1L;


	@EmbeddedId
    protected UserRolePK userRolesPK;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="User_Id", referencedColumnName="User_Id", foreignKey = @ForeignKey(name = "FK_USER_ID"), nullable = false, insertable = false, updatable = false)
	private UserApp userId;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="Role_Id", referencedColumnName="Role_Id", foreignKey = @ForeignKey(name = "FK_ROLE_ID"), nullable = false, insertable = false, updatable = false)

	private Role roleId;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="Role_Status", referencedColumnName="STATUS_ID", foreignKey = @ForeignKey(name = "FK_ROLE_STATUS_ID"), nullable = false)
	private AdmconsStatus roleStatus;
	
	@Column(length=200)
	private String Observation;
	
	@Column(name="From_date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date fromDate;
	
	@Column(name="To_date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date toDate;

	public UserRolePK getUserRolesPK() {
		return userRolesPK;
	}

	public void setUserRolesPK(UserRolePK userRolesPK) {
		this.userRolesPK = userRolesPK;

	}

	public UserApp getUserId() {
		return userId;
	}

	public void setUserId(UserApp userId) {
		this.userId = userId;
	}

	public Role getRoleId() {
		return roleId;
	}

	public void setRoleId(Role roleId) {
		this.roleId = roleId;
	}


	public AdmconsStatus getRoleStatus() {
		return roleStatus;
	}

	public void setRoleStatus(AdmconsStatus roleStatus) {
		this.roleStatus = roleStatus;
	}

	public String getObservation() {
		return Observation;
	}

	public void setObservation(String observation) {
		Observation = observation;
	}

	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public Date getToDate() {
		return toDate;
	}

	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

}
