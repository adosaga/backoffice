package com.novo.adminconsole.models.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name="ADMCONS_TEMP_ACCOUNTS")
public class AdmconsAccountTypes implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
    @NotNull
    @Size(min = 1, max = 2)
    @Column(name = "ACCOUNT_TYPE_ID")
    private String accountTypeId;
	
    @Size(max = 100)
    @Column(name = "ACCOUNT_TYPE_NAME")
    private String accountTypeName;
    
    @Size(max = 100)
    @Column(name = "OBSERVATIONS")
    private String observations;

	public String getAccountTypeId() {
		return accountTypeId;
	}

	public void setAccountTypeId(String accountTypeId) {
		this.accountTypeId = accountTypeId;
	}

	public String getAccountTypeName() {
		return accountTypeName;
	}

	public void setAccountTypeName(String accountTypeName) {
		this.accountTypeName = accountTypeName;
	}

	public String getObservations() {
		return observations;
	}

	public void setObservations(String observations) {
		this.observations = observations;
	}
    
}
