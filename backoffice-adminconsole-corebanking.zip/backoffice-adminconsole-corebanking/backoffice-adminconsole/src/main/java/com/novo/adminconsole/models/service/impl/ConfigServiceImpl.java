package com.novo.adminconsole.models.service.impl;

import com.novo.adminconsole.models.dao.IConfigDao;
import com.novo.adminconsole.models.dao.IModuleDao;
import com.novo.adminconsole.models.dao.IRoleDao;
import com.novo.adminconsole.models.dao.IUserDao;
import com.novo.adminconsole.models.entity.*;
import com.novo.adminconsole.models.service.IConfigService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class ConfigServiceImpl implements IConfigService {

	@Autowired
	private IRoleDao roleDao;
	
	@Autowired
	private IUserDao userDao;
	
	@Autowired
	private IModuleDao moduleDao;
	
	@Autowired
	private IConfigDao configDao;
	
	@Override
	@Transactional(readOnly = true)
	public List<Role> getRolesList() {
		
		return this.roleDao.getRoleList();

	}

	@Override
	@Transactional(readOnly = true)
	public List<AdmconsBranchOffices> getBranchOfficeList() {
		
		return this.userDao.getBranchOfficeList();
	}

	@Override
	@Transactional(readOnly = true)
	public List<AdmconsIssuers> getIssuerList() {
		
		return this.userDao.getIssuerList();
	}

	@Override
	@Transactional(readOnly = true)
	public List<String> getDisabledModules() {
		
		return this.moduleDao.getDisabledModules();
		
	}
	
	@Override
	public List<Object[]> getEnabledModules(String roleId) {
		
		return this.moduleDao.getEnabledModules(roleId);
	}

	@Override
	public List<Object[]> getListModules(String roleId) {
		return this.moduleDao.getListModules(roleId);
	}

	@Override
	@Transactional(readOnly = true)
	public List<AdmconsConfigType> getListTypes() {
		
		
		return configDao.getListTypes();
	}

	@Override
	@Transactional(readOnly = true)
	public List<AdmconsCategories> getListCategories(String areaId) {
		
		
		return configDao.getListCategories(areaId);
	}

	@Override
	@Transactional(readOnly = true)
	public List<Object[]> getListProducts(String issuerId) {
		
		
		return configDao.getListProducts(issuerId);
	}

	@Override
	@Transactional(readOnly = true)
	public List<AdmconsBranchOffices> getBranchOfficeListByIssuer(String issuerId) {
		
				
		return configDao.getBranchOfficeListByIssuer(issuerId);
	}

	@Override
	@Transactional(readOnly = true)
	public List<AdmconsIssuers> getIssuerListByIssuer(String issuerId) {
		
		
		return configDao.getIssuerListByIssuer(issuerId);
	}

	public List<Object[]> getMemberByFinancial(String financialId){
		return configDao.getMemberByFinancial(financialId);
	}
}
