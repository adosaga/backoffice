package com.novo.adminconsole.models.dao.impl;

import com.novo.adminconsole.models.dao.IReportDao;
import com.novo.adminconsole.utils.Report;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;

@Repository
public class ReportDaoImpl implements IReportDao {

    @PersistenceContext
    private EntityManager entityManager;

    private final Logger log = Logger.getLogger(RoleDaoImpl.class);

    @Override
    public List<String> getReportAuditoria(Report report) {
        log.info("Buscando datos de reporte");
        String sql = "select \n" +
                "SUBSTR(TO_CHAR(aul.event_time),0,17) ||' '|| SUBSTR(TO_CHAR(aul.event_time),26,2)  fecha, \n" +
               "aul.USER_ID usuario, \n" +
                "au.user_firstname nombre, \n" +
                "au.user_lastname apellido, \n" +
                "CASE WHEN am.module_name IS NULL THEN 'LOGIN' ELSE am.module_name END modulo,\n" +
                "ae.event_description funcion\n" +
                "from admcons_user_logs aul\n" +
                "join ADMCONS_USERS au on aul.user_id=au.user_id\n" +
                "join ADMCONS_EVENTS ae on aul.event_id=ae.event_id\n" +
                "left join admcons_functions af on ae.event_id=af.event_id\n" +
                "left join admcons_modules am on af.module_id=am.module_code\n" +
                "where " +
                "trunc(aul.event_time,'DD')=TO_DATE( '"+report.getFecha()+"' ,'dd/MM/yyyy')\n";
                if(report.getUserId()!="") {
                    sql += " and au.user_id='" + report.getUserId() + "'" ;
                }
                if(report.getModuloId()!="") {
                    sql += " and am.module_code='" + report.getModuloId() + "'" ;
                }
                sql += " order by aul.event_time DESC";
        Query query = this.entityManager.createNativeQuery(sql);
        return (List<String>) query.getResultList();
    }

    @Override
    public List<String> getReportConciliacion(Report report) {
        log.info("Buscando datos de reporte");
        String sql = "SELECT\n" +
                "NVL(SUM(CASE WHEN tt.transaction_type_id=13 THEN 1 ELSE 0 END),0) cantidad_op_AFT,\n" +
                "NVL(SUM(CASE WHEN tt.transaction_type_id=13 THEN t.amount ELSE 0 END),0) monto_op_AFT,\n" +
                "NVL(SUM(CASE WHEN tt.transaction_type_id=14 THEN 1 ELSE 0 END),0) cantidad_op_OCT,\n" +
                "NVL(SUM(CASE WHEN tt.transaction_type_id=14 THEN t.amount ELSE 0 END),0) monto_op_OCT,\n" +
                "NVL(SUM(CASE WHEN tt.transaction_type_id=15 THEN 1 ELSE 0 END),0) cantidad_op_AFTR,\n" +
                "NVL(SUM(CASE WHEN tt.transaction_type_id=15 THEN t.amount ELSE 0 END),0) monto_op_AFTR\n" +
                "FROM solution s\n" +
                "join operator o on s.operator_id=o.operator_id\n" +
                "join THIRD_PARTY_TRACE tpt on tpt.solution_name=s.solution_name\n" +
                "join transaction t on t.trace_id=tpt.trace_id\n" +
                "join ADMCONS_operations ao on t.operation_id=ao.operation_id\n" +
                "join TRANSACTION_TYPE tt on tt.TRANSACTION_TYPE_ID=t.TRANSACTION_TYPE_ID\n" +
                "join TRANSACTION_VISADIRECT tvd on tvd.TRANSACTION_ID=t.TRANSACTION_ID\n" +
                "where s.SOLUTION_NAME='VISADIRECT' and ao.OPERATION_NAME IN ('P2P','A2A')\n" +
                "UNION\n" +
                "SELECT\n" +
                "10 cantidad_op_AFT,\n" +
                "150 monto_op_AFT,\n" +
                "45 cantidad_op_OCT,\n" +
                "160 monto_op_OCT,\n" +
                "4 cantidad_op_AFTR,\n" +
                "70 monto_op_AFTR\n" +
                "FROM dual";
        Query query = this.entityManager.createNativeQuery(sql);
        return (List<String>) query.getResultList();
    }
}