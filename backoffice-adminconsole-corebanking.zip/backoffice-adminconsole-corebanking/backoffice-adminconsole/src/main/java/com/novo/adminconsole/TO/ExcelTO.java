/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.novo.adminconsole.TO;

import java.util.List;

/**
 *
 * @author frosales
 */
public class ExcelTO {
    private String bytes;
    private Header header;
    private List<RowTO> rows;

    public String getBytes() {
        return bytes;
    }

    public void setBytes(String bytes) {
        this.bytes = bytes;
    }

    public Header getHeader() {
        return header;
    }

    public void setHeader(Header header) {
        this.header = header;
    }

    public List<RowTO> getRows() {
        return rows;
    }

    public void setRows(List<RowTO> rows) {
        this.rows = rows;
    }
    
}
