package com.novo.adminconsole.controllers;

import java.security.Principal;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;

import com.novo.adminconsole.TO.ResponseAccessTO;
import com.novo.adminconsole.TO.ResponseTO;
import com.novo.adminconsole.models.entity.AdmconsBranchOffices;
import com.novo.adminconsole.models.entity.AdmconsIssuers;
import com.novo.adminconsole.models.entity.Role;
import com.novo.adminconsole.models.entity.UserApp;
import com.novo.adminconsole.models.service.IConfigService;
import com.novo.adminconsole.models.service.IRoleService;
import com.novo.adminconsole.models.service.IUserService;
import com.novo.adminconsole.models.service.impl.UserDetailsServiceImpl;
import com.novo.adminconsole.utils.NewUser;

import static com.novo.adminconsole.utils.Constants.CONFIG_USER_MODULE_ID;
import static com.novo.adminconsole.utils.Constants.LISTAR_USUARIO_ID;
import static com.novo.adminconsole.utils.Constants.CREAR_USUARIO_ID;
import static com.novo.adminconsole.utils.Constants.EDITAR_USUARIO_ID;
import static com.novo.adminconsole.utils.Constants.BLOQUEAR_USUARIO_ID;
import static com.novo.adminconsole.utils.Constants.DESBLOQUEAR_USUARIO_ID;
import static com.novo.adminconsole.utils.Constants.ELIMINAR_USUARIO_ID;

@Controller
public class UserController {
	
	private final Logger log = Logger.getLogger(UserController.class);
		
	@Autowired
	private IUserService userService;
	
	@Autowired
	private IConfigService configService;
	
	@Autowired
	private IRoleService roleService;
	
	@Autowired
	private UserDetailsServiceImpl userDetailsService;

	@ModelAttribute("listaRoles")
	public List<Role> getListaRoles() {
		// Obtener la lista de los roles
		return this.configService.getRolesList();
	}
	
	@ModelAttribute("listaSucursales")
	public List<AdmconsBranchOffices> getListaSucursales() {
		// Obtener la lista de sucursales
		return this.configService.getBranchOfficeList();
	}
	
	@ModelAttribute("listaEmisores")
	public List<AdmconsIssuers> getIssuerList() {
		// Obtener la lista de emisores
		return this.configService.getIssuerList();
	}
	
	
	// Listar todos los usuarios
	@GetMapping("/config/user/list")
	public String listarUsuarios(Model model, Principal principal, HttpSession httpSession, RedirectAttributes flash) {
		User loggedUser = (User) ((Authentication) principal).getPrincipal();
		model.addAttribute("userInfo", loggedUser.getUsername());
		String roleId = httpSession.getAttribute("roleId").toString();
		  
		log.info("Verificando accesos a modulo usuarios");
		ResponseEntity<ResponseAccessTO> responseAccess = roleService.obtenerPermisos(roleId, CONFIG_USER_MODULE_ID);
			
		HttpStatus statusAccess = responseAccess.getStatusCode();
			
		if (statusAccess == HttpStatus.OK) {
				
			ResponseAccessTO bodyAccess = responseAccess.getBody();
			Map<String,String> accessObject = bodyAccess.getAccess();
			log.info("accessObject: " + accessObject);
				
			if(!accessObject.isEmpty()) {
				
				try {
					
					String LISTAR_USUARIO = accessObject.containsKey(LISTAR_USUARIO_ID)?accessObject.get(LISTAR_USUARIO_ID).toString():null;
					String CREAR_USUARIO = accessObject.containsKey(CREAR_USUARIO_ID)?accessObject.get(CREAR_USUARIO_ID).toString():null;
					String EDITAR_USUARIO = accessObject.containsKey(EDITAR_USUARIO_ID)?accessObject.get(EDITAR_USUARIO_ID).toString():null;
					String BLOQUEAR_USUARIO = accessObject.containsKey(BLOQUEAR_USUARIO_ID)?accessObject.get(BLOQUEAR_USUARIO_ID).toString():null;
					String DESBLOQUEAR_USUARIO = accessObject.containsKey(DESBLOQUEAR_USUARIO_ID)?accessObject.get(DESBLOQUEAR_USUARIO_ID).toString():null;
					String ELIMINAR_USUARIO = accessObject.containsKey(ELIMINAR_USUARIO_ID)?accessObject.get(ELIMINAR_USUARIO_ID).toString():null;
					
					model.addAttribute("LISTAR_USUARIO", LISTAR_USUARIO);
					model.addAttribute("CREAR_USUARIO", CREAR_USUARIO);
					model.addAttribute("EDITAR_USUARIO", EDITAR_USUARIO);
					model.addAttribute("BLOQUEAR_USUARIO", BLOQUEAR_USUARIO);
					model.addAttribute("DESBLOQUEAR_USUARIO", DESBLOQUEAR_USUARIO);
					model.addAttribute("ELIMINAR_USUARIO", ELIMINAR_USUARIO);
						
					//Obtener lista de usuarios
					List<Object[]> listaUsuarios =  userService.getUserList();
					
					model.addAttribute("usuarios", listaUsuarios);
					
					@SuppressWarnings("unchecked")
					List<String> menu = (List<String>) httpSession.getAttribute("menu");
					model.addAttribute("menu", menu);
					
					@SuppressWarnings("unchecked")
					List<String> menuModules = (List<String>) httpSession.getAttribute("menuModules");
					model.addAttribute("menuModules", menuModules);
					
					model.addAttribute("userInfo", loggedUser.getUsername());
					
					model.addAttribute("titulo", "User list");
					
					NewUser modalObject = new NewUser();
					model.addAttribute("delete", modalObject);
					model.addAttribute("block", modalObject);
					model.addAttribute("unblock", modalObject);
					
					userService.saveEvent(loggedUser.getUsername(), "13", "Listando usuarios", "0");
					return "configurations/users/listUser";
					
				} catch (Exception e) {
					log.info("roleId: "+ roleId +" Objeto con permisos incompletos");
					userService.saveEvent(loggedUser.getUsername(), "13", "roleId: "+ roleId +" Objeto con permisos incompletos", "-1");
					flash.addFlashAttribute("error", "It is not possible to access");
					return "redirect:/dashboard";
					
				}
				
			}else {
				
				userService.saveEvent(loggedUser.getUsername(), "13", "roleId: "+ roleId +" It is not possible to access", "-1");
				flash.addFlashAttribute("error", "It is not possible to access");
				return "redirect:/dashboard";
			}	
				
		} else {

			userService.saveEvent(loggedUser.getUsername(), "13", "roleId: "+ roleId +" It is not possible to access", "-1");
			flash.addFlashAttribute("error", "It is not possible to access");
			return "redirect:/dashboard";
				
		}
		
	}

	// Crear un usuario nuevo
	@GetMapping("/config/user/new")
	public String crearUsuarios(Model model, Principal principal, HttpSession httpSession) {
		
		User loggedUser = (User) ((Authentication) principal).getPrincipal();
		model.addAttribute("userInfo", loggedUser.getUsername());
		
		@SuppressWarnings("unchecked")
		List<String> menu = (List<String>) httpSession.getAttribute("menu");
		model.addAttribute("menu", menu);
		
		@SuppressWarnings("unchecked")
		List<String> menuModules = (List<String>) httpSession.getAttribute("menuModules");
		model.addAttribute("menuModules", menuModules);
		
		NewUser usuario = new NewUser();
		model.addAttribute("usuario", usuario);
		model.addAttribute("titulo", "New user");
		
		return "configurations/users/newUser";
	}
	
	// Editar los datos de un usuario
	@GetMapping("/config/user/edit/{username}")
	public String editarUsuarios(@PathVariable(name = "username") String username, Model model, HttpSession httpSession, Principal principal, RedirectAttributes flash) {
		
		User loggedUser = (User) ((Authentication) principal).getPrincipal();
		model.addAttribute("userInfo", loggedUser.getUsername());
		
		//Obtener usuario por username
		log.info("Obteniendo usuario " + username);
		UserApp user = userDetailsService.findByUsername(username);
		
		if(user != null) {
			
			@SuppressWarnings("unchecked")
			List<String> menu = (List<String>) httpSession.getAttribute("menu");
			model.addAttribute("menu", menu);
			
			@SuppressWarnings("unchecked")
			List<String> menuModules = (List<String>) httpSession.getAttribute("menuModules");
			model.addAttribute("menuModules", menuModules);
			
			NewUser usuario = new NewUser();
			usuario.setUser_id(user.getId());
			usuario.setNational_id(user.getNationalId());
			usuario.setUser_email(user.getEmail());
			usuario.setUser_firstname(user.getFirstName());
			usuario.setUser_middlename(user.getMiddleName());
			usuario.setUser_lastname(user.getLastName());
			usuario.setUser_secondsurname(user.getSurName());
			usuario.setUser_job(user.getJob());
			usuario.setUser_job_area(user.getJobArea());
			usuario.setPhone_code(user.getPhoneCode());
			usuario.setUser_telephone(user.getTelephone());
			
			String role = userService.getUserRole(user.getId());
			
			model.addAttribute("usuario", usuario);
			model.addAttribute("titulo", "Edit user");
			model.addAttribute("role", role);
			
			model.addAttribute("phone", user.getTelephone());
			
			return "configurations/users/editUser";
		}else {
			
			userService.saveEvent(loggedUser.getUsername(), "36", "User is not correct", "-1");
			flash.addFlashAttribute("error", "User is not correct");
			return "redirect:/config/user/list";
		}
		
	}
	
	// Enviar los datos del formulario de creacion de usuario
	@PostMapping("/config/user/create")
	public String crearUsuarios(@ModelAttribute("usuario") NewUser usuario, Model model, RedirectAttributes flash, Principal principal, HttpSession httpSession) {
		
		User loggedUser = (User) ((Authentication) principal).getPrincipal();
		model.addAttribute("userInfo", loggedUser.getUsername());
		
		@SuppressWarnings("unchecked")
		List<String> menu = (List<String>) httpSession.getAttribute("menu");
		model.addAttribute("menu", menu);
		
		@SuppressWarnings("unchecked")
		List<String> menuModules = (List<String>) httpSession.getAttribute("menuModules");
		model.addAttribute("menuModules", menuModules);
		
		// llamo al servicio para crear el usuario
		log.info("Llamando a servicio de creacion de usuario");
		ResponseTO response =  userService.crearUsuario(usuario);
		//Verificar el codigo de respuesta del API
		if(response.getRc() == "0") {
			
			userService.saveEvent(loggedUser.getUsername(), "14", "User " + usuario.getUser_id() + " has been successfully created", response.getRc());
			flash.addFlashAttribute("success", response.getMsg());
			return "redirect:/config/user/list";	
		}else {
			
			userService.saveEvent(loggedUser.getUsername(), "14", "Error creatinf user: " + usuario.getUser_id(), response.getRc());
			flash.addFlashAttribute("error", response.getMsg());
			return "redirect:/config/user/new";
		}
		
	}
	
		// Enviar los datos del formulario de editar usuario
		@PostMapping("/config/user/edit")
		public String saveEditarUsuarios(@ModelAttribute("usuario") @Valid NewUser usuario, BindingResult result, Model model, RedirectAttributes flash, Principal principal, HttpSession httpSession) {
			
			User loggedUser = (User) ((Authentication) principal).getPrincipal();
			model.addAttribute("userInfo", loggedUser.getUsername());
			
			@SuppressWarnings("unchecked")
			List<String> menu = (List<String>) httpSession.getAttribute("menu");
			model.addAttribute("menu", menu);
			
			@SuppressWarnings("unchecked")
			List<String> menuModules = (List<String>) httpSession.getAttribute("menuModules");
			model.addAttribute("menuModules", menuModules);
			
			// si tiene algun tipo de error redirecciona al formulario
			if(result.hasErrors()) {
				
				model.addAttribute("titulo", "Editar usuario");
				return "configurations/users/editUser";
			}
			
			// llamo al servicio para editar el usuario
			log.info("Llamando a servicio de edicion de usuario");
			ResponseTO response =  userService.editarUsuario(usuario);
			//Verificar el codigo de respuesta del API
			if(response.getRc() == "0") {
				
				userService.saveEvent(loggedUser.getUsername(), "36", "User " + usuario.getUser_id() +" was success edited", response.getRc());
				flash.addFlashAttribute("success", response.getMsg());
				return "redirect:/config/user/list";	
			}else {
				
				userService.saveEvent(loggedUser.getUsername(), "36", "Error editing user " + usuario.getUser_id(), response.getRc());
				flash.addFlashAttribute("error", response.getMsg());
				return "redirect:/config/user/edit/" + usuario.getUser_id();
			}
			
		}
		
		
		@PostMapping("/config/user/delete")
		public String eliminarrUsuarios(@ModelAttribute("delete") NewUser usuario, RedirectAttributes flash, Principal principal, HttpSession httpSession) {
			User loggedUser = (User) ((Authentication) principal).getPrincipal();
			
			log.info("Llamando a servicio de eliminacion de usuario");
			ResponseTO response =  userService.eliminarUsuario(usuario.getUser_id());
			//Verificar el codigo de respuesta del API
			if(response.getRc() == "0") {
				
				userService.saveEvent(loggedUser.getUsername(), "37", "Usuario " + usuario.getUser_id() + " eliminado satisfactoriamente", response.getRc());
				flash.addFlashAttribute("success", response.getMsg());
				return "redirect:/config/user/list";	
			}else {
				
				userService.saveEvent(loggedUser.getUsername(), "37", "Error al eliminar usuario " + usuario.getUser_id(), response.getRc());
				flash.addFlashAttribute("error", response.getMsg());
				return "redirect:/config/user/list";
			}
			
		}	
		
		@PostMapping("/config/user/lock")
		public String bloquearUsuario(@ModelAttribute("block") NewUser usuario, RedirectAttributes flash, Principal principal){
			User loggedUser = (User) ((Authentication) principal).getPrincipal();
			
			log.info("Llamando a servicio de bloqueo de usuario");
			ResponseTO response =  userService.bloquearUsuario(usuario.getUser_id());
			
			if(response.getRc() == "0") {
				
				userService.saveEvent(loggedUser.getUsername(), "47", "Usuario " + usuario.getUser_id() + " bloqueado satisfactoriamente", response.getRc());
				flash.addFlashAttribute("success", response.getMsg());
				return "redirect:/config/user/list";	
			}else {
				
				userService.saveEvent(loggedUser.getUsername(), "47", "Error al bloquear usuario " + usuario.getUser_id(), response.getRc());
				flash.addFlashAttribute("error", response.getMsg());
				return "redirect:/config/user/list";
			}
		}
	
		@PostMapping("/config/usuarios/desbloquear")
		public String desbloquearUsuario(@ModelAttribute("unblock") NewUser usuario, RedirectAttributes flash, Principal principal){
			User loggedUser = (User) ((Authentication) principal).getPrincipal();
			
			log.info("Llamando a servicio de desbloqueo de usuario");
			ResponseTO response =  userService.desbloquearUsuario(usuario.getUser_id());
			
			if(response.getRc() == "0") {
				
				userService.saveEvent(loggedUser.getUsername(), "48", "Usuario " + usuario.getUser_id() + " desbloqueado satisfactoriamente", response.getRc());
				flash.addFlashAttribute("success", response.getMsg());
				return "redirect:/config/user/list";	
			}else {
				
				userService.saveEvent(loggedUser.getUsername(), "48", "Error al desbloquear usuario " + usuario.getUser_id(), response.getRc());
				flash.addFlashAttribute("error", response.getMsg());
				return "redirect:/config/user/list";
			}
		}
}
