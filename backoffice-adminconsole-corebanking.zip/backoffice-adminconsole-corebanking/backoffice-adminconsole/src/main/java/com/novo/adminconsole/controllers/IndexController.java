package com.novo.adminconsole.controllers;

import java.security.NoSuchAlgorithmException;
import java.security.Principal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.apache.tomcat.jdbc.pool.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.LockedException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.User;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.novo.adminconsole.TO.ResponseAccessTO;
import com.novo.adminconsole.TO.ResponseTO;
import com.novo.adminconsole.models.entity.AdmconsBranchOffices;
import com.novo.adminconsole.models.entity.AdmconsUserBranchOffice;
import com.novo.adminconsole.models.entity.UserApp;
import com.novo.adminconsole.models.entity.UserPassword;
import com.novo.adminconsole.models.service.IConfigService;
import com.novo.adminconsole.models.service.IRoleService;
import com.novo.adminconsole.models.service.IUserAttemptsService;
import com.novo.adminconsole.models.service.IUserService;
import com.novo.adminconsole.utils.MD5Hash;
import com.novo.adminconsole.utils.NewPassword;
import com.novo.adminconsole.utils.Recovery;
import com.novo.adminconsole.utils.RoleAssoc;

import static com.novo.adminconsole.utils.Constants.ACCESO_GENERAL;

import static com.novo.adminconsole.utils.Constants.REPORT_MODULE_ID; // evento 91

import static com.novo.adminconsole.utils.Constants.GENERAL_PARAMETER_MODULE_ID; // evento 91

import static com.novo.adminconsole.utils.Constants.CONFIG_MODULE_ID; // evento 91

import static com.novo.adminconsole.utils.Constants.CONFIG_ROL_MODULE_ID;
import static com.novo.adminconsole.utils.Constants.LISTAR_ROLES_ID;

import static com.novo.adminconsole.utils.Constants.CONFIG_USER_MODULE_ID;
import static com.novo.adminconsole.utils.Constants.LISTAR_USUARIO_ID;

import static com.novo.adminconsole.utils.Constants.CONFIG_PRODUCTOS_MODULE_ID;
import static com.novo.adminconsole.utils.Constants.LISTAR_PRODUCTOS_ID;

import static com.novo.adminconsole.utils.Constants.CONFIG_OPERACIONES_MODULE_ID;
import static com.novo.adminconsole.utils.Constants.LISTAR_OPERACIONES_ID;

import static com.novo.adminconsole.utils.Constants.CONFIG_EMISORES_MODULE_ID;
import static com.novo.adminconsole.utils.Constants.LISTAR_EMISORES_ID;

import static com.novo.adminconsole.utils.Constants.CONFIG_FINANCIERA_MODULE_ID;
import static com.novo.adminconsole.utils.Constants.LISTAR_INSTITUCION_ID;

@Controller
public class IndexController {

	@Autowired
	private IUserAttemptsService userAttemptsService;

	@Autowired
	private IUserService userService;

	@Autowired
	private IConfigService configService;

	@Autowired
	private IRoleService roleService;

	@Autowired
	private BCryptPasswordEncoder passwordEncoder;

	@Autowired
	DataSource dataSource;

	private final Logger log = Logger.getLogger(IndexController.class);

	private static final int PASSWORD_COUNT_CHANGE = 4;
	private static final int PASSWORD_COUNT_NEW = 5;

	public String generarSesion() {

		UUID uuid = UUID.randomUUID();
		MD5Hash md5Hash = new MD5Hash();
		String sessionId;
		try {
			sessionId = md5Hash.doHash(uuid.toString());
			return sessionId;
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
			return null;
		}
	}

	public List<String> convertirListaAccesos(ArrayList<Map<String, String>> access) {

		List<String> accessModuleList = new ArrayList<>();
		String enabled;

		for (Map<String, String> item : access) {

			String moduleId = item.get("MODULE_ID").toString();

			switch (moduleId) {

			case REPORT_MODULE_ID:
				enabled = item.containsKey(ACCESO_GENERAL) ? item.get(ACCESO_GENERAL).toString() : "";

				if (enabled.equals("0")) {
					accessModuleList.add(item.get("MODULE_NAME").toString());
				}

				break;

			case GENERAL_PARAMETER_MODULE_ID:
				enabled = item.containsKey(ACCESO_GENERAL) ? item.get(ACCESO_GENERAL).toString() : "";

				if (enabled.equals("0")) {
					accessModuleList.add(item.get("MODULE_NAME").toString());
				}

				break;

			case CONFIG_MODULE_ID:
				enabled = item.containsKey(ACCESO_GENERAL) ? item.get(ACCESO_GENERAL).toString() : "";

				if (enabled.equals("0")) {
					accessModuleList.add(item.get("MODULE_NAME").toString());
				}

				break;

			case CONFIG_ROL_MODULE_ID:

				enabled = item.containsKey(LISTAR_ROLES_ID) ? item.get(LISTAR_ROLES_ID).toString() : "";

				if (enabled.equals("0")) {
					accessModuleList.add(item.get("MODULE_NAME").toString());
				}

				break;

			case CONFIG_USER_MODULE_ID:

				enabled = item.containsKey(LISTAR_USUARIO_ID) ? item.get(LISTAR_USUARIO_ID).toString() : "";

				if (enabled.equals("0")) {
					accessModuleList.add(item.get("MODULE_NAME").toString());
				}

				break;

			case CONFIG_PRODUCTOS_MODULE_ID:
				enabled = item.get(LISTAR_PRODUCTOS_ID).toString();

				if (enabled.equals("0")) {
					accessModuleList.add(item.get("MODULE_NAME").toString());
				}

				break;

			case CONFIG_OPERACIONES_MODULE_ID:
				enabled = item.get(LISTAR_OPERACIONES_ID).toString();

				if (enabled.equals("0")) {
					accessModuleList.add(item.get("MODULE_NAME").toString());
				}

				break;

			case CONFIG_EMISORES_MODULE_ID:
				enabled = item.get(LISTAR_EMISORES_ID).toString();

				if (enabled.equals("0")) {
					accessModuleList.add(item.get("MODULE_NAME").toString());
				}

				break;

			case CONFIG_FINANCIERA_MODULE_ID:
				enabled = item.get(LISTAR_INSTITUCION_ID).toString();

				if (enabled.equals("0")) {
					accessModuleList.add(item.get("MODULE_NAME").toString());
				}

				break;

			default:
				break;
			}
		}
		return accessModuleList;
	}

	@GetMapping("/")
	public String home(Model model) {

		model.addAttribute("titulo", "Login de usuario");

		return "login";
	}

	@GetMapping("/logout")
	public String logout_redirect(Model model, Principal principal) {
		// Obtengo el usuario loggeado
		User loggedUser = (User) ((Authentication) principal).getPrincipal();
		userService.saveEvent(loggedUser.getUsername(), "1", "User logout successfully", "");
		return "redirect:/signout";
	}

	@GetMapping("/login")
	public String login(Model model) {

		model.addAttribute("titulo", "User Login");

		return "login";
	}

	@GetMapping("/signin/{type}")
	public String login_redirect(@PathVariable(value = "type") Integer type, Model model, RedirectAttributes flash,
			HttpServletRequest request, HttpSession session) {

		if (type != null) {

			if (type == 1) {
				String error = getErrorMessage(request, "SPRING_SECURITY_LAST_EXCEPTION");

				flash.addFlashAttribute("error", error);
				return "redirect:/login";

			} else if (type == 2) {
				log.info("------------------------- CERRANDO SESION DE USUARIO  --------------------------------");

				flash.addFlashAttribute("logout", "User logout");
				return "redirect:/login";
			}
		}
		return "redirect:/login";
	}

	@GetMapping("/dashboard")
	public String dashboard(Model model, Principal principal, HttpSession httpSession) {

		// Obtengo el usuario loggeado
		User loggedUser = (User) ((Authentication) principal).getPrincipal();

		// Verificar si está deshabilitado para que cambie su contraseña
		UserPassword userDisabled = userAttemptsService.findDisabledPassword(loggedUser.getUsername());

		if (userDisabled == null) {

			List<String> menu = this.configService.getDisabledModules();
			httpSession.setAttribute("menu", menu);

			String roleId = userService.getUserRoleId(loggedUser.getUsername());
			httpSession.setAttribute("roleId", roleId);

			List<Object[]> menuRole = this.configService.getEnabledModules(roleId);

			if (!menuRole.isEmpty()) {

				RoleAssoc roleAssoc = new RoleAssoc();
				List<RoleAssoc> subModuleList = new ArrayList<>();

				for (Object[] item : menuRole) {

					RoleAssoc module = new RoleAssoc();
					module.setModuleName(item[0].toString());
					module.setModuleId(item[1].toString());
					subModuleList.add(module);
				}

				roleAssoc.setRoleId(roleId);
				roleAssoc.setSubModuleList(subModuleList);

				ResponseEntity<ResponseAccessTO> response = this.roleService.obtenerPermisosModulos(roleAssoc);

				HttpStatus statusCode = response.getStatusCode();

				if (statusCode == HttpStatus.OK) {
					ResponseAccessTO body = response.getBody();
					ArrayList<Map<String, String>> accessList = body.getAccessList();

					List<String> menuModules = convertirListaAccesos(accessList);

					model.addAttribute("menuModules", menuModules);
					httpSession.setAttribute("menuModules", menuModules);

					log.info("----- Info de pool de conexiones ----");
					log.info("Max Idle: " + dataSource.getMaxIdle());
					log.info("Max Active: " + dataSource.getMaxIdle());
					log.info("Active: " + dataSource.getNumActive());
					log.info("Idle: " + dataSource.getNumIdle());
					log.info("Released: " + dataSource.getReleasedCount());
					log.info("Released Idle: " + dataSource.getReleasedIdleCount());
					log.info("Abandoned: " + dataSource.getRemoveAbandonedCount());
					log.info("Returned: " + dataSource.getReturnedCount());
					log.info("----- Info de pool de conexiones ----");

					// Generar sessionId del usuario
					String sessionId = generarSesion();

					// llamar a los metodos del dao del servicio userattemptsservice
					AdmconsUserBranchOffice userBranchOffice = this.userAttemptsService
							.findBranchId(loggedUser.getUsername());

					String branchId = userBranchOffice.getAdmconsBranchOffices().getBranchId();
					AdmconsBranchOffices branchOffices = this.userAttemptsService.findIssuerId(branchId);

					String issuerId = branchOffices.getIssuerId().getIssuerId();
					String branchCountry = branchOffices.getBranchCountry();

					// seteo los valores de sesion
					httpSession.setAttribute("issuerId", issuerId);
					httpSession.setAttribute("branchId", branchId);
					httpSession.setAttribute("branchCountry", branchCountry);
					httpSession.setAttribute("sessionId", sessionId);

					model.addAttribute("titulo", "Dashboard Admin Console");
					model.addAttribute("userInfo", loggedUser.getUsername());
					model.addAttribute("menu", menu);

					return "dashboard";

				} else {

					log.info("No se pudieron obtener permisos generales para los modulos");
					userService.saveEvent(loggedUser.getUsername(), "0",
							"General access for modules could not be gotten", "");
					return "redirect:/logout";
				}

			} else {

				httpSession.setAttribute("menuModules", menuRole);
				model.addAttribute("menuModules", menuRole);

				// Generar sessionId del usuario
				String sessionId = generarSesion();

				// llamar a los metodos del dao del servicio userattemptsservice
				AdmconsUserBranchOffice userBranchOffice = this.userAttemptsService
						.findBranchId(loggedUser.getUsername());

				String branchId = userBranchOffice.getAdmconsBranchOffices().getBranchId();
				AdmconsBranchOffices branchOffices = this.userAttemptsService.findIssuerId(branchId);

				String issuerId = branchOffices.getIssuerId().getIssuerId();
				String branchCountry = branchOffices.getBranchCountry();

				// seteo los valores de sesion
				httpSession.setAttribute("issuerId", issuerId);
				httpSession.setAttribute("branchId", branchId);
				httpSession.setAttribute("branchCountry", branchCountry);
				httpSession.setAttribute("sessionId", sessionId);

				model.addAttribute("titulo", "Dashboard Admin Console");
				model.addAttribute("userInfo", loggedUser.getUsername());
				model.addAttribute("menu", menu);

				return "dashboard";
			}

		} else {
			// Usuario deshabilitado

			return "redirect:/password/new";
		}

	}

	@GetMapping("/password/recovery")
	public String recoverPassword(Model model, Principal principal) {

		Recovery recovery = new Recovery();

		model.addAttribute("recovery", recovery);
		model.addAttribute("titulo", "Password recovery");

		return "recovery-password";
	}

	@PostMapping("/password/recovery")
	public String recoverPassword(@ModelAttribute("recovery") @Valid Recovery recovery, BindingResult result,
			RedirectAttributes flash, Model model) {

		// si tiene algun tipo de error redirecciona al formulario
		if (result.hasErrors()) {

			model.addAttribute("titulo", "Password recovery");
			return "recovery-password";
		}

		UserApp user = userAttemptsService.findEmail(recovery.getEmail());

		UserApp natId = userAttemptsService.findNationalId(recovery.getNationalId());

		if (user == null || natId == null) {
			log.info("Email o N° de identificación inválido");

			flash.addFlashAttribute("error", "invalid info. Please verify and try again");
			return "redirect:/password/recovery";

		} else {

			String response = userAttemptsService.passwordRecovery(user);

			if (response.equals("0")) {

				userService.saveEvent(user.getId(), "3", "Info was recovery with success and sent it by email", "0");
				flash.addFlashAttribute("logout", "Credentials are been sent to your email");
				return "redirect:/login";

			} else {

				userService.saveEvent(user.getId(), "3", "Info recovery was not possible", "-1");
				flash.addFlashAttribute("error",
						"User and password was not possible to recovery it, please try latter");
				return "redirect:/password/recovery";
			}

		}
	}

	@GetMapping("/password/new")
	public String newPassword(Model model, Principal principal) {

		log.info("Change temporal password");

		NewPassword password = new NewPassword();

		model.addAttribute("password", password);
		model.addAttribute("titulo", "New password");

		return "new-password";

	}

	@PostMapping("/password/new")
	public String newPassword(@ModelAttribute("password") @Valid NewPassword password, BindingResult result,
			RedirectAttributes flash, Model model, Principal principal) {

		// si tiene algun tipo de error redirecciona al formulario
		if (result.hasErrors()) {

			model.addAttribute("titulo", "New password");
			return "new-password";
		}

		// Obtengo el usuario loggeado
		User loggedUser = (User) ((Authentication) principal).getPrincipal();

		if (password.getUser_password().trim().isEmpty() || password.getConfirm_password().trim().isEmpty()) {

			log.info("Contraseñas vacías");
			userService.saveEvent(loggedUser.getUsername(), "2", "new password is not set", "");
			flash.addFlashAttribute("error", "Please set new password");
			return "redirect:/password/new";

		} else {

			log.info("Verificar 3 ultimas contraseñas en Nueva Contraseña");
			// verificar que la nueva contraseña no sea igual a las 3 anteriores
			boolean match = userAttemptsService.lastPasswords(loggedUser.getUsername(), password.getUser_password(),
					PASSWORD_COUNT_NEW);

			if (match) {

				userService.saveEvent(loggedUser.getUsername(), "2", "New password must be different to the last 3",
						"");
				flash.addFlashAttribute("error", "New password must be different to the last 3");
				return "redirect:/password/new";

			} else {

				boolean verificarConfirm = password.getUser_password().equals(password.getConfirm_password());

				if (verificarConfirm) {

					ResponseTO response = userAttemptsService.newPassword(loggedUser.getUsername(),
							password.getUser_password());

					String rc = response.getRc();

					if (rc.equals("0")) {

						userService.saveEvent(loggedUser.getUsername(), "2", "Password has been successfully changed",
								"0");
						flash.addFlashAttribute("success", "Password has been successfully changed");
						return "redirect:/password/confirm";

					} else {

						userService.saveEvent(loggedUser.getUsername(), "2",
								"Password change is not possible, please try latter", "-1");
						flash.addFlashAttribute("error", "Password change is not possible, please try latter");
						return "redirect:/password/new";
					}

				} else {

					log.info("Contraseña nueva y confirmacion de contraseña incorrectas");
					userService.saveEvent(loggedUser.getUsername(), "2",
							"New passwords does not match, please verify password requirements", "");
					flash.addFlashAttribute("error",
							"New passwords does not match, please verify password requirements");
					return "redirect:/password/new";
				}

			}
		}
	}

	// Confirmando contraseña
	@GetMapping("/password/confirm")
	public String confirmPassword(Model model, Principal principal) {

		log.info("Confirmando cambio de contraseña");

		NewPassword password = new NewPassword();

		model.addAttribute("password", password);
		model.addAttribute("titulo", "New password");

		return "new-password-confirm";

	}

	// Cambiar contraseña del usuario dentro del administrador
	@GetMapping("/password/change")
	public String changePassword(Model model, Principal principal, HttpSession httpSession) {

		// Obtengo el usuario loggeado
		User loggedUser = (User) ((Authentication) principal).getPrincipal();

		@SuppressWarnings("unchecked")
		List<String> menu = (List<String>) httpSession.getAttribute("menu");
		model.addAttribute("menu", menu);

		@SuppressWarnings("unchecked")
		List<String> menuModules = (List<String>) httpSession.getAttribute("menuModules");
		model.addAttribute("menuModules", menuModules);

		NewPassword password = new NewPassword();

		model.addAttribute("password", password);
		model.addAttribute("userInfo", loggedUser.getUsername());
		model.addAttribute("titulo", "Change password");

		return "change-password";
	}

	@PostMapping("/password/change")
	public String changePassword(@ModelAttribute("password") @Valid NewPassword password, BindingResult result,
			RedirectAttributes flash, Model model, HttpSession httpSession, Principal principal) {

		@SuppressWarnings("unchecked")
		List<String> menu = (List<String>) httpSession.getAttribute("menu");
		model.addAttribute("menu", menu);

		@SuppressWarnings("unchecked")
		List<String> menuModules = (List<String>) httpSession.getAttribute("menuModules");
		model.addAttribute("menuModules", menuModules);

		// si tiene algun tipo de error redirecciona al formulario
		if (result.hasErrors()) {

			model.addAttribute("titulo", "Change password");
			return "change-password";
		}

		// Obtengo el usuario loggeado
		User loggedUser = (User) ((Authentication) principal).getPrincipal();

		// Verificar que la contraseña actual sea correcta
		UserPassword passwordObject = userAttemptsService.findPassword(loggedUser.getUsername());

		boolean verificar = passwordEncoder.matches(password.getActual_password(), passwordObject.getUserPassword());

		if (verificar) {
			// la contraseña concuerda con la actual

			boolean verificarConfirm = password.getUser_password().equals(password.getConfirm_password());

			if (verificarConfirm) {

				log.info("Verificar 3 ultimas contraseñas en Cambio de Contraseña");
				// verificar que la nueva contraseña no sea igual a las 3 anteriores
				boolean matchAnteriores = userAttemptsService.lastPasswords(loggedUser.getUsername(),
						password.getUser_password(), PASSWORD_COUNT_CHANGE);

				if (matchAnteriores) {

					userService.saveEvent(loggedUser.getUsername(), "2", "New password must be different to the last 3",
							"");
					flash.addFlashAttribute("error", "New password must be different to the last 3");
					return "redirect:/password/change";
				} else {

					ResponseTO response = userAttemptsService.changePassword(loggedUser.getUsername(),
							password.getUser_password());

					String rc = response.getRc();

					if (rc.equals("0")) {

						userService.saveEvent(loggedUser.getUsername(), "2", "Password has been successfully changed",
								"0");
						flash.addFlashAttribute("success", "Password has been successfully changed");
						return "redirect:/dashboard";

					} else {

						userService.saveEvent(loggedUser.getUsername(), "2", "Error updating password", "-1");
						flash.addFlashAttribute("error", "Error updating password");
						return "redirect:/dashboard";
					}
				}
			} else {

				log.info("Contraseña nueva y confirmacion de contraseña incorrectas");
				userService.saveEvent(loggedUser.getUsername(), "2", "New passwords does not match", "");
				flash.addFlashAttribute("error", "New passwords does not match");
				return "redirect:/password/change";
			}
		} else {

			log.info("Contraseña actual incorrecta");
			userService.saveEvent(loggedUser.getUsername(), "2", "Invalid current password", "");
			flash.addFlashAttribute("error", "Invalid current password");
			return "redirect:/password/change";
		}
	}

	@GetMapping("/403")
	public String notAccess(Model model, Principal principal, HttpSession httpSession) {

		if (principal != null) {

			// Obtengo el usuario loggeado
			User loggedUser = (User) ((Authentication) principal).getPrincipal();
			@SuppressWarnings("unchecked")
			List<String> menu = (List<String>) httpSession.getAttribute("menu");
			model.addAttribute("menu", menu);

			@SuppressWarnings("unchecked")
			List<String> menuModules = (List<String>) httpSession.getAttribute("menuModules");
			model.addAttribute("menuModules", menuModules);

			model.addAttribute("titulo", "403 Access Denied");
			model.addAttribute("userInfo", loggedUser.getUsername());

			return "accessdenied";
		}
		
		return "accessdenied";
	}

	// customize the error message
	private String getErrorMessage(HttpServletRequest request, String key) {

		Exception exception = (Exception) request.getSession().getAttribute(key);

		String error = "";
		if (exception instanceof BadCredentialsException) {
			error = exception.getMessage();
		} else if (exception instanceof LockedException) {
			error = exception.getMessage();
		} else {
			error = exception.getMessage();
		}

		return error;
	}
}
