package com.novo.adminconsole.models.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="DO_VIP_STATUS")
public class Status {

    @Id
    @Column(name = "id_status")
    private String code;

    @Column(name = "description")
    private String description;

}
