package com.novo.adminconsole.models.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author dfernandez
 */
@Entity
@Table(name = "ADMCONS_USER_BRANCH_OFFICE")
public class AdmconsUserBranchOffice implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected AdmconsUserBranchOfficePK admconsUserBranchOfficePK;
    @Basic
    @Column(name = "FROM_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date fromDate;
    @Column(name = "TO_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date toDate;
    @JoinColumn(name = "USER_ID", referencedColumnName = "USER_ID", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private UserApp admconsUsers;
    @JoinColumn(name = "BRANCH_ID", referencedColumnName = "BRANCH_ID", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private AdmconsBranchOffices admconsBranchOffices;

    public AdmconsUserBranchOffice() {
    }

    public AdmconsUserBranchOffice(AdmconsUserBranchOfficePK admconsUserBranchOfficePK) {
        this.admconsUserBranchOfficePK = admconsUserBranchOfficePK;
    }

    public AdmconsUserBranchOffice(AdmconsUserBranchOfficePK admconsUserBranchOfficePK, Date fromDate) {
        this.admconsUserBranchOfficePK = admconsUserBranchOfficePK;
        this.fromDate = fromDate;
    }

    public AdmconsUserBranchOffice(String userId, String branchId) {
        this.admconsUserBranchOfficePK = new AdmconsUserBranchOfficePK(userId, branchId);
    }

    public AdmconsUserBranchOfficePK getAdmconsUserBranchOfficePK() {
        return admconsUserBranchOfficePK;
    }

    public void setAdmconsUserBranchOfficePK(AdmconsUserBranchOfficePK admconsUserBranchOfficePK) {
        this.admconsUserBranchOfficePK = admconsUserBranchOfficePK;
    }

    public Date getFromDate() {
        return fromDate;
    }

    public void setFromDate(Date fromDate) {
        this.fromDate = fromDate;
    }

    public Date getToDate() {
        return toDate;
    }

    public void setToDate(Date toDate) {
        this.toDate = toDate;
    }

    public UserApp getAdmconsUsers() {
        return admconsUsers;
    }

    public void setAdmconsUsers(UserApp admconsUsers) {
        this.admconsUsers = admconsUsers;
    }

    public AdmconsBranchOffices getAdmconsBranchOffices() {
        return admconsBranchOffices;
    }

    public void setAdmconsBranchOffices(AdmconsBranchOffices admconsBranchOffices) {
        this.admconsBranchOffices = admconsBranchOffices;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (admconsUserBranchOfficePK != null ? admconsUserBranchOfficePK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof AdmconsUserBranchOffice)) {
            return false;
        }
        AdmconsUserBranchOffice other = (AdmconsUserBranchOffice) object;
        if ((this.admconsUserBranchOfficePK == null && other.admconsUserBranchOfficePK != null) || (this.admconsUserBranchOfficePK != null && !this.admconsUserBranchOfficePK.equals(other.admconsUserBranchOfficePK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.hm.plantillawarapplication.model.AdmconsUserBranchOffice[ admconsUserBranchOfficePK=" + admconsUserBranchOfficePK + " ]";
    }
    
}