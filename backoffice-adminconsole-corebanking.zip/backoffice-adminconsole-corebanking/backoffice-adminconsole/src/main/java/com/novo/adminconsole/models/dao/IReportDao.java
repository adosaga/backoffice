package com.novo.adminconsole.models.dao;

import com.novo.adminconsole.utils.Report;

import java.util.List;

public interface IReportDao {

    public List<String> getReportAuditoria(Report report);

    public List<String> getReportConciliacion(Report report);
}
