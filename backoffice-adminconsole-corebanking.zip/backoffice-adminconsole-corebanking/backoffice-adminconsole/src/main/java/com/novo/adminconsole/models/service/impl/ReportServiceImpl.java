package com.novo.adminconsole.models.service.impl;

import com.google.gson.Gson;
import com.novo.adminconsole.TO.ReportFiltersTO;
import com.novo.adminconsole.TO.ReportTO;
import com.novo.adminconsole.TO.ResponseReportTO;
import com.novo.adminconsole.TO.RspReportParamsTO;
import com.novo.adminconsole.config.TokenOauth;
import com.novo.adminconsole.models.dao.IConfigDao;
import com.novo.adminconsole.models.dao.IReportDao;
import com.novo.adminconsole.models.entity.AdmconsReport;
import com.novo.adminconsole.models.service.IReportService;
import com.novo.adminconsole.utils.MultiReport;
import com.novo.adminconsole.utils.Report;
import com.novo.adminconsole.utils.Utils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.List;
import java.util.Properties;

import static com.novo.adminconsole.utils.Constants.PROPERTIES_FILE;

@Service
public class ReportServiceImpl implements IReportService {

	private final Logger log = Logger.getLogger(ParameterServiceImpl.class);

	@Autowired
	private IReportDao reportDao;
	@Autowired
	private IConfigDao configDao;
	@Autowired
	private TokenOauth tokenOauth;

	public ResponseEntity<ResponseReportTO> consultarReporte(String reportId) {

		Properties properties = Utils.getConfig(PROPERTIES_FILE);
		String countryHeader = properties.getProperty("country_header");
		String urlReportOneParam = properties.getProperty("app.api.report.oneParam");

		// get access token
		String accessTokn = tokenOauth.getRefreshedToken();

		if (accessTokn != null) {

			// request Headers
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.add("x-country", countryHeader);
			headers.add("Authorization", "Bearer " + accessTokn);

			// request Data
			HttpEntity<ResponseReportTO> requestBody = new HttpEntity<ResponseReportTO>(headers);

			try {
				RestTemplate restTemplate = new RestTemplate();
				return restTemplate.exchange(urlReportOneParam, HttpMethod.GET, requestBody, ResponseReportTO.class,
						reportId);
			} catch (RestClientException re) {

				log.error("Error llamando al API: " + re.getMessage());
				return new ResponseEntity<ResponseReportTO>(HttpStatus.CONFLICT);
			}

		} else {
			log.error("Access token is null");
			return new ResponseEntity<ResponseReportTO>(HttpStatus.CONFLICT);
		}
	}

	@Override
	public ResponseEntity<ByteArrayResource> descargarReporte(String reportId) throws IOException {

		ResponseEntity<ResponseReportTO> responseApi = consultarReporte(reportId);

		HttpStatus statusCode = responseApi.getStatusCode();

		if (statusCode == HttpStatus.OK) {

			String bean = responseApi.getBody().getBean();
			Gson gson = new Gson();
			ReportTO report = gson.fromJson(bean, ReportTO.class);

			byte[] data = report.getArchivo();
			ByteArrayResource resource = new ByteArrayResource(data);

			return ResponseEntity.ok()
					.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=report_" + reportId + ".xls")
					.contentType(MediaType.APPLICATION_OCTET_STREAM).contentLength(data.length).body(resource);

		} else {

			return new ResponseEntity<ByteArrayResource>(statusCode);

		}

	}

	@Override
	public ResponseEntity<ByteArrayResource> descargarReporte(String reportId, String format,
			ReportFiltersTO reportFiltersTO) throws IOException {

		ResponseEntity<ResponseReportTO> responseApi = obtenerReport(reportFiltersTO, reportId, format);
		HttpStatus statusCode = responseApi.getStatusCode();
		if (statusCode == HttpStatus.OK) {
			String bean = responseApi.getBody().getBean();
			Gson gson = new Gson();
			ReportTO report = gson.fromJson(bean, ReportTO.class);
			byte[] data = report.getArchivo();
			ByteArrayResource resource = new ByteArrayResource(data);
			return ResponseEntity.ok()
					.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=report_" + reportId + ".xls")
					.contentType(MediaType.APPLICATION_OCTET_STREAM).contentLength(data.length).body(resource);
		} else {
			return new ResponseEntity<ByteArrayResource>(statusCode);
		}
	}

	@Override
	@Transactional(readOnly = true)
	public List<AdmconsReport> obtenerReportes() {

		return configDao.obtenerReportes();
	}

	public ResponseEntity<ResponseReportTO> consultarReporteParam(MultiReport multi) {

		Properties properties = Utils.getConfig(PROPERTIES_FILE);
		String countryHeader = properties.getProperty("country_header");
		String urlReportStatus = properties.getProperty("app.api.report.status");

		// get access token
		String accessTokn = tokenOauth.getRefreshedToken();

		if (accessTokn != null) {

			// request Headers
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.add("x-country", countryHeader);
			headers.add("Authorization", "Bearer " + accessTokn);

			// request Data
			HttpEntity<ResponseReportTO> requestBody = new HttpEntity<ResponseReportTO>(headers);

			try {
				RestTemplate restTemplate = new RestTemplate();
				return restTemplate.exchange(urlReportStatus, HttpMethod.GET, requestBody, ResponseReportTO.class,
						multi.getReportId(), multi.getEstatus().trim());
			} catch (RestClientException re) {

				log.error("Error llamando al API: " + re.getMessage());
				return new ResponseEntity<ResponseReportTO>(HttpStatus.CONFLICT);
			}

		} else {
			log.error("Access token is null");
			return new ResponseEntity<ResponseReportTO>(HttpStatus.CONFLICT);
		}
	}

	@Override
	public ResponseEntity<ByteArrayResource> descargarReporteParam(MultiReport multi) throws IOException {

		ResponseEntity<ResponseReportTO> response = consultarReporteParam(multi);

		HttpStatus statusCode = response.getStatusCode();

		if (statusCode == HttpStatus.OK) {

			String bean = response.getBody().getBean();

			Gson gson = new Gson();
			ReportTO report = gson.fromJson(bean, ReportTO.class);

			byte[] data = report.getArchivo();
			ByteArrayResource resource = new ByteArrayResource(data);

			return ResponseEntity.ok()
					.header(HttpHeaders.CONTENT_DISPOSITION,
							"attachment;filename=report_" + multi.getReportId() + ".xls")
					.contentType(MediaType.APPLICATION_OCTET_STREAM).contentLength(data.length).body(resource);
		} else {

			return new ResponseEntity<ByteArrayResource>(statusCode);
		}
	}

	@Override
	public ResponseEntity<ResponseReportTO> obtenerReport(ReportFiltersTO reportFiltersTO, String reportId) {

		log.info("obtenerReport");

		Properties properties = Utils.getConfig(PROPERTIES_FILE);
		String countryHeader = properties.getProperty("country_header");
		String urlReportbyReportId = properties.getProperty("app.api.report.byReportId");

		// get access token
		String accessTokn = tokenOauth.getRefreshedToken();

		if (accessTokn != null) {

			// Headers de la peticion
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.add("x-country", countryHeader);
			headers.add("Authorization", "Bearer " + accessTokn);

			// request Data
			HttpEntity<ReportFiltersTO> requestBody = new HttpEntity<>(reportFiltersTO, headers);

			try {
				RestTemplate restTemplate = new RestTemplate();
				return restTemplate.exchange(urlReportbyReportId, HttpMethod.POST, requestBody, ResponseReportTO.class,
						reportId);
			} catch (RestClientException re) {
				log.error("Error llamando al API: " + re.getMessage());
				return new ResponseEntity<ResponseReportTO>(HttpStatus.CONFLICT);
			}

		} else {
			log.error("Access token is null");
			return new ResponseEntity<ResponseReportTO>(HttpStatus.CONFLICT);
		}
	}

	@Override
	public ResponseEntity<ResponseReportTO> obtenerReport(ReportFiltersTO reportFiltersTO, String reportId,
			String format) throws IOException {

		log.info("obtenerReport");

		Properties properties = Utils.getConfig(PROPERTIES_FILE);
		String countryHeader = properties.getProperty("country_header");
		String urlReportbyReportId = properties.getProperty("app.api.report.excelByReportId");

		// get access token
		String accessTokn = tokenOauth.getRefreshedToken();

		if (accessTokn != null) {

			// request Headers
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.add("x-country", countryHeader);
			headers.add("Authorization", "Bearer " + accessTokn);
			// request Data
			HttpEntity<ReportFiltersTO> requestBody = new HttpEntity<>(reportFiltersTO, headers);

			try {
				RestTemplate restTemplate = new RestTemplate();
				return restTemplate.exchange(urlReportbyReportId, HttpMethod.POST, requestBody, ResponseReportTO.class,
						reportId);
			} catch (RestClientException re) {

				log.error("Error llamando al API: " + re.getMessage());
				return new ResponseEntity<ResponseReportTO>(HttpStatus.CONFLICT);
			}

		} else {
			log.error("Access token is null");
			return new ResponseEntity<ResponseReportTO>(HttpStatus.CONFLICT);
		}
	}

	@Override
	public List<String> obtenerReportAuditoria(Report report) throws IOException {
		return reportDao.getReportAuditoria(report);
	}

	@Override
	public ResponseEntity<ByteArrayResource> exportReportParams(String reportId, String params) {

		ResponseEntity<ResponseReportTO> responseApi = getReportParams(reportId, params);
		HttpStatus statusCode = responseApi.getStatusCode();
		if (statusCode == HttpStatus.OK) {
			String bean = responseApi.getBody().getBean();
			Gson gson = new Gson();
			ReportTO report = gson.fromJson(bean, ReportTO.class);
			byte[] data = report.getArchivo();
			ByteArrayResource resource = new ByteArrayResource(data);
			return ResponseEntity.ok()
					.header(HttpHeaders.CONTENT_DISPOSITION,
							"attachment;filename=report_" + report.getNombre().replace(" ", "_") + ".xls")
					.contentType(MediaType.APPLICATION_OCTET_STREAM).contentLength(data.length).body(resource);
		} else {
			return new ResponseEntity<ByteArrayResource>(statusCode);
		}
	}

	@Override
	public ResponseEntity<ResponseReportTO> getReportParams(String reportId, String params) {

		Properties properties = Utils.getConfig(PROPERTIES_FILE);
		String countryHeader = properties.getProperty("country_header");
		String urlReportbyReportId = properties.getProperty("app.api.report.exportReport");

		// get access token
		String accessTokn = tokenOauth.getRefreshedToken();

		if (accessTokn != null) {

			// request Headers
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.add("x-country", countryHeader);
			headers.add("Authorization", "Bearer " + accessTokn);

			// request Data
			HttpEntity<String> requestBody = new HttpEntity<>(params, headers);

			try {
				RestTemplate restTemplate = new RestTemplate();
				return restTemplate.exchange(urlReportbyReportId, HttpMethod.POST, requestBody, ResponseReportTO.class,
						reportId);
			} catch (RestClientException re) {

				log.error("Error llamando al API: " + re.getMessage());
				return new ResponseEntity<ResponseReportTO>(HttpStatus.CONFLICT);
			}

		} else {
			log.error("Access token is null");
			return new ResponseEntity<ResponseReportTO>(HttpStatus.CONFLICT);
		}
	}

	@Override
	public ResponseEntity<RspReportParamsTO> getReportParams(String reportId) {

		Properties properties = Utils.getConfig(PROPERTIES_FILE);
		String countryHeader = properties.getProperty("country_header");
		String APIurl = properties.getProperty("app.api.report.reportParams");

		// get access token
		String accessTokn = tokenOauth.getRefreshedToken();
		
		if (accessTokn != null) {
			
				// request Headers
				HttpHeaders headers = new HttpHeaders();
				headers.setContentType(MediaType.APPLICATION_JSON);
				headers.add("x-country", countryHeader);
				headers.add("Authorization", "Bearer " + accessTokn);
				
				// request Data
				HttpEntity<String> requestBody = new HttpEntity<>(headers);
				
				try {
					RestTemplate restTemplate = new RestTemplate();
					return restTemplate.exchange(APIurl, HttpMethod.GET, requestBody, RspReportParamsTO.class);
				} catch (RestClientException re) {

					log.error("Error llamando al API: " + re.getMessage());
					return new ResponseEntity<RspReportParamsTO>(HttpStatus.CONFLICT);
				}

		} else {
			log.error("Access token is null");
			return new ResponseEntity<RspReportParamsTO>(HttpStatus.CONFLICT);
		}
	}

}
