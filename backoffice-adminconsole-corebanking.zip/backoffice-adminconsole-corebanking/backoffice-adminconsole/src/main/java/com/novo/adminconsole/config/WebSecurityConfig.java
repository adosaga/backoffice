package com.novo.adminconsole.config;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.novo.adminconsole.models.service.impl.UserDetailsServiceImpl;

@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter{
	
	@Autowired
	private UserDetailsServiceImpl userDetailsService;
	
	@Autowired
	@Qualifier("authenticationEventListener")
	private AuthenticationEventListener authenticationEventListner;
	
	@Bean
	public BCryptPasswordEncoder passwordEncoder() {
        BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();
        return bCryptPasswordEncoder;
    }
	
	
	@Autowired
	public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
		
		//Servicio para buscar el usuario en la BD
		auth.userDetailsService(this.userDetailsService).passwordEncoder(passwordEncoder());
		
		auth.authenticationEventPublisher(this.authenticationEventListner);	
		
	}
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		
		http.csrf().disable();
		
		// Rutas que no necesitan autorizacion
		http.authorizeRequests().antMatchers("/","/login").not().authenticated();
		
        // If no login, it will redirect to /login page.        
		http.authorizeRequests().antMatchers("/dashboard", "/password/new", "/password/confirm", "/logout","/onboarding/**").authenticated();
						      
        // For ROLE_PARAMETROS only
        http.authorizeRequests().antMatchers("/parameter/**").authenticated();
		
        // For ROLE_REPORTES only
        http.authorizeRequests().antMatchers("/reports/**").authenticated();
				
        // For MASTER and ADMIN only Modulo de Configuraciones
        http.authorizeRequests().antMatchers("/config/**").authenticated();
				
        // When the user has logged in as XX.
        // But access a page that requires role YY,
        // AccessDeniedException will be thrown.
        http.authorizeRequests().and().exceptionHandling().accessDeniedPage("/403");
		
		// Configuracion para el Formulario de Login
		http.authorizeRequests().and().formLogin()
				.loginProcessingUrl("/security_login") //Submit URL
				.loginPage("/login") // URL de la página de Login
				.defaultSuccessUrl("/dashboard", true) // URL a la que se redirecciona con Login Correcto
				.failureUrl("/signin/1") // URL si ocurre error al hacer login
				.usernameParameter("username")
				.passwordParameter("password")
				// Config para la Pagina de Logout
				.and().logout().logoutUrl("/signout").logoutSuccessUrl("/signin/2");

						
	}
	
	@Override
	public void configure(WebSecurity web) throws Exception {
		web.ignoring().antMatchers("/css/**", "/images/**", "/js/**", "/webjars/**");
	}
}
