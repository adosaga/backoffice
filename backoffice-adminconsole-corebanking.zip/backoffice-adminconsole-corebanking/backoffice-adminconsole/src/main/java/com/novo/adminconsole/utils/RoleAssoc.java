package com.novo.adminconsole.utils;

import java.util.List;

public class RoleAssoc {

	private String roleId;
	
	private String roleName;
	
	private String roleDescription;
	
	private String moduleId;
	
	private String moduleName;
	
	private String subModuleId;
	
	private String subModuleName;
	
	private String eventId;
	
	private String eventName;
	
	private String statusId;
	
	private List<RoleAssoc> subModuleList;
	
	private List<RoleAssoc> eventList;

	public String getRoleId() {
		return roleId;
	}

	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getModuleId() {
		return moduleId;
	}

	public void setModuleId(String moduleId) {
		this.moduleId = moduleId;
	}

	public String getModuleName() {
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	public String getSubModuleId() {
		return subModuleId;
	}

	public void setSubModuleId(String subModuleId) {
		this.subModuleId = subModuleId;
	}

	public String getSubModuleName() {
		return subModuleName;
	}

	public void setSubModuleName(String subModuleName) {
		this.subModuleName = subModuleName;
	}

	public String getEventId() {
		return eventId;
	}

	public void setEventId(String eventId) {
		this.eventId = eventId;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public String getStatusId() {
		return statusId;
	}

	public void setStatusId(String statusId) {
		this.statusId = statusId;
	}

	public String getRoleDescription() {
		return roleDescription;
	}

	public void setRoleDescription(String roleDescription) {
		this.roleDescription = roleDescription;
	}

	public List<RoleAssoc> getSubModuleList() {
		return subModuleList;
	}

	public void setSubModuleList(List<RoleAssoc> subModuleList) {
		this.subModuleList = subModuleList;
	}

	public List<RoleAssoc> getEventList() {
		return eventList;
	}

	public void setEventList(List<RoleAssoc> eventList) {
		this.eventList = eventList;
	}
}
