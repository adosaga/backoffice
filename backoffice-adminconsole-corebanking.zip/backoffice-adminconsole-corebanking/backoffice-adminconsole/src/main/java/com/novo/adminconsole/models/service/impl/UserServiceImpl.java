package com.novo.adminconsole.models.service.impl;

import com.novo.adminconsole.TO.RequestEncrypt;
import com.novo.adminconsole.TO.ResponseEmailTO;
import com.novo.adminconsole.TO.ResponseTO;
import com.novo.adminconsole.config.TokenOauth;
import com.novo.adminconsole.models.dao.IRoleDao;
import com.novo.adminconsole.models.dao.IUserDao;
import com.novo.adminconsole.models.entity.AdmconsBranchOffices;
import com.novo.adminconsole.models.entity.Role;
import com.novo.adminconsole.models.entity.UserApp;
import com.novo.adminconsole.models.service.IUserService;
import com.novo.adminconsole.utils.Email;
import com.novo.adminconsole.utils.NewUser;
import com.novo.adminconsole.utils.PasswordGenerator;
import com.novo.adminconsole.utils.Utils;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Properties;

import static com.novo.adminconsole.utils.Constants.PROPERTIES_FILE;

@Service
public class UserServiceImpl implements IUserService {

	@Autowired
	private IUserDao userDao;
	@Autowired
	private IRoleDao roleDao;
	@Autowired
	private TokenOauth tokenOauth;

	private final Logger log = Logger.getLogger(UserServiceImpl.class);

	private Email email = new Email();

	@Transactional
	@Override
	public ResponseTO crearUsuario(NewUser user) {

		// Verificar que no exista username, nationalId o email
		ResponseTO response = new ResponseTO();

		// Buscar por email
		UserApp userEmail = userDao.findByEmail(user.getUser_email());
		if (userEmail != null) {
			log.info("Ya existe un usuario con ese email");
			// crear un objeto de retorno con un rc para determinar el caso
			response.setRc("-1");
			response.setMsg("Email is already registered");

			return response;

		} else {
			// Buscar por username
			UserApp userId = userDao.findByUsername(user.getUser_id());
			if (userId != null) {
				log.info("Ya existe un usuario con ese username");
				// crear un objeto de retorno con un rc para determinar el caso
				response.setRc("-1");
				response.setMsg("Username is already registered");

				return response;

			} else {
				// Buscar por nationalId
				UserApp userNatId = userDao.findByNationalId(user.getNational_id());
				if (userNatId != null) {
					log.info("Ya existe un usuario con ese  N° de Identificación");
					// crear un objeto de retorno con un rc para determinar el caso
					response.setRc("-1");
					response.setMsg("ID number is already registered");

					return response;

				} else {
					// Ya se hicieron las validaciones respectivas

					// llamo al dao que inserta el usuario en Admcons_Users
					ResponseTO userSaved = userDao.saveUser(user);
					UserApp newUser = userSaved.getObject();
					final String emailUsername = newUser.getId();
					final String emailRecipient = newUser.getEmail();

					if (userSaved.getRc() == "0") {

						// Generar nueva password aleatoria
						final String password = PasswordGenerator.getPassword(6);
						log.info("Password temporal --> " + password);

						// llamo al dao que inserta el usuario en Admcons_User_Passwords
						ResponseTO passSaved = userDao.saveDisableUserPassword(newUser, password);

						if (passSaved.getRc() == "0") {

							// Thread que envia el correo con el password temporal
							Runnable regtrx = new Runnable() {
								@Override
								public void run() {
									// llamar al servicio de correo
									ResponseEntity<ResponseEmailTO> responseEmail = email.nuevoUsuario(emailUsername,
											password, emailRecipient);

									log.info("Email");

									if (responseEmail.equals(null)) {

									} else {

										log.info("StatusCode: " + responseEmail.getStatusCode().toString());
										log.info("RC: " + responseEmail.getBody().getRc());
										log.info("mSG: " + responseEmail.getBody().getMsg());

									}

								}
							};
							Thread Thregtrx = new Thread(regtrx);
							Thregtrx.start();

							// Busco primero el rol por el id
							Role userRole = roleDao.getRole(user.getUser_role());

							// llamo al dao que inserta el usuario en Admcons_User_Roles
							ResponseTO roleSaved = userDao.saveUserRoles(userRole, newUser);

							if (roleSaved.getRc() == "0") {
								// Busco primero el branchOffice por id
								AdmconsBranchOffices branchOffice = userDao.getBranchOffice(user.getBranch_city());

								// llamo al dao que inserta el usuario en Admcons_User_Branch_Office
								ResponseTO branchSaved = userDao.saveUserBranchOffice(newUser, branchOffice);

								if (branchSaved.getRc() == "0") {

									response.setRc("0");
									response.setMsg("user created! your temporal password was sent you by email");

									return response;

								} else {
									response.setRc("-1");
									response.setMsg("Error al insertar Sucursal");

									return response;
								}

							} else {
								response.setRc("-1");
								response.setMsg("Error creating Role");

								return response;
							}

						} else {
							response.setRc("-1");
							response.setMsg("Error creating Password");

							return response;
						}
					} else {
						response.setRc("-1");
						response.setMsg("Error creating Usuario");

						return response;
					}

				}
			}
		}

	}

	@Transactional
	@Override
	public ResponseTO editarUsuario(NewUser user) {

		log.info("Editando datos de usuario " + user.getUser_id());

		// Verificar que no exista username, nationalId o email
		ResponseTO response = new ResponseTO();

		// Buscar por email
		UserApp userEmail = userDao.findByEmail(user.getUser_email());
		if (userEmail != null) {
			if (userEmail.getId().equals(user.getUser_id())) {

				// Buscar por nationalId
				UserApp userNatId = userDao.findByNationalId(user.getNational_id());
				if (userNatId != null) {
					if (userNatId.getId().equals(user.getUser_id())) {

						// Caso en el que el usuario no modifica su nationalId ni su correo

						// Metodo que realiza la actualizacion de los datos
						return genericEdit(user);

					} else {
						log.info("Ya existe un usuario con ese  N° de Identificación");
						// crear un objeto de retorno con un rc para determinar el caso
						response.setRc("-1");
						response.setMsg("Id number is already registered");

						return response;
					}

				} else {

					// Caso en el que el usuario no modifica su correo pero si su nationalId

					// Metodo que realiza la actualizacion de los datos
					return genericEdit(user);

				}

			} else {

				log.info("Ya existe un usuario con ese email");
				// crear un objeto de retorno con un rc para determinar el caso
				response.setRc("-1");
				response.setMsg("email is already registered");

				return response;
			}

		} else {

			// Buscar por nationalId
			UserApp userNatId = userDao.findByNationalId(user.getNational_id());
			if (userNatId != null) {
				if (userNatId.getId().equals(user.getUser_id())) {

					// Caso en el que el usuario no modifica su nationalId pero si su correo

					// Metodo que realiza la actualizacion de los datos
					return genericEdit(user);

				} else {
					log.info("Ya existe un usuario con ese  N° de Identificación");
					// crear un objeto de retorno con un rc para determinar el caso
					response.setRc("-1");
					response.setMsg("Id number is already registered");

					return response;
				}

			} else {
				// Caso en el que el usuario modifica su nationalId y su correo

				// Metodo que realiza la actualizacion de los datos
				return genericEdit(user);
			}

		}

	}

	@Transactional
	@Override
	public ResponseTO eliminarUsuario(String username) {

		ResponseTO response = new ResponseTO();

		// llamo al dao que inserta el usuario en Admcons_Users
		ResponseTO userSaved = userDao.deleteUser(username);

		if (userSaved.getRc() == "0") {

			// llamo al dao que inserta el usuario en Admcons_User_Passwords
			ResponseTO passSaved = userDao.deleteUserPassword(username);

			if (passSaved.getRc() == "0") {

				// llamo al dao que inserta el usuario en Admcons_User_Roles
				ResponseTO roleSaved = userDao.deleteUserRoles(username);

				if (roleSaved.getRc() == "0") {

					// llamo al dao que inserta el usuario en Admcons_User_Branch_Office
					ResponseTO branchSaved = userDao.deleteUserBranchOffice(username);

					if (branchSaved.getRc() == "0") {

						response.setRc("0");
						response.setMsg("User has been successfully deleted");

						return response;

					} else {
						response.setRc("-1");
						response.setMsg("Error al eliminar Sucursal");

						return response;
					}

				} else {
					response.setRc("-1");
					response.setMsg("Error deleting Role");

					return response;
				}

			} else {
				response.setRc("-1");
				response.setMsg("Error deleting Password");

				return response;
			}
		} else {
			response.setRc("-1");
			response.setMsg("Error deleting Usuario");

			return response;
		}

	}

	@Override
	public List<Object[]> getUserList() {

		return this.userDao.getUserList();

	}

	@Override
	public List<Object[]> getUsers() {
		return this.userDao.getUsers();

	}

	@Override
	public List<Object[]> getFinalUserDetail(String tagpay) {
		return this.userDao.getFinalUsersDetail(tagpay);
	}

	@Override
	public List<Object[]> getEmailsUser(String tagpay) {
		return this.userDao.getEmailsUser(tagpay);
	}

	@Override
	public List<Object[]> getPhonesUser(String tagpay) {
		return this.userDao.getPhonesUser(tagpay);
	}

	@Override
	public List<Object[]> getDeviceUser(String tagpay) {
		return this.userDao.getDeviceUser(tagpay);
	}

	@Override
	public Object getStatusUser(String status, String column) {
		return this.userDao.getStatusUser(status, column);
	}

	@Transactional
	@Override
	public void saveEvent(String username, String eventId, String observation, String rc) {
		userDao.saveEvent(username, eventId, observation, rc);
	}

	public ResponseTO genericEdit(NewUser user) {

		ResponseTO response = new ResponseTO();
		// llamo al dao que edita el usuario en Admcons_Users
		ResponseTO userSaved = userDao.editUser(user);
		UserApp newUser = userSaved.getObject();
		if (userSaved.getRc() == "0") {

			// Busco primero el rol por el id
			Role userRole = roleDao.getRole(user.getUser_role());

			// llamo al dao que edita el usuario en Admcons_User_Roles
			ResponseTO roleSaved = userDao.editUserRoles(userRole, newUser);

			if (roleSaved.getRc() == "0") {
				// Busco primero el branchOffice por id
				AdmconsBranchOffices branchOffice = userDao.getBranchOffice(user.getBranch_city());

				// llamo al dao que edita el usuario en Admcons_User_Branch_Office
				ResponseTO branchSaved = userDao.editUserBranchOffice(newUser, branchOffice);

				if (branchSaved.getRc() == "0") {

					response.setRc("0");
					response.setMsg("User has been successfully edited");

					return response;

				} else {
					response.setRc("-1");
					response.setMsg("Error al insertar Sucursal");

					return response;
				}

			} else {

				response.setRc("-1");
				response.setMsg("Error creating Role");

				return response;
			}

		} else {

			response.setRc("-1");
			response.setMsg("Error creating User");

			return response;
		}

	}

	@Transactional
	@Override
	public String getUserRole(String userId) {

		return roleDao.getRoleName(userId);
	}

	@Transactional
	@Override
	public ResponseTO bloquearUsuario(String username) {

		return userDao.blockUserAccess(username);
	}

	@Transactional
	@Override
	public ResponseTO desbloquearUsuario(String username) {

		return userDao.unblockUserAccess(username);
	}

	@Transactional
	@Override
	public String getUserRoleId(String userId) {

		return roleDao.getRoleId(userId);
	}

	@Override
	public ResponseEntity<RequestEncrypt> changeStatus(String customerId, String sessionId, String status) {

		Properties properties = Utils.getConfig(PROPERTIES_FILE);
		String url = properties.getProperty("api.api.user.changeStatus");

		// get access token
		String accessTokn = tokenOauth.getRefreshedToken();

		if (accessTokn != null) {

			// request Headers
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.add("Accept", "application/json");
			headers.add("Authorization", "Bearer " + accessTokn);
			headers.add("x-country", "Rd");
			headers.add("language", "es");
			headers.add("x-session", sessionId);

			RequestEncrypt requestEncrypt = new RequestEncrypt();
			requestEncrypt.setStatus(status);
			requestEncrypt.setCustomerId(customerId);

			HttpEntity<RequestEncrypt> requestBody = new HttpEntity<>(requestEncrypt, headers);

			try {
				RestTemplate restTemplate = new RestTemplate();
				return restTemplate.exchange(url, HttpMethod.PUT, requestBody, RequestEncrypt.class, customerId);

			} catch (RestClientException re) {
				log.error("Error llamando al API: " + re.getMessage());
				return new ResponseEntity<RequestEncrypt>(HttpStatus.CONFLICT);
			}
		} else {
			log.error("Access token is null");
			return new ResponseEntity<RequestEncrypt>(HttpStatus.CONFLICT);
		}
	}
}
