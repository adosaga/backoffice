package com.novo.adminconsole.models.service;

import org.springframework.http.ResponseEntity;

import com.novo.adminconsole.TO.ResponseUserCoreTO;

public interface IOnboardingService {
	
	public ResponseEntity<ResponseUserCoreTO> getOnboardingCustomers(String docType, String createdDate, String status);
	public ResponseEntity<ResponseUserCoreTO> getCusConnectivity(String cusId);
	public ResponseEntity<ResponseUserCoreTO> getPersonalInfo(String cusId);
	public ResponseEntity<ResponseUserCoreTO> getOccupation(String cusId);
	public ResponseEntity<ResponseUserCoreTO> getAssessment(String cusId);
	public ResponseEntity<ResponseUserCoreTO> getDocuments(String cusId);
	public ResponseEntity<ResponseUserCoreTO> getSummary(String cusId);
	public ResponseEntity<ResponseUserCoreTO> getEventLog(String cusId);
	public ResponseEntity<ResponseUserCoreTO> getPayments(String cusId);
}
