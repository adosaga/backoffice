package com.novo.adminconsole.models.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="ADMCONS_PRODUCT_TYPES")
public class AdmconsProductTypes implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@NotNull
	@Column(name="PRODUCT_TYPE_ID")
	private String productTypeId;
	
	@Column(name="PRODUCT_TYPE_NAME")
	private String productTypeName;
	
	@Column(name="PRODUCT_TYPE_DESCRIPTION")
	private String productTypeDescription;
	
	@Column(name="CREATED")
	@Temporal(TemporalType.TIMESTAMP)
	private Date created;

	public String getProductTypeId() {
		return productTypeId;
	}

	public void setProductTypeId(String productTypeId) {
		this.productTypeId = productTypeId;
	}

	public String getProductTypeName() {
		return productTypeName;
	}

	public void setProductTypeName(String productTypeName) {
		this.productTypeName = productTypeName;
	}

	public String getProductTypeDescription() {
		return productTypeDescription;
	}

	public void setProductTypeDescription(String productTypeDescription) {
		this.productTypeDescription = productTypeDescription;
	}

	
}
