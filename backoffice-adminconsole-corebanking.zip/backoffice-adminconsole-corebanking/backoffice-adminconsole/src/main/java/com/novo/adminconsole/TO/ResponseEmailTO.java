package com.novo.adminconsole.TO;

public class ResponseEmailTO {

	private String rc;
	
	private String msg;
	
	public String getRc() {
		return rc;
	}

	public void setRc(String rc) {
		this.rc = rc;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}
	
}
