package com.novo.adminconsole.models.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="ADMCONS_MODULES")
public class AdmconsModules implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "Module_code")
	private String code;
	
	@Column(name = "Module_name")
	private String name;
	
	@Column(name = "Module_description")
	private String description;
	
	@JoinColumn(name = "Module_status", referencedColumnName = "STATUS_ID")
    @ManyToOne
	private AdmconsStatus moduleStatus;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public AdmconsStatus getModuleStatus() {
		return moduleStatus;
	}

	public void setModuleStatus(AdmconsStatus moduleStatus) {
		this.moduleStatus = moduleStatus;
	}
	
}
