package com.novo.adminconsole.utils;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

public class NewUser {

	@NotEmpty(message = "El usuario es requerido")
	@Size(max = 25)
	private String user_id;
	
	@NotEmpty(message = "El N° de Identificación es requerido")
	@Size(max = 15)
	private String national_id;
	
	@NotEmpty
	private String user_role;
	
	@NotEmpty(message = "El email es requerido")
	@Email(message = "El formato del email es incorrecto")
	private String user_email;
	
	@NotEmpty(message = "El Primer Nombre es requerido")
	@Size(max = 100)
	private String user_firstname;
	
	@Size(max = 100)
	private String user_middlename;
	
	@NotEmpty(message = "El Primer Apellido es requerido")
	@Size(max = 100)
	private String user_lastname;
	
	@Size(max = 100)
	private String user_secondsurname;
	
	private String phone_code;
	
	@Size(max = 50)
	private String user_telephone;
	
	@NotEmpty
	private String branch_city;
	
	@NotEmpty
	private String issuer_name;
	
	@Size(max = 100)
	private String user_job;
	
	@Size(max = 100)
	private String user_job_area;
	
	private String user_password;
	
	private String confirm_password;
	
	public String getUser_id() {
		return user_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

	public String getNational_id() {
		return national_id;
	}

	public void setNational_id(String national_id) {
		this.national_id = national_id;
	}

	public String getUser_email() {
		return user_email;
	}

	public void setUser_email(String user_email) {
		this.user_email = user_email;
	}

	public String getUser_firstname() {
		return user_firstname;
	}

	public void setUser_firstname(String user_firstname) {
		this.user_firstname = user_firstname;
	}

	public String getUser_middlename() {
		return user_middlename;
	}

	public void setUser_middlename(String user_middlename) {
		this.user_middlename = user_middlename;
	}

	public String getUser_lastname() {
		return user_lastname;
	}

	public void setUser_lastname(String user_lastname) {
		this.user_lastname = user_lastname;
	}

	public String getUser_secondsurname() {
		return user_secondsurname;
	}

	public void setUser_secondsurname(String user_secondsurname) {
		this.user_secondsurname = user_secondsurname;
	}

	public String getUser_telephone() {
		return user_telephone;
	}

	public void setUser_telephone(String user_telephone) {
		this.user_telephone = user_telephone;
	}

	public String getUser_password() {
		return user_password;
	}

	public void setUser_password(String user_password) {
		this.user_password = user_password;
	}

	public String getConfirm_password() {
		return confirm_password;
	}

	public void setConfirm_password(String confirm_password) {
		this.confirm_password = confirm_password;
	}

	public String getUser_job() {
		return user_job;
	}

	public void setUser_job(String user_job) {
		this.user_job = user_job;
	}

	public String getUser_job_area() {
		return user_job_area;
	}

	public void setUser_job_area(String user_job_area) {
		this.user_job_area = user_job_area;
	}

	public String getUser_role() {
		return user_role;
	}

	public void setUser_role(String user_role) {
		this.user_role = user_role;
	}

	public String getBranch_city() {
		return branch_city;
	}

	public void setBranch_city(String branch_city) {
		this.branch_city = branch_city;
	}

	public String getIssuer_name() {
		return issuer_name;
	}

	public void setIssuer_name(String issuer_name) {
		this.issuer_name = issuer_name;
	}

	public String getPhone_code() {
		return phone_code;
	}

	public void setPhone_code(String phone_code) {
		this.phone_code = phone_code;
	}

}
