package com.novo.adminconsole.models.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name = "ADMCONS_STATUS")
public class AdmconsStatus implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
    @NotNull
    @Size(min = 1, max = 2)
    @Column(name = "STATUS_ID")
    private String statusId;
	
    @Size(max = 50)
    @Column(name = "STATUS_NAME")
    private String statusName;
    
    @Size(max = 200)
    @Column(name = "STATUS_DESC")
    private String statusDesc;
    
    @Column(name = "CREATED")
    @Temporal(TemporalType.TIMESTAMP)
    private Date created;

	public String getStatusId() {
		return statusId;
	}

	public void setStatusId(String statusId) {
		this.statusId = statusId;
	}

	public String getStatusName() {
		return statusName;
	}

	public void setStatusName(String statusName) {
		this.statusName = statusName;
	}

	public String getStatusDesc() {
		return statusDesc;
	}

	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	public Date getCreated() {
		return created;
	}

	public void setCreated(Date created) {
		this.created = created;
	}
	
}
