package com.novo.adminconsole.utils;

import org.hibernate.validator.constraints.NotEmpty;

public class Reject {

	@NotEmpty
	private String passwordReject;
	
	private String dataFormIdReject;

	@NotEmpty
	private String observations;

	public String getPasswordReject() {
		return passwordReject;
	}

	public void setPasswordReject(String passwordReject) {
		this.passwordReject = passwordReject;
	}

	public String getDataFormIdReject() {
		return dataFormIdReject;
	}

	public void setDataFormIdReject(String dataFormIdReject) {
		this.dataFormIdReject = dataFormIdReject;
	}

	public String getObservations() {
		return observations;
	}

	public void setObservations(String observations) {
		this.observations = observations;
	}

}
