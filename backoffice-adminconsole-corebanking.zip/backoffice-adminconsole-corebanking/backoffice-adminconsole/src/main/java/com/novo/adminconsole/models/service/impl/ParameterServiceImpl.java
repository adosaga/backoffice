package com.novo.adminconsole.models.service.impl;

import static com.novo.adminconsole.utils.Constants.PROPERTIES_FILE;

import java.util.Properties;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.novo.adminconsole.TO.ResponseParameterTO;
import com.novo.adminconsole.config.TokenOauth;
import com.novo.adminconsole.models.service.IParameterService;
import com.novo.adminconsole.utils.Parameter;
import com.novo.adminconsole.utils.Utils;

@Service
public class ParameterServiceImpl implements IParameterService {

	private final Logger log = Logger.getLogger(ParameterServiceImpl.class);

	@Autowired
	private TokenOauth tokenOauth;

	@Override
	public ResponseEntity<ResponseParameterTO> listarParametros(User userLogged, String sessionId) {

		Properties properties = Utils.getConfig(PROPERTIES_FILE);
		String countryHeader = properties.getProperty("country_header");
		String urlListParameter = properties.getProperty("app.api.parameter.list");

		// get access token
		String accessTokn = tokenOauth.getRefreshedToken();

		if (accessTokn != null) {
			// Headers de la peticion
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.add("x-country", countryHeader);
			headers.add("Authorization", "Bearer " + accessTokn);

			// Data enviada en el request
			HttpEntity<ResponseParameterTO> requestBody = new HttpEntity<ResponseParameterTO>(headers);

			try {
				RestTemplate restTemplate = new RestTemplate();
				return restTemplate.exchange(urlListParameter, HttpMethod.GET, requestBody, ResponseParameterTO.class);
			} catch (RestClientException re) {

				log.error("Error llamando al API, list parameters: " + re);
				return new ResponseEntity<ResponseParameterTO>(HttpStatus.CONFLICT);
			}

		} else {
			log.error("Access token is null");
			return new ResponseEntity<ResponseParameterTO>(HttpStatus.CONFLICT);
		}

	}

	@Override
	public ResponseEntity<ResponseParameterTO> crearParametro(Parameter parameter, User userLogged, String sessionId) {

		Properties properties = Utils.getConfig(PROPERTIES_FILE);
		String countryHeader = properties.getProperty("country_header");
		String urlCreateParameter = properties.getProperty("app.api.parameter.create");

		// get access token
		String accessTokn = tokenOauth.getRefreshedToken();

		if (accessTokn != null) {

			// Headers de la peticion
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.add("x-country", countryHeader);
			headers.add("Authorization", "Bearer " + accessTokn);

			// Data enviada en el request
			HttpEntity<Parameter> requestBody = new HttpEntity<>(parameter, headers);

			try {
				RestTemplate restTemplate = new RestTemplate();
				return restTemplate.exchange(urlCreateParameter, HttpMethod.POST, requestBody,
						ResponseParameterTO.class);
			} catch (RestClientException re) {

				log.error("Error llamando al API, create parameter: " + re);
				return new ResponseEntity<ResponseParameterTO>(HttpStatus.CONFLICT);
			}
		} else {
			log.error("Access token is null");
			return new ResponseEntity<ResponseParameterTO>(HttpStatus.CONFLICT);
		}

	}

	@Override
	public ResponseEntity<ResponseParameterTO> obtenerParametro(Parameter parameter, User userLogged,
			String sessionId) {

		Properties properties = Utils.getConfig(PROPERTIES_FILE);
		String countryHeader = properties.getProperty("country_header");
		String urlGetParameter = properties.getProperty("app.api.parameter.getone");

		// get access token
		String accessTokn = tokenOauth.getRefreshedToken();

		if (accessTokn != null) {

			// request Headers
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.add("x-country", countryHeader);
			headers.add("Authorization", "Bearer " + accessTokn);

			// Data sent
			HttpEntity<ResponseParameterTO> requestBody = new HttpEntity<ResponseParameterTO>(headers);

			try {
				RestTemplate restTemplate = new RestTemplate();
				return restTemplate.exchange(urlGetParameter, HttpMethod.GET, requestBody, ResponseParameterTO.class,
						parameter.getConfigId());
			} catch (RestClientException re) {

				log.error("Error llamando al API, get parameter: " + re);
				return new ResponseEntity<ResponseParameterTO>(HttpStatus.CONFLICT);
			}

		} else {
			log.error("Access token is null");
			return new ResponseEntity<ResponseParameterTO>(HttpStatus.CONFLICT);
		}

	}

	@Override
	public ResponseEntity<ResponseParameterTO> editarParametro(Parameter parameter, User userLogged, String sessionId) {

		Properties properties = Utils.getConfig(PROPERTIES_FILE);
		String countryHeader = properties.getProperty("country_header");
		String urlEditParameter = properties.getProperty("app.api.parameter.edit");

		// get access token
		String accessTokn = tokenOauth.getRefreshedToken();

		if (accessTokn != null) {
			// request Headers
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.add("x-country", countryHeader);
			headers.add("Authorization", "Bearer " + accessTokn);

			// request data
			HttpEntity<Parameter> requestBody = new HttpEntity<>(parameter, headers);

			try {
				RestTemplate restTemplate = new RestTemplate();
				return restTemplate.exchange(urlEditParameter, HttpMethod.POST, requestBody, ResponseParameterTO.class);
			} catch (RestClientException re) {

				log.error("Error llamando al API: " + re);
				return new ResponseEntity<ResponseParameterTO>(HttpStatus.CONFLICT);
			}

		} else {
			log.error("Access token is null");
			return new ResponseEntity<ResponseParameterTO>(HttpStatus.CONFLICT);
		}

	}

	@Override
	public ResponseEntity<ResponseParameterTO> activarParametro(Parameter parameter, User userLogged,
			String sessionId) {

		Properties properties = Utils.getConfig(PROPERTIES_FILE);
		String countryHeader = properties.getProperty("country_header");
		String urlActivateParameter = properties.getProperty("app.api.parameter.activate");

		// get access token
		String accessTokn = tokenOauth.getRefreshedToken();

		if (accessTokn != null) {

			// request headers
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.add("x-country", countryHeader);
			headers.add("Authorization", "Bearer " + accessTokn);

			// request data
			HttpEntity<Parameter> requestBody = new HttpEntity<>(parameter, headers);

			try {
				RestTemplate restTemplate = new RestTemplate();
				return restTemplate.exchange(urlActivateParameter, HttpMethod.PUT, requestBody,
						ResponseParameterTO.class);
			} catch (RestClientException re) {

				log.error("Error llamando al API: " + re);
				return new ResponseEntity<ResponseParameterTO>(HttpStatus.CONFLICT);
			}

		} else {
			log.error("Access token is null");
			return new ResponseEntity<ResponseParameterTO>(HttpStatus.CONFLICT);
		}

	}

	@Override
	public ResponseEntity<ResponseParameterTO> desactivarParametro(Parameter parameter, User userLogged,
			String sessionId) {

		Properties properties = Utils.getConfig(PROPERTIES_FILE);
		String countryHeader = properties.getProperty("country_header");
		String urlDeactivateParameter = properties.getProperty("app.api.parameter.deactivate");

		// get access token
		String accessTokn = tokenOauth.getRefreshedToken();

		if (accessTokn != null) {

			// request headers
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.add("x-country", countryHeader);
			headers.add("Authorization", "Bearer " + accessTokn);

			// Data enviada en el request
			HttpEntity<Parameter> requestBody = new HttpEntity<>(parameter, headers);

			try {
				RestTemplate restTemplate = new RestTemplate();
				return restTemplate.exchange(urlDeactivateParameter, HttpMethod.PUT, requestBody,
						ResponseParameterTO.class);
			} catch (RestClientException re) {

				log.error("Error llamando al API: " + re.getMessage());
				return new ResponseEntity<ResponseParameterTO>(HttpStatus.CONFLICT);
			}

		} else {
			log.error("Access token is null");
			return new ResponseEntity<ResponseParameterTO>(HttpStatus.CONFLICT);
		}

	}

	@Override
	public ResponseEntity<ResponseParameterTO> eliminarParametro(Parameter parameter, User userLogged,
			String sessionId) {

		Properties properties = Utils.getConfig(PROPERTIES_FILE);
		String countryHeader = properties.getProperty("country_header");
		String urlDeleteParameter = properties.getProperty("app.api.parameter.delete");

		// get access token
		String accessTokn = tokenOauth.getRefreshedToken();

		if (accessTokn != null) {

			// request Headers
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.add("x-country", countryHeader);
			headers.add("Authorization", "Bearer " + accessTokn);

			// request Data
			HttpEntity<Parameter> requestBody = new HttpEntity<>(parameter, headers);

			try {
				RestTemplate restTemplate = new RestTemplate();
				return restTemplate.exchange(urlDeleteParameter, HttpMethod.PUT, requestBody,
						ResponseParameterTO.class);
			} catch (RestClientException re) {

				log.error("Error llamando al API: " + re.getMessage());
				return new ResponseEntity<ResponseParameterTO>(HttpStatus.CONFLICT);
			}
		} else {
			log.error("Access token is null");
			return new ResponseEntity<ResponseParameterTO>(HttpStatus.CONFLICT);
		}

	}

}
