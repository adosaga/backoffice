package com.novo.adminconsole.models.service.impl;

import static com.novo.adminconsole.utils.Constants.PROPERTIES_FILE;

import java.util.Map;
import java.util.Properties;

import javax.ejb.EJB;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;
import com.novo.adminconsole.TO.GeoIP;
import com.novo.adminconsole.TO.ResponseUserCoreTO;
import com.novo.adminconsole.config.TokenOauth;
import com.novo.adminconsole.models.service.IOnboardingService;
import com.novo.adminconsole.utils.Utils;

@Service
public class OnboardingServiceImpl implements IOnboardingService{
	
	private final Logger log = Logger.getLogger(OnboardingServiceImpl.class);

	@Autowired
	private TokenOauth tokenOauth;
	
	public ResponseEntity<ResponseUserCoreTO> getOnboardingCustomers(String docType, String createdDate, String status) {
		
		log.info("getOnboardingCustomers");
		
		Properties properties = Utils.getConfig(PROPERTIES_FILE);
		String country = properties.getProperty("country_header");
		String serviceURL = properties.getProperty("usercore.ob.consumers");
		String cusType= properties.getProperty("att.cusType");
		
		HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_JSON);
		boolean isParam=false;
		try {
			
			if(docType!=null && !docType.isEmpty()) {
				serviceURL=serviceURL.concat("?"+properties.getProperty("att.docType")+"="+docType);
				isParam=true;
			}
			if(createdDate!=null && !createdDate.isEmpty()) {
				if(isParam) {
					serviceURL=serviceURL.concat("&"+properties.getProperty("att.createdDate")+"="+createdDate);
				}
				else {
					serviceURL=serviceURL.concat("?"+properties.getProperty("att.createdDate")+"="+createdDate);
				}
				isParam=true;
			}
			if(status!=null && !status.isEmpty()) {
				if(isParam) {
					serviceURL=serviceURL.concat("&"+properties.getProperty("att.status")+"="+status);
				}
				else {
					serviceURL=serviceURL.concat("?"+properties.getProperty("att.status")+"="+status);
				}
				isParam=true;
			}
			
			RestTemplate restTemplate = new RestTemplate();			
			return restTemplate.exchange(serviceURL, HttpMethod.GET, new HttpEntity<>(headers),ResponseUserCoreTO.class,country,cusType);
		} catch (RestClientException re) {
			
			log.info("Error llamando al API user-core: " + re.getMessage());
			return new ResponseEntity<ResponseUserCoreTO>(HttpStatus.CONFLICT);
		}
		
	}
	
	public ResponseEntity<ResponseUserCoreTO> getCusConnectivity(String cusId) {
		log.info("getCusConnectivity");
	
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<ResponseUserCoreTO> result =null;
		String access_token;
		
		Properties properties = Utils.getConfig(PROPERTIES_FILE);
		String country = properties.getProperty("country_header");
		String serviceURL = properties.getProperty("usercore.ob.connectivity");
		String cusType= properties.getProperty("att.cusType");
		
		HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_JSON);
	    
	    //get connectivity info
	    try {						
			result= restTemplate.exchange(serviceURL, HttpMethod.GET, new HttpEntity<>(headers),ResponseUserCoreTO.class,country,cusType,cusId);
		} catch (RestClientException re) {			
			log.info("Error llamando al API user-core: " + re.getMessage());
			return new ResponseEntity<ResponseUserCoreTO>(HttpStatus.CONFLICT);
		}
	    Gson gson = new Gson();
	    Map<String,Object> conn = (Map<String, Object>) result.getBody().getData();
	    	    
	    if(conn != null) {
	
	    	access_token = tokenOauth.getRefreshedToken();	    	
	    	serviceURL = properties.getProperty("geoapi.url");
	    	headers.add("Authorization", "Bearer " + access_token);
	    	//Get IP from connectivity result
	    	String IP = ((Map)conn.get("connectivity")).get("IP").toString();
	    	ResponseEntity<GeoIP> g = null;
	    	//call GeoIP service
	    	try {
	    		g = restTemplate.exchange(serviceURL, HttpMethod.GET, new HttpEntity<>(headers),GeoIP.class,IP);
	    		((Map)conn.get("connectivity")).put("geoip", g.getBody().getCountryCode()+"-"+g.getBody().getCountryName());
		    	log.info("GEO: "+gson.toJson(g.getBody()));
	    	}catch(RestClientException e) {
	    		((Map)conn.get("connectivity")).put("geoip", "");
                log.info("Error llamando al servicio GeoIP: "+e);
	    	}   	   		    	
	    }else {
	    	log.info("No se puede invocar servicio GEOIP porque el token falló o no hay IP");
	    }

	    return result;
	}

	
	public ResponseEntity<ResponseUserCoreTO> getPersonalInfo(String cusId) {
		log.info("getPersonalInfo");
		
		Properties properties = Utils.getConfig(PROPERTIES_FILE);
		String country = properties.getProperty("country_header");
		String serviceURL = properties.getProperty("usercore.ob.personalInfo");
		String cusType= properties.getProperty("att.cusType");
		
		HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_JSON);

		try {			
			RestTemplate restTemplate = new RestTemplate();			
			return restTemplate.exchange(serviceURL, HttpMethod.GET, new HttpEntity<>(headers),ResponseUserCoreTO.class,country,cusType,cusId);
		} catch (RestClientException re) {
			
			log.info("Error llamando al API user-core,personal info: " + re.getMessage());
			return new ResponseEntity<ResponseUserCoreTO>(HttpStatus.CONFLICT);
		}
	}


	public ResponseEntity<ResponseUserCoreTO> getOccupation(String cusId) {
		log.info("getOccupation");
		
		Properties properties = Utils.getConfig(PROPERTIES_FILE);
		String country = properties.getProperty("country_header");
		String serviceURL = properties.getProperty("usercore.ob.occupation");
		String cusType= properties.getProperty("att.cusType");
		
		HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_JSON);

		try {			
			RestTemplate restTemplate = new RestTemplate();			
			return restTemplate.exchange(serviceURL, HttpMethod.GET, new HttpEntity<>(headers),ResponseUserCoreTO.class,country,cusType,cusId);
		} catch (RestClientException re) {
			
			log.info("Error llamando al API user-core,occupation: " + re.getMessage());
			return new ResponseEntity<ResponseUserCoreTO>(HttpStatus.CONFLICT);
		}
	}

	
	public ResponseEntity<ResponseUserCoreTO> getAssessment(String cusId) {
		log.info("getAssessment");
		
		Properties properties = Utils.getConfig(PROPERTIES_FILE);
		String country = properties.getProperty("country_header");
		String serviceURL = properties.getProperty("usercore.ob.assessment");
		String cusType= properties.getProperty("att.cusType");
		
		HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_JSON);

		try {			
			RestTemplate restTemplate = new RestTemplate();			
			return restTemplate.exchange(serviceURL, HttpMethod.GET, new HttpEntity<>(headers),ResponseUserCoreTO.class,country,cusType,cusId);
		} catch (RestClientException re) {
			
			log.info("Error llamando al API user-core,assessment: " + re.getMessage());
			return new ResponseEntity<ResponseUserCoreTO>(HttpStatus.CONFLICT);
		}
	}

	
	public ResponseEntity<ResponseUserCoreTO> getDocuments(String cusId) {
		log.info("getDocuments");
		
		Properties properties = Utils.getConfig(PROPERTIES_FILE);
		String country = properties.getProperty("country_header");
		String serviceURL = properties.getProperty("usercore.ob.documents");
		String cusType= properties.getProperty("att.cusType");
		
		HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_JSON);

		try {			
			RestTemplate restTemplate = new RestTemplate();			
			return restTemplate.exchange(serviceURL, HttpMethod.GET, new HttpEntity<>(headers),ResponseUserCoreTO.class,country,cusType,cusId);
		} catch (RestClientException re) {
			
			log.info("Error llamando al API user-core,documents: " + re.getMessage());
			return new ResponseEntity<ResponseUserCoreTO>(HttpStatus.CONFLICT);
		}
	}

	
	public ResponseEntity<ResponseUserCoreTO> getSummary(String cusId) {
		log.info("getSummary");
		
		Properties properties = Utils.getConfig(PROPERTIES_FILE);
		String country = properties.getProperty("country_header");
		String serviceURL = properties.getProperty("usercore.ob.summary");
		String cusType= properties.getProperty("att.cusType");
		
		HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_JSON);

		try {			
			RestTemplate restTemplate = new RestTemplate();			
			return restTemplate.exchange(serviceURL, HttpMethod.GET, new HttpEntity<>(headers),ResponseUserCoreTO.class,country,cusType,cusId);
		} catch (RestClientException re) {
			
			log.info("Error llamando al API user-core,summary: " + re.getMessage());
			return new ResponseEntity<ResponseUserCoreTO>(HttpStatus.CONFLICT);
		}
	}

	@Override
	public ResponseEntity<ResponseUserCoreTO> getEventLog(String cusId) {
	
		log.info("getEventLog");
		
		Properties properties = Utils.getConfig(PROPERTIES_FILE);
		String country = properties.getProperty("country_header");
		String serviceURL = properties.getProperty("usercore.ob.logs");
		String cusType= properties.getProperty("att.cusType");
		
		HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_JSON);

		try {			
			RestTemplate restTemplate = new RestTemplate();			
			return restTemplate.exchange(serviceURL, HttpMethod.GET, new HttpEntity<>(headers),ResponseUserCoreTO.class,country,cusType,cusId);
		} catch (RestClientException re) {
			
			log.info("Error llamando al API user-core,event_logs: " + re.getMessage());
			return new ResponseEntity<ResponseUserCoreTO>(HttpStatus.CONFLICT);
		}
	}

	@Override
	public ResponseEntity<ResponseUserCoreTO> getPayments(String cusId) {
		
		log.info("getPayments");
		
		Properties properties = Utils.getConfig(PROPERTIES_FILE);
		String country = properties.getProperty("country_header");
		String serviceURL = properties.getProperty("usercore.ob.payments");
		String cusType= properties.getProperty("att.cusType");
		
		HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_JSON);

		try {			
			RestTemplate restTemplate = new RestTemplate();			
			return restTemplate.exchange(serviceURL, HttpMethod.GET, new HttpEntity<>(headers),ResponseUserCoreTO.class,country,cusType,cusId);
		} catch (RestClientException re) {
			
			log.info("Error llamando al API user-core,payments: " + re.getMessage());
			return new ResponseEntity<ResponseUserCoreTO>(HttpStatus.CONFLICT);
		}
	}

}
