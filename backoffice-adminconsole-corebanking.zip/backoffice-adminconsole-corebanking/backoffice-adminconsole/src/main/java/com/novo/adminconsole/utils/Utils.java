package com.novo.adminconsole.utils;

import java.io.FileInputStream;
import java.util.Properties;

import org.apache.log4j.Logger;

public class Utils {
    
    private static final Logger log = Logger.getLogger(Utils.class);
    
    public static Properties getConfig(String nameFile) {
    	String pathLocal = System.getProperty("user.dir")
                + System.getProperty("file.separator")
                + nameFile;
        
        String pathWeblogic = System.getProperty("catalina.home", ".")
                + System.getProperty("file.separator")
                + "parametros"
                + System.getProperty("file.separator")
                + nameFile;
        
        Properties p = new Properties();
        try {
            FileInputStream fileIn = new FileInputStream(pathLocal);
            p.load(fileIn);
            fileIn.close();
        } catch (Exception e) {
            log.debug("getConfig ERROR path[" + pathLocal + "]");
            log.debug("getConfig ERROR getMessage[" + e.getMessage() + "]");
            log.debug("getConfig ERROR getLocalizedMessage[" + e.getLocalizedMessage() + "]");
            //e.printStackTrace();
        }
			
        try {
            FileInputStream fileIn = new FileInputStream(pathWeblogic);
            p.load(fileIn);
            fileIn.close();
        } catch (Exception e) {
            log.debug("getConfig ERROR path[" + pathWeblogic + "]");
            log.debug("getConfig ERROR getMessage[" + e.getMessage() + "]");
            log.debug("getConfig ERROR getLocalizedMessage[" + e.getLocalizedMessage() + "]");
            //e.printStackTrace();
        }
        return (p);
    }
}