package com.novo.adminconsole.constants;

public enum ApplicationHeader {
	
	CONTENT_PDF("pdf", "application/pdf"),
	CONTENT_XLS("xls","application/vnd.ms-excel"),
	CONTENT_XLSX("xlsx","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"),
	CONTENT_DOC("doc","application/msword"),
	CONTENT_DOCX("docx","application/vnd.openxmlformats-officedocument.wordprocessingml.document"),
	CONTENT_PNG("png","image/png"),
	CONTENT_JPG("jpg","image/jpeg"),
	CONTENT_JPEG("jpeg","image/jpeg");

    private String key;
    private String value;

    ApplicationHeader(String key, String value) {
        this.key = key;
        this.value = value;
    }

    public static String getById(String id) {
        for (ApplicationHeader e : values()) {
            if (e.key.equals(id.toLowerCase())) {
                return e.value;
            }
        }
        return "application/text";
    }

}
