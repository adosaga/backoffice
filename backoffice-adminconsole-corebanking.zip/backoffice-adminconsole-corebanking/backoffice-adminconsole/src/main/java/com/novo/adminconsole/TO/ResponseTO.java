package com.novo.adminconsole.TO;

import com.novo.adminconsole.models.entity.UserApp;

public class ResponseTO {

	private String rc;
	
	private String msg;
	
	private UserApp object;

	private String bean;

	private String token;

	public String getBean() {
		return bean;
	}

	public void setBean(String bean) {
		this.bean = bean;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getRc() {
		return rc;
	}

	public void setRc(String rc) {
		this.rc = rc;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public UserApp getObject() {
		return object;
	}

	public void setObject(UserApp object) {
		this.object = object;
	}
	
}
