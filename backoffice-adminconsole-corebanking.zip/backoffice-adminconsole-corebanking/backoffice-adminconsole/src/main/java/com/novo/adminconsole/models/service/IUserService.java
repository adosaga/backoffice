package com.novo.adminconsole.models.service;

import com.novo.adminconsole.TO.RequestEncrypt;
import com.novo.adminconsole.TO.ResponseTO;
import com.novo.adminconsole.utils.NewUser;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface IUserService {

	// Crear un usuario
	public ResponseTO crearUsuario(NewUser user);
	
	//Editar un usuario
	public ResponseTO editarUsuario(NewUser user);
	
	//Eliminar un usuario
	public ResponseTO eliminarUsuario(String username);
	
	public ResponseTO bloquearUsuario(String username);
	
	public ResponseTO desbloquearUsuario(String username);
	
	// Obtener lista de todos los usuarios
	public List<Object[]> getUserList();

	// Obtener todos usuarios
	public List<Object[]> getUsers();

	public List<Object[]> getFinalUserDetail(String tagpay);

	public List<Object[]> getEmailsUser(String tagpay);

	public List<Object[]> getPhonesUser(String tagpay);

	public List<Object[]> getDeviceUser(String tagpay);

	public Object getStatusUser(String status, String column);
	
	// Guardar eventos del usuario
	public void saveEvent(String username, String eventId, String observation, String rc);
	
	public String getUserRole(String userId);
	
	public String getUserRoleId(String userId);

	public ResponseEntity<RequestEncrypt> changeStatus(String customerId, String sessionId, String status);
}
