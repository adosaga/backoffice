package com.novo.adminconsole.models.service;

import com.novo.adminconsole.models.entity.*;

import java.util.List;

public interface IConfigService {

	public List<Role> getRolesList();
	
	public List<AdmconsBranchOffices> getBranchOfficeList();
	
	public List<AdmconsBranchOffices> getBranchOfficeListByIssuer(String issuerId);
	
	public List<AdmconsIssuers> getIssuerList();
	
	public List<AdmconsIssuers> getIssuerListByIssuer(String issuerId);
	
	public List<String> getDisabledModules();
	
	public List<Object[]> getEnabledModules(String roleId);

    public List<Object[]> getListModules(String roleId);

    public List<AdmconsConfigType> getListTypes();

    public List<AdmconsCategories> getListCategories(String areaId);

    public List<Object[]> getListProducts(String issuerId);

    public List<Object[]> getMemberByFinancial(String financialId);

}
