package com.novo.adminconsole.models.dao;


import java.util.List;


import com.novo.adminconsole.models.entity.UserApp;
import com.novo.adminconsole.models.entity.UserPassword;


public interface IUserPassDao {

	public UserPassword findNoBlocked(String id);
	
	public UserPassword findBlocked(String id);
	
	public UserPassword findPassword(String id);
	

	public UserPassword findDisabledPassword(String id);
	
	public List<Object[]> lastPasswords(String username, int rows);
	

	public void saveBlocked(UserApp us, String password);
	
	public void unlockBlocked(String id);
	
	public void updateBlocked(String id, int value);
	
	public void blockUser(String id, int max);
	

	public void disablePassword(String id);
	

}
