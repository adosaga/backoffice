package com.novo.adminconsole.models.dao.impl;


import com.novo.adminconsole.TO.ResponseTO;
import com.novo.adminconsole.models.dao.IUserDao;
import com.novo.adminconsole.models.entity.*;
import com.novo.adminconsole.utils.NewUser;
import org.apache.log4j.Logger;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;


@Repository
public class UserDaoImpl implements IUserDao {

	@PersistenceContext
	private EntityManager entityManager;
	
	private BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
	
	private final Logger log = Logger.getLogger(UserDaoImpl.class);
	
	@Override
	public UserApp findByUsername(String userName) {
		// Buscar el usuario por username
		
		try {
		String sql = "Select e from " + UserApp.class.getName() + " e " + "where e.id = :userName";
		Query query = this.entityManager.createQuery(sql, UserApp.class);
		query.setParameter("userName", userName);
		
		return (UserApp) query.getSingleResult();
		} catch (NoResultException e) {

			log.info("No existe el usuario con userName: " + userName);

			return null;
		}
	}

	@Override
	public UserApp findByEmail(String email) {
		// Buscar el usuario por email
		
		try {
			String sql = "Select e from " + UserApp.class.getName() + " e " + "where e.email = :email and e.userStatus = '1'";
			
			Query query = this.entityManager.createQuery(sql, UserApp.class);
			query.setParameter("email", email);
			
			return (UserApp) query.getSingleResult();
			} catch (NoResultException e) {

				log.info("No existe el usuario con email: " + email);
				return null;
			}
	}
	
	@Override
	public UserApp findByNationalId(String nationalId) {
		
		log.info("Obteniendo usuario con NationalId: " + nationalId);
		
		try {
		String sql = "Select e from " + UserApp.class.getName() + " e where e.nationalId = :nationalId and e.userStatus = '1'";
		
		Query query = this.entityManager.createQuery(sql, UserApp.class);
		query.setParameter("nationalId", nationalId);
		
		return (UserApp) query.getSingleResult();
		} catch (NoResultException e) {
			log.info("No existe el usuario con nationalId: " + nationalId);
			return null;
		}
	}

	@Override
	public AdmconsUserBranchOffice findBranchId(String username) {
		
		try {
			String sql = "Select e from " + AdmconsUserBranchOffice.class.getName() + " e where e.admconsUsers.id = :username";
			
			Query query = this.entityManager.createQuery(sql, AdmconsUserBranchOffice.class);
			query.setParameter("username", username);
			
			return (AdmconsUserBranchOffice) query.getSingleResult();
			} catch (Exception e) {
				
				log.info("error: " + e);
				return null;
			}
		
	}
	
	
	@Override
	public AdmconsBranchOffices findIssuerId(String branchId) {
		
		try {
			String sql = "Select e from " + AdmconsBranchOffices.class.getName() + " e where e.branchId = :branchId";
			
			Query query = this.entityManager.createQuery(sql, AdmconsBranchOffices.class);
			query.setParameter("branchId", branchId);
			
			return (AdmconsBranchOffices) query.getSingleResult();
			
		} catch (Exception e) {
			log.info("error: " + e);
			return null;
		}
			
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<AdmconsBranchOffices> getBranchOfficeList() {
		log.info("Obteniendo lista de sucursales");
		
		String sql = "Select b from " + AdmconsBranchOffices.class.getName() + " b";
		Query query = this.entityManager.createQuery(sql, AdmconsBranchOffices.class);
		
		return (List<AdmconsBranchOffices>) query.getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<AdmconsIssuers> getIssuerList() {
		log.info("Obteniendo lista de emisores");
		
		String sql = "Select i from " + AdmconsIssuers.class.getName() + " i";
		Query query = this.entityManager.createQuery(sql, AdmconsIssuers.class);
		
		return (List<AdmconsIssuers>) query.getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override									
	public List<Object[]> getUserList() {  
		log.info("Obteniendo lista de usuarios"); //
		
		String sql = "Select u.id, u.nationalId, u.firstName, u.lastName, u.email, u.userStatus.statusId from " + UserApp.class.getName() + " u where (u.userStatus.statusId = '1' and u.isAdmin = '0') or (u.userStatus.statusId = '3' and u.isAdmin = '0')";
		Query query = this.entityManager.createQuery(sql);
		
		return (List<Object[]>) query.getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getUsers() {
		log.info("Obteniendo todos los usuarios activos"); //
		String sql = "Select u.id, u.nationalId, u.firstName, u.lastName, u.email, u.userStatus.statusId from " + UserApp.class.getName() + " u where (u.userStatus.statusId = '1') or (u.userStatus.statusId = '3') ORDER BY u.firstName ASC";
		Query query = this.entityManager.createQuery(sql);
		return (List<Object[]>) query.getResultList();
	}

	@Override
	public ResponseTO saveUser(NewUser user) {
		log.info("Almacenando nuevo usuario");
		
		String sql = "INSERT INTO ADMCONS_USERS VALUES (:id, :natId, :email, '1', :fName, :mName, :lName, :sName, :code, :phone, :job, :area, '0', SYSDATE, SYSDATE, SYSDATE, SYSDATE)";
		
		ResponseTO resp = new ResponseTO();
		
		UserApp nuevoUser = new UserApp();
		nuevoUser.setId(user.getUser_id());
		nuevoUser.setNationalId(user.getNational_id());
		nuevoUser.setEmail(user.getUser_email());
		nuevoUser.setFirstName(user.getUser_firstname());
		nuevoUser.setMiddleName(user.getUser_middlename());
		nuevoUser.setLastName(user.getUser_lastname());
		nuevoUser.setSurName(user.getUser_secondsurname());
		nuevoUser.setTelephone(user.getUser_telephone());
		nuevoUser.setPhoneCode(user.getPhone_code());
		nuevoUser.setJob(user.getUser_job());
		nuevoUser.setJobArea(user.getUser_job_area());
		nuevoUser.setIsAdmin("0");
		
		AdmconsStatus statusUsr = new AdmconsStatus();
		statusUsr.setStatusId("1");
		nuevoUser.setUserStatus(statusUsr);
		
		try {
			
			Query query = entityManager.createNativeQuery(sql);
			query.setParameter("id", user.getUser_id());
			query.setParameter("natId", user.getNational_id());
			query.setParameter("email", user.getUser_email());
			query.setParameter("fName", user.getUser_firstname());
			query.setParameter("mName", user.getUser_middlename());
			query.setParameter("lName", user.getUser_lastname());
			query.setParameter("sName", user.getUser_secondsurname());
			query.setParameter("code", user.getPhone_code());
			query.setParameter("phone", user.getUser_telephone());
			query.setParameter("job", user.getUser_job());
			query.setParameter("area", user.getUser_job_area());
			
			
			query.executeUpdate();
			log.info("Usuario insertado satisfactoriamente");
			
			resp.setRc("0");
			resp.setMsg("User has been successfully created");
			resp.setObject(nuevoUser);
			return resp;
		} catch (Exception e) {
			log.info("error: " + e);
			
			resp.setRc("-1");
			resp.setMsg("Error creating user");
			return resp;
		}
		
	}

	@Override
	public ResponseTO saveUserRoles(Role rol, UserApp user) {
		log.info("Almacenando rol del usuario");
		
		String sql = "INSERT INTO ADMCONS_USER_ROLES VALUES (:id, :roleId, '9', null, SYSDATE, SYSDATE)";
		
		ResponseTO resp = new ResponseTO();
		/*UserRole nuevoUserRole = new UserRole();
		nuevoUserRole.setUserId(user);
		nuevoUserRole.setRoleId(rol);
		
		UserRolePK rolePk = new UserRolePK();
		rolePk.setRoleId(rol.getId());
		rolePk.setUserId(user.getId());
		nuevoUserRole.setUserRolesPK(rolePk);
		
		AdmconsStatus status = new AdmconsStatus();
		status.setStatusId("1");
		nuevoUserRole.setRoleStatus(status);*/
		
		try {
			Query query = entityManager.createNativeQuery(sql);
			query.setParameter("id", user.getId());
			query.setParameter("roleId", rol.getId());
			query.executeUpdate();
			
			log.info("Rol de usuario insertado satisfactoriamente");
			
			resp.setRc("0");
			resp.setMsg("Role has been successfully created");
			return resp;
		} catch (Exception e) {
			log.info("error: " + e);
			
			resp.setRc("-1");
			resp.setMsg("Error creating role");
			return resp;
		}
	}

	@Override
	public ResponseTO saveUserPassword(UserApp userApp, String password) {
		
		log.info("Almacenando cambio de password del usuario " + userApp.getId());
		log.info("El status de la contraseña es DESHABILITADO");
		ResponseTO resp = new ResponseTO();
		
		String sql = "UPDATE ADMCONS_USER_PASSWORDS SET user_password = :password, attempts = 0, passw_status = '1' WHERE User_Id = :id AND user_status = '1' AND passw_status = '4'";
		String hashPassword = passwordEncoder.encode(password);
		
		try {
			
			Query query = entityManager.createNativeQuery(sql);
			query.setParameter("id", userApp.getId());
			query.setParameter("password", hashPassword);
			
			query.executeUpdate();
			log.info("Password insertada satisfactoriamente");
			
			resp.setRc("0");
			resp.setMsg("Password has been successfully updated");
			return resp;
		} catch (Exception e) {
			log.info("error: " + e);
			
			resp.setRc("-1");
			resp.setMsg("Error updating password");
			return resp;
		}
				
	}

	@Override
	public ResponseTO saveUserBranchOffice(UserApp userApp, AdmconsBranchOffices branchOffice) {
		log.info("Almacenando usuario en User_Branch_Office");
		
		String sql = "INSERT INTO ADMCONS_USER_BRANCH_OFFICE VALUES (:id, :branch, SYSDATE, SYSDATE, '1')";
		
		ResponseTO resp = new ResponseTO();
		/*AdmconsUserBranchOffice userBranchOffice = new AdmconsUserBranchOffice();
		userBranchOffice.setAdmconsBranchOffices(branchOffice);
		userBranchOffice.setAdmconsUsers(userApp);
		userBranchOffice.setFromDate(now);
		
		AdmconsUserBranchOfficePK userBranchPK = new AdmconsUserBranchOfficePK();
		userBranchPK.setBranchId(branchOffice.getBranchId());
		userBranchPK.setUserId(userApp.getId());
		userBranchOffice.setAdmconsUserBranchOfficePK(userBranchPK);*/
		
		try {
			Query query = entityManager.createNativeQuery(sql);
			query.setParameter("id", userApp.getId());
			query.setParameter("branch", branchOffice.getBranchId());
			query.executeUpdate();
			
			log.info("Insertado satisfactoriamente Sucursal");
			
			resp.setRc("0");
			resp.setMsg("Insertado satisfactoriamente Sucursal");
			return resp;
		} catch (Exception e) {
			
			log.info("error: " + e);
			
			resp.setRc("-1");
			resp.setMsg("Error al insertar Sucursal");
			return resp;
		}
	}

	@Override
	public AdmconsBranchOffices getBranchOffice(String branchId) {
		log.info("Obteniendo BranchOffice");
		
		String sql = "Select b from " + AdmconsBranchOffices.class.getName() + " b where b.branchId = :branchId";
		Query query = entityManager.createQuery(sql, AdmconsBranchOffices.class);
		query.setParameter("branchId", branchId);
		
		return (AdmconsBranchOffices) query.getSingleResult();
	}

	@Override
	public ResponseTO saveDisableUserPassword(UserApp userApp, String password) {
		
		log.info("Almacenando password del usuario " + userApp.getId());
		log.info("El status de la contraseña es DESHABILITADO");

		ResponseTO resp = new ResponseTO();

		String sql = "INSERT INTO ADMCONS_USER_PASSWORDS VALUES ('1', ?, ?,'0','4','1',SYSDATE,SYSDATE)";
		String hashPassword = passwordEncoder.encode(password);
		
		try {
			
			Query query = entityManager.createNativeQuery(sql);
			query.setParameter(1, userApp.getId());
			query.setParameter(2, hashPassword);
			
			query.executeUpdate();
			log.info("Password insertada satisfactoriamente");
			
			resp.setRc("0");
			resp.setMsg("Password has been successfully created");
			return resp;
		} catch (Exception e) {
			log.info("error: " + e);
			
			resp.setRc("-1");
			resp.setMsg("Error setting password");
			return resp;
		}
		
	}

	@Override
	public ResponseTO changeUserPassword(UserApp userApp, String password) {
		
		log.info("Cambiando password del usuario " + userApp.getId());

		ResponseTO resp = new ResponseTO();

		String sql = "INSERT INTO ADMCONS_USER_PASSWORDS VALUES ('1', ?, ?,'0','1','1',SYSDATE,SYSDATE)";
		String hashPassword = passwordEncoder.encode(password);
		
		try {
			
			Query query = entityManager.createNativeQuery(sql);
			query.setParameter(1, userApp.getId());
			query.setParameter(2, hashPassword);
			
			query.executeUpdate();
			log.info("Password cambiada satisfactoriamente");
			
			resp.setRc("0");
			resp.setMsg("Password has been successfully created");
			return resp;
		} catch (Exception e) {
			log.info("error: " + e);
			
			resp.setRc("-1");
			resp.setMsg("Error creating password");
			return resp;
		}
	}

	@Override
	public void saveEvent(String username, String eventId, String observation, String rc) {
		
		String sql = "INSERT INTO ADMCONS_USER_LOGS (USER_ID, EVENT_ID, EVENT_TIME, RC, OBSERVATIONS) VALUES (:userId, :eventId, SYSDATE, :rc, :observation)";
		
		try {
			
			Query query = entityManager.createNativeQuery(sql);
			query.setParameter("userId", username);
			query.setParameter("eventId", eventId);
			query.setParameter("rc", rc);
			query.setParameter("observation", observation);
			
			query.executeUpdate();
			
		} catch (Exception e) {
			log.info("No se pudo registrar el evento: " + e);
			
		}	
	}

	@Override
	public List<Object[]> getFinalUsersDetail(String tagpay) {
		log.info("Obteniendo detalle de usuario final");
		String sql = "SELECT dvc.tagpay identificacion,\n" +
				"dvc.firstname nombre,\n" +
				"dvc.lastname apellido,\n" +
				"TO_DATE(dvc.birthday,'dd/mm/yyyy') fecha_nacimiento,\n" +
				"dvc.nationality nacionalidad,\n" +
				"dvc.gender genero,\n" +
				"dvca.address direccion,\n" +
				"dvca.sector sector,\n" +
				"dvca.municipality municipio\n" +
				"FROM DO_VIP_CUSTOMERS dvc\n" +
				"JOIN do_vip_status dvs on dvc.status=dvs.id_status\n" +
				"JOIN DO_VIP_CUSTOMER_ADDRESS dvca on dvc.tagpay=dvca.customer_id\n" +
				"WHERE dvc.tagpay=:id ";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter("id", tagpay);
		return (List<Object[]>) query.getResultList();
	}

	@Override
	public List<Object[]> getEmailsUser(String tagpay) {
		log.info("Obteniendo lista de correos de usuario final");
		String sql = "select email from do_vip_customer_emails where customer_id= :id ORDER BY primary_email DESC";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter("id", tagpay);
		return (List<Object[]>) query.getResultList();
	}

	@Override
	public List<Object[]> getPhonesUser(String tagpay) {
		log.info("Obteniendo lista de telefonos");
		String sql = "select cell_phone from do_vip_customer_phones where customer_id= :id ORDER BY primary_phone DESC";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter("id", tagpay);
		return (List<Object[]>) query.getResultList();
	}

	@Override
	public List<Object[]> getDeviceUser(String tagpay) {
		log.info("Obteniendo lista de dispositivos asociados al usuario");
		String sql = "select \n" +
				"x.host_device_id,\n" +
				"x.operating_system,\n"+
				"x.date_created\n" +
				"from do_vip_customer_device x\n" +
				"join do_vip_customers y on x.customer_id=y.tagpay\n" +
				" where x.customer_id=:id AND x.operating_system!='WEB'";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter("id", tagpay);
		return (List<Object[]>) query.getResultList();
	}

	@Override
	public Object getStatusUser(String status, String column) {
		log.info("Obteniendo lista de telefonos");
		String sql = "SELECT "+column+" FROM admcons_status_user WHERE ID_STATUS= :id";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter("id", status);
		return (Object) query.getSingleResult();
	}

	@Override
	public ResponseTO deleteUser(String username) {
		log.info("Eliminando usuario " + username);
		ResponseTO response = new ResponseTO();
		
		String sql = "UPDATE ADMCONS_USERS SET user_status = '0', dropped_out = SYSDATE WHERE User_Id = :id AND user_status = '1'";
		
		try {
			Query query = entityManager.createNativeQuery(sql);
			query.setParameter("id", username);
			query.executeUpdate();
			
			log.info("Usuario eliminado satisfactoriamente");
			
			response.setRc("0");
			response.setMsg("User has been successfully deleted");
			return response;
		} catch (Exception e) {
			
			log.info("error: " + e);
			
			response.setRc("-1");
			response.setMsg("Error deleting user");
			return response;
			
		}
		
	}

	@Override
	public ResponseTO deleteUserRoles(String username) {
		log.info("Eliminando rol de usuario " + username);
		ResponseTO response = new ResponseTO();
		
		String sql = "UPDATE ADMCONS_USER_ROLES SET role_status = '0', to_date = SYSDATE WHERE User_Id = :id AND role_status = '9'";
		
		try {
			Query query = entityManager.createNativeQuery(sql);
			query.setParameter("id", username);
			query.executeUpdate();
			
			log.info("Rol eliminado satisfactoriamente");
			
			response.setRc("0");
			response.setMsg("Role has been successfully deleted");
			return response;
		} catch (Exception e) {
			
			log.info("error: " + e);
			
			response.setRc("-1");
			response.setMsg("Error deleting role");
			return response;
			
		}
		
	}

	@Override
	public ResponseTO deleteUserPassword(String username) {
		log.info("Eliminando password de usuario " + username);
		
		ResponseTO response = new ResponseTO();
		
		String sql = "UPDATE ADMCONS_USER_PASSWORDS SET passw_status = '0', user_status = '0', to_date = SYSDATE WHERE (User_Id = :id AND user_status = '1') OR (User_Id = :id AND user_status = '3') OR (User_Id = :id AND user_status = '4')";
		
		try {
			
			Query query = entityManager.createNativeQuery(sql);
			query.setParameter("id", username);
			query.executeUpdate();
			
			log.info("Password eliminada satisfactoriamente");
			
			response.setRc("0");
			response.setMsg("Password has been successfully deleted");
			return response;
		} catch (Exception e) {
			
			log.info("error: " + e);
			
			response.setRc("-1");
			response.setMsg("Error deleting password");
			return response;
			
		}
		
	}

	@Override
	public ResponseTO deleteUserBranchOffice(String username) {
		log.info("Eliminando sucursal de usuario " + username);
		
		ResponseTO response = new ResponseTO();
		
		String sql = "UPDATE ADMCONS_USER_BRANCH_OFFICE SET status = '0', to_date = SYSDATE WHERE User_Id = :id AND status = '1'";
		
		try {
			Query query = entityManager.createNativeQuery(sql);
			query.setParameter("id", username);
			query.executeUpdate();
			
			log.info("Sucursal eliminada satisfactoriamente");
			
			response.setRc("0");
			response.setMsg("Sucursal eliminada satisfactoriamente");
			return response;
		} catch (Exception e) {
			
			log.info("error: " + e);
			
			response.setRc("-1");
			response.setMsg("Error al eliminar sucursal");
			return response;
			
		}
		
	}

	@Override
	public ResponseTO editUser(NewUser user) {
		log.info("Editando usuario: " + user.getUser_id());
		ResponseTO response = new ResponseTO();
		
		String sql = "UPDATE ADMCONS_USERS SET national_id = :natId, user_email = :email, user_firstname = :fName, user_middlename = :mName, user_lastname = :lName, user_secondsurname = :sName, user_phone_code = :code, user_telephone = :phone, user_job = :job, user_job_area = :area, last_updated = SYSDATE WHERE User_Id = :id AND user_status = '1'";
		
		UserApp nuevoUser = new UserApp();
		nuevoUser.setId(user.getUser_id());
		nuevoUser.setNationalId(user.getNational_id());
		nuevoUser.setEmail(user.getUser_email());
		nuevoUser.setFirstName(user.getUser_firstname());
		nuevoUser.setMiddleName(user.getUser_middlename());
		nuevoUser.setLastName(user.getUser_lastname());
		nuevoUser.setSurName(user.getUser_secondsurname());
		nuevoUser.setTelephone(user.getUser_telephone());
		nuevoUser.setPhoneCode(user.getPhone_code());
		nuevoUser.setJob(user.getUser_job());
		nuevoUser.setJobArea(user.getUser_job_area());
		nuevoUser.setIsAdmin("0");
		
		AdmconsStatus statusUsr = new AdmconsStatus();
		statusUsr.setStatusId("1");
		nuevoUser.setUserStatus(statusUsr);
		
		try {
			
			Query query = entityManager.createNativeQuery(sql);
			query.setParameter("id", user.getUser_id());
			query.setParameter("natId", user.getNational_id());
			query.setParameter("email", user.getUser_email());
			query.setParameter("fName", user.getUser_firstname());
			query.setParameter("mName", user.getUser_middlename());
			query.setParameter("lName", user.getUser_lastname());
			query.setParameter("sName", user.getUser_secondsurname());
			query.setParameter("code", user.getPhone_code());
			query.setParameter("phone", user.getUser_telephone());
			query.setParameter("job", user.getUser_job());
			query.setParameter("area", user.getUser_job_area());
			query.executeUpdate();
			
			log.info("Usuario editado satisfactoriamente");
			
			response.setRc("0");
			response.setMsg("User has been successfully edited");
			response.setObject(nuevoUser);
			return response;
			
		} catch (Exception e) {
			
			log.info("error: " + e);
			
			response.setRc("-1");
			response.setMsg("Error editing user");
			return response;
		}
		
	}

	@Override
	public ResponseTO editUserRoles(Role rol, UserApp user) {
		log.info("Editando rol de usuario: " + user.getId());
		ResponseTO response = new ResponseTO();
		
		String sql = "UPDATE ADMCONS_USER_ROLES SET role_id = :roleId WHERE user_id = :id and role_status = '9'";
		
		try {
			Query query = entityManager.createNativeQuery(sql);
			query.setParameter("id", user.getId());
			query.setParameter("roleId", rol.getId());
			query.executeUpdate();
			
			log.info("Rol de usuario editado satisfactoriamente");
			
			response.setRc("0");
			response.setMsg("Role has been successfully edited");
			return response;
		} catch (Exception e) {
			log.info("error: " + e);
			
			response.setRc("-1");
			response.setMsg("Error editing role");
			return response;
		}
	}

	@Override
	public ResponseTO editUserBranchOffice(UserApp userApp, AdmconsBranchOffices branchOffice) {
		log.info("Editando sucursal de usuario: " + userApp.getId());
		ResponseTO response = new ResponseTO();
		
		String sql = "UPDATE ADMCONS_USER_BRANCH_OFFICE SET branch_id = :branchId WHERE user_id = :id and status = '1'";
		
		try {
			Query query = entityManager.createNativeQuery(sql);
			query.setParameter("id", userApp.getId());
			query.setParameter("branchId", branchOffice.getBranchId());
			query.executeUpdate();
			
			log.info("Sucursal de usuario editado satisfactoriamente");
			
			response.setRc("0");
			response.setMsg("Sucursal de usuario editado satisfactoriamente");
			return response;
		} catch (Exception e) {
			log.info("error: " + e);
			
			response.setRc("-1");
			response.setMsg("Error al editar Sucursal de usuario");
			return response;
		}
	}

	@Override
	public ResponseTO blockUserAccess(String username) {
		log.info("Bloqueando acceso de usuario " + username);
		ResponseTO response = new ResponseTO();
		
		try {
			
			String sql = "UPDATE ADMCONS_USERS SET USER_STATUS = '3' WHERE USER_ID = :username AND USER_STATUS = '1'";
			Query query = entityManager.createNativeQuery(sql);
			query.setParameter("username", username);
			query.executeUpdate();
			
			log.info("Acceso de usuario " + username + " bloqueado satisfactoriamente");
			
			response.setRc("0");
			response.setMsg("Access to user: " + username + " has been successfully locked");
			return response;
			
		} catch (Exception e) {
			log.info("error: " + e);
			
			response.setRc("-1");
			response.setMsg("Error locking to user: " + username);
			return response;
		}
	}

	@Override
	public ResponseTO unblockUserAccess(String username) {
		log.info("Desbloqueando acceso de usuario " + username);
		ResponseTO response = new ResponseTO();
		
		try {
			
			String sql = "UPDATE ADMCONS_USERS SET USER_STATUS = '1' WHERE USER_ID = :username AND USER_STATUS = '3'";
			Query query = entityManager.createNativeQuery(sql);
			query.setParameter("username", username);
			query.executeUpdate();
			
			log.info("Acceso de usuario " + username + " desbloqueado satisfactoriamente");
			
			response.setRc("0");
			response.setMsg("Access to user: " + username + " has been successfully unlocked");
			return response;
		} catch (Exception e) {
			log.info("error: " + e);
			
			response.setRc("-1");
			response.setMsg("Error unlocking user: " + username);
			return response;
		}
	}

	@Override
	public UserApp findBlockedUserAccess(String username) {
		log.info("Buscando usuario con acceso bloqueado");
		
		try {
			String sql = "SELECT u FROM " +  UserApp.class.getName() + " u WHERE u.id = :username AND u.userStatus.statusId = '3'";
			Query query = entityManager.createQuery(sql, UserApp.class);
			query.setParameter("username", username);
			
			return (UserApp) query.getSingleResult();
		} catch (NoResultException e) {
			log.info("No se encontro usuario con acceso bloqueado");
			
			return null;
		}
	}
}
