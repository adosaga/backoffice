package com.novo.adminconsole.config;

import static com.novo.adminconsole.utils.Constants.PROPERTIES_FILE;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;
import com.novo.adminconsole.utils.Utils;

/**
 * 
 * @author cagarcia
 *
 */
@Configuration
public class TokenOauth {

	private String refreshToken;
	private String accessToken;
	
    private final static Logger log = Logger.getLogger(TokenOauth.class);

    @Bean(name="getTokenBean")
    public String getToken() {
        log.info("Getting first token");
        
        Properties properties = Utils.getConfig(PROPERTIES_FILE);
        RestTemplate restTemplate = new RestTemplate();
        Gson gson = new Gson();
        HttpHeaders header = new HttpHeaders();
        Map<String,String> mapBody = new HashMap<>();

        List<MediaType> acceptH = new ArrayList<>();
        acceptH.add(MediaType.APPLICATION_JSON);
        header.setContentType(MediaType.APPLICATION_JSON);
        header.setAccept(acceptH);
        header.add("x-channel", properties.getProperty("country_header"));
        header.add("x-language", properties.getProperty("languaje"));
        
        //getting access token by first time
        mapBody.put("grant_type", properties.getProperty("geoip_grant_type"));
        mapBody.put("client_id", properties.getProperty("geoip_client_id"));        
        mapBody.put("client_secret", properties.getProperty("geoip_client_secret"));
        String url = properties.getProperty("geoip.token.url");
        
        HttpEntity<String> request = new HttpEntity<>(gson.toJson(mapBody), header);

        try {
            ResponseEntity<HashMap> token =  restTemplate.postForEntity(url, request, HashMap.class);            
            this.refreshToken = token.getBody().get("refreshToken").toString();
            this.accessToken = token.getBody().get("accessToken").toString();
            String msg = accessToken==null?"access token is null":"access token generated successfuly";
            log.info("main token: "+msg);
        } catch (Exception e) {
           log.error("Error invoking main token service: " + e);
        }
        return refreshToken;
    }

    public String getRefreshedToken() {
        log.info("Getting refresh token");
        
        Properties properties = Utils.getConfig(PROPERTIES_FILE);
        RestTemplate restTemplate = new RestTemplate();
        Gson gson = new Gson();
        HttpHeaders header = new HttpHeaders();
        Map<String,String> mapBody = new HashMap<>();
        String url = null;

        List<MediaType> acceptH = new ArrayList<>();
        acceptH.add(MediaType.APPLICATION_JSON);
        header.setContentType(MediaType.APPLICATION_JSON);
        header.setAccept(acceptH);
        header.add("x-channel", properties.getProperty("country_header"));
        header.add("x-language", properties.getProperty("languaje"));
        
        //getting access token by refresh token
        mapBody.put("refresh_token", this.refreshToken);
        url = properties.getProperty("geoip.refresh.url");
                
        HttpEntity<String> request = new HttpEntity<>(gson.toJson(mapBody), header);

        try { log.info("url: "+url); log.info("request: "+gson.toJson(request));
            ResponseEntity<HashMap> token =  restTemplate.postForEntity(url, request, HashMap.class);            
            this.refreshToken = token.getBody().get("refresh_token").toString();
            this.accessToken = token.getBody().get("access_token").toString();
            String msg = accessToken==null?"access token is null":"access token generated successfuly";
            log.info("refresh token: "+msg);
        } catch (Exception e) {
           log.error("Error invoking refres-token service: " + e);
        }
        
        return this.accessToken;
    }    
}
