package com.novo.adminconsole.controllers;

import java.security.Principal;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.google.gson.Gson;
import com.novo.adminconsole.TO.ResponseAccessTO;
import com.novo.adminconsole.TO.ResponseModFuncTO;
import com.novo.adminconsole.TO.ResponseRoleAssocTO;
import com.novo.adminconsole.TO.ResponseRoleTO;
import com.novo.adminconsole.models.service.IRoleService;
import com.novo.adminconsole.models.service.IUserService;
import com.novo.adminconsole.utils.Role;
import com.novo.adminconsole.utils.RoleAssoc;

import static com.novo.adminconsole.utils.Constants.CONFIG_ROL_MODULE_ID;
import static com.novo.adminconsole.utils.Constants.LISTAR_ROLES_ID;
import static com.novo.adminconsole.utils.Constants.CREAR_ROLES_ID;
import static com.novo.adminconsole.utils.Constants.OBTENER_ROLES_ID;
import static com.novo.adminconsole.utils.Constants.EDITAR_ROLES_ID;
import static com.novo.adminconsole.utils.Constants.ACTIVAR_ROLES_ID;
import static com.novo.adminconsole.utils.Constants.DESACTIVAR_ROLES_ID;
import static com.novo.adminconsole.utils.Constants.ASOCIAR_PERMISO_ROLES_ID;
import static com.novo.adminconsole.utils.Constants.ACTIVAR_PERMISO_ROLES_ID;
import static com.novo.adminconsole.utils.Constants.DESACTIVAR_PERMISO_ROLES_ID;

@Controller
public class RoleController {
	
	@Autowired
	private IUserService userService;
	
	@Autowired
	private IRoleService roleService;
	
	private final Logger log = Logger.getLogger(RoleController.class);
	
	@GetMapping("/config/role/list")
	public String listarRoles(Model model, Principal principal, HttpSession httpSession, RedirectAttributes flash) {
		 User loggedUser = (User) ((Authentication) principal).getPrincipal();
		 model.addAttribute("userInfo", loggedUser.getUsername());
		 String roleId = httpSession.getAttribute("roleId").toString(); 
		  
		 log.info("Verificando accesos a modulo roles");
			ResponseEntity<ResponseAccessTO> responseAccess = roleService.obtenerPermisos(roleId, CONFIG_ROL_MODULE_ID);
			
			HttpStatus statusAccess = responseAccess.getStatusCode();
			
			if (statusAccess == HttpStatus.OK) {
				
				ResponseAccessTO bodyAccess = responseAccess.getBody();
				Map<String,String> accessObject = bodyAccess.getAccess();
				log.info("accessObject: " + accessObject);
				
				if(!accessObject.isEmpty()) {
						
						try {
							
							String LISTAR_ROLES = accessObject.containsKey(LISTAR_ROLES_ID)?accessObject.get(LISTAR_ROLES_ID).toString():null;
							String CREAR_ROLES = accessObject.containsKey(CREAR_ROLES_ID)?accessObject.get(CREAR_ROLES_ID).toString():null;
							String OBTENER_ROLES = accessObject.containsKey(OBTENER_ROLES_ID)?accessObject.get(OBTENER_ROLES_ID).toString():null;
							String EDITAR_ROLES = accessObject.containsKey(EDITAR_ROLES_ID)?accessObject.get(EDITAR_ROLES_ID).toString():null;
							String ACTIVAR_ROLES = accessObject.containsKey(ACTIVAR_ROLES_ID)?accessObject.get(ACTIVAR_ROLES_ID).toString():null;
							String DESACTIVAR_ROLES = accessObject.containsKey(DESACTIVAR_ROLES_ID)?accessObject.get(DESACTIVAR_ROLES_ID).toString():null;
							String ASOCIAR_PERMISO_ROLES = accessObject.containsKey(ASOCIAR_PERMISO_ROLES_ID)?accessObject.get(ASOCIAR_PERMISO_ROLES_ID).toString():null;
							String ACTIVAR_PERMISO_ROLES = accessObject.containsKey(ACTIVAR_PERMISO_ROLES_ID)?accessObject.get(ACTIVAR_PERMISO_ROLES_ID).toString():null;
							String DESACTIVAR_PERMISO_ROLES = accessObject.containsKey(DESACTIVAR_PERMISO_ROLES_ID)?accessObject.get(DESACTIVAR_PERMISO_ROLES_ID).toString():null;
								
							model.addAttribute("LISTAR_ROLES", LISTAR_ROLES);
							model.addAttribute("CREAR_ROLES", CREAR_ROLES);
							model.addAttribute("OBTENER_ROLES", OBTENER_ROLES);
							model.addAttribute("EDITAR_ROLES", EDITAR_ROLES);
							model.addAttribute("ACTIVAR_ROLES", ACTIVAR_ROLES);
							model.addAttribute("DESACTIVAR_ROLES", DESACTIVAR_ROLES);
							model.addAttribute("ASOCIAR_PERMISO_ROLES", ASOCIAR_PERMISO_ROLES);
							model.addAttribute("ACTIVAR_PERMISO_ROLES", ACTIVAR_PERMISO_ROLES);
							model.addAttribute("DESACTIVAR_PERMISO_ROLES", DESACTIVAR_PERMISO_ROLES);
							
							log.info("Consumiendo API LISTAR ROLES");
							ResponseEntity<ResponseRoleTO> response = roleService.listarRoles();
							
							HttpStatus statusCode = response.getStatusCode();
							
							if (statusCode == HttpStatus.OK) {
								ResponseRoleTO body = response.getBody();
								List<Role> listaRole = body.getRoleList();
								model.addAttribute("listaRole", listaRole);
								
								Role modalObject = new Role();
								model.addAttribute("deactivate", modalObject);
								model.addAttribute("activate", modalObject);
								
								@SuppressWarnings("unchecked")
								List<String> menu = (List<String>) httpSession.getAttribute("menu");
								model.addAttribute("menu", menu);
								
								@SuppressWarnings("unchecked")
								List<String> menuModules = (List<String>) httpSession.getAttribute("menuModules");
								model.addAttribute("menuModules", menuModules);
								
								model.addAttribute("userInfo", loggedUser.getUsername());
								model.addAttribute("titulo", "Roles");
								
								userService.saveEvent(loggedUser.getUsername(), "95", "Listando roles", "0");
								
								return "configurations/roles/listRoles";
							} else {

								userService.saveEvent(loggedUser.getUsername(), "95", "Error al listar roles", "-1");
								flash.addFlashAttribute("error", "Role list is not available");
								return "redirect:/dashboard";
							}	
								
						} catch (Exception e) {
							log.info("roleId: "+ roleId +" It is not possible to access");
							userService.saveEvent(loggedUser.getUsername(), "95", "roleId: "+ roleId +" It is not possible to access", "-1");
							flash.addFlashAttribute("error", "It is not possible to access");
							return "redirect:/dashboard";
							
						}
						
					}else {
						
						userService.saveEvent(loggedUser.getUsername(), "95", "roleId: "+ roleId +" It is not possible to access", "-1");
						flash.addFlashAttribute("error", "It is not possible to access");
						return "redirect:/dashboard";
					}
				
			} else {

				userService.saveEvent(loggedUser.getUsername(), "95", "roleId: "+ roleId +" It is not possible to access", "-1");
				flash.addFlashAttribute("error", "It is not possible to access");
				return "redirect:/dashboard";
				
			}
	}
	
	@GetMapping("/config/role/nuevo")
	public String crearRol(Model model, Principal principal, HttpSession httpSession, RedirectAttributes flash) {
		
		Role role = new Role();
		
		@SuppressWarnings("unchecked")
		List<String> menu = (List<String>) httpSession.getAttribute("menu");
		model.addAttribute("menu", menu);
		
		@SuppressWarnings("unchecked")
		List<String> menuModules = (List<String>) httpSession.getAttribute("menuModules");
		model.addAttribute("menuModules", menuModules);
		
		User loggedUser = (User) ((Authentication) principal).getPrincipal();
		model.addAttribute("userInfo", loggedUser.getUsername());
		
		model.addAttribute("titulo", "New role");
		model.addAttribute("role", role);
		
		return "configurations/roles/newRol";
	}
	
	@PostMapping("/config/role/create")
	public String generarRol(@ModelAttribute("role") Role role, Model model, Principal principal, HttpSession httpSession, RedirectAttributes flash) {
		User loggedUser = (User) ((Authentication) principal).getPrincipal();
		model.addAttribute("userInfo", loggedUser.getUsername());
		log.info("Consumiendo API LISTAR ROLES");
		ResponseEntity<ResponseRoleTO> response = roleService.listarRoles();
				
		HttpStatus statusCode = response.getStatusCode();
				
		if (statusCode == HttpStatus.OK) {
			ResponseRoleTO body = response.getBody();
			List<Role> listaRole = body.getRoleList();
			
			if (listaRole != null) {
				for (Role item : listaRole) {
					
					if (item.getRoleName().toLowerCase().equals(role.getRoleName().toLowerCase())) {
						
						userService.saveEvent(loggedUser.getUsername(), "97", "Role name " + role.getRoleName() + " already exists", "-1");
						flash.addFlashAttribute("error", "Role name " + role.getRoleName() + " already exists");
						return "redirect:/config/role/nuevo";	
					}
				}
			}
			
			log.info("Consumiendo API CREAR ROLE");
			ResponseEntity<ResponseRoleTO> responseCrear = roleService.crearRol(role);
			
			HttpStatus codigo = responseCrear.getStatusCode();
			
			if (codigo == HttpStatus.OK) {
				
				userService.saveEvent(loggedUser.getUsername(), "97", "Role " + role.getRoleName() + " Role created with success", "0");
				flash.addFlashAttribute("success", "Role created with success");
				return "redirect:/config/role/list";
			} else {

				userService.saveEvent(loggedUser.getUsername(), "97", "Fail to create Role", "-1");
				flash.addFlashAttribute("error", "Fail to create Role: Role creation is not available");
				return "redirect:/config/role/nuevo";
			}
		}else{
			
			userService.saveEvent(loggedUser.getUsername(), "97", "Fail to create Role", "-1");
			flash.addFlashAttribute("error", "Fail to create Role: Role creation is not available");
			return "redirect:/config/role/nuevo";	
		}
	}
	
	@GetMapping("/config/role/editar/{id}")
	public String editarRol(@PathVariable(name = "id") String id, Model model, Principal principal, HttpSession httpSession, RedirectAttributes flash) {
		
		User loggedUser = (User) ((Authentication) principal).getPrincipal();
		model.addAttribute("userInfo", loggedUser.getUsername());
		Role singleRole = new Role();
		singleRole.setRoleId(id);
		
		log.info("Consumiendo API OBTENER ROL");
		ResponseEntity<ResponseRoleTO> response = roleService.obtenerRol(singleRole);
		
		HttpStatus statusCode = response.getStatusCode();
		
		if (statusCode == HttpStatus.OK) {
			
			ResponseRoleTO body = response.getBody();
			Role role = body.getRoleList().get(0);
			
			@SuppressWarnings("unchecked")
			List<String> menu = (List<String>) httpSession.getAttribute("menu");
			model.addAttribute("menu", menu);
			
			@SuppressWarnings("unchecked")
			List<String> menuModules = (List<String>) httpSession.getAttribute("menuModules");
			model.addAttribute("menuModules", menuModules);
			
			model.addAttribute("userInfo", loggedUser.getUsername());
			model.addAttribute("titulo", "Edit Role");
			model.addAttribute("role", role);
			
			return "configurations/roles/editRol";
		} else {
		
			userService.saveEvent(loggedUser.getUsername(), "96", "Error searching role identified by ID " + id, "-1");
			flash.addFlashAttribute("error", "Role searching is not available");
			return "redirect:/config/role/list";
		}	
	}
	
	@PostMapping("/config/role/edit")
	public String guardarEditarRole(@ModelAttribute("role") Role role, Model model, Principal principal, HttpSession httpSession, RedirectAttributes flash) {
		User loggedUser = (User) ((Authentication) principal).getPrincipal();
		model.addAttribute("userInfo", loggedUser.getUsername());
		log.info("Consumiendo API EDITAR ROL");
		ResponseEntity<ResponseRoleTO> response = roleService.editarRol(role);
		
		HttpStatus statusCode = response.getStatusCode();
		
		if(statusCode == HttpStatus.OK) {
			
			userService.saveEvent(loggedUser.getUsername(), "98", "Role: "+role.getRoleName()+" was success edited", "0");
			flash.addFlashAttribute("success", "Role: "+role.getRoleName()+" was success edited");
			return "redirect:/config/role/list";
		}else {
			
			userService.saveEvent(loggedUser.getUsername(), "98", "Error editing role: " + role.getRoleName(), "-1");
			flash.addFlashAttribute("error", "Role edition is not available");
			return "redirect:/config/role/list";
		}
	}
	
	@PostMapping("/config/role/activate")
	public String activarRol(@ModelAttribute("activate") Role role, Model model, Principal principal, HttpSession httpSession, RedirectAttributes flash) {
		User loggedUser = (User) ((Authentication) principal).getPrincipal();
		model.addAttribute("userInfo", loggedUser.getUsername());
		role.setRoleStatus("9");
		
		log.info("Consumiendo API ACTIVAR ROL");
		ResponseEntity<ResponseRoleTO> response = roleService.activarRol(role);
		
		HttpStatus statusCode = response.getStatusCode();
		
		if(statusCode == HttpStatus.OK){
		
			userService.saveEvent(loggedUser.getUsername(), "99", "Role " + role.getRoleId() + " was success activated", "0");
			flash.addFlashAttribute("success", "Role " + role.getRoleId() + " was success activated");
			return "redirect:/config/role/list";
		}else {
			
			userService.saveEvent(loggedUser.getUsername(), "99", "Error activating Rol " + role.getRoleId(), "-1");
			flash.addFlashAttribute("error", "Role activation is not available");
			return "redirect:/config/role/list";
		}
	}
	
	@PostMapping("/config/role/deactivate")
	public String desactivarRol(@ModelAttribute("deactivate") Role role, Model model, Principal principal, HttpSession httpSession, RedirectAttributes flash) {
		User loggedUser = (User) ((Authentication) principal).getPrincipal();
		model.addAttribute("userInfo", loggedUser.getUsername());
		role.setRoleStatus("11");
		
		log.info("Consumiendo API DESACTIVAR ROL");
		ResponseEntity<ResponseRoleTO> response = roleService.desactivarRol(role);
		
		HttpStatus statusCode = response.getStatusCode();
		
		if(statusCode == HttpStatus.OK){
		
			userService.saveEvent(loggedUser.getUsername(), "100", "Role " + role.getRoleId() + " was success deactivated", "0");
			flash.addFlashAttribute("success", "Role " + role.getRoleId() + " was success deactivated");
			return "redirect:/config/role/list";
		}else {
			
			userService.saveEvent(loggedUser.getUsername(), "100", "Error deactivating Role " + role.getRoleId(), "-1");
			flash.addFlashAttribute("error", "Role deactivation is not available");
			return "redirect:/config/role/list";
		}
	}
	
	@GetMapping("/config/role/associate")
	public String vistaAsociarRol(@RequestParam(value = "roleId") String roleId, @RequestParam(value = "assoc" , required = false) String assoc, @RequestParam(value = "act" , required = false) String act, @RequestParam(value = "deact" , required = false) String deact, Model model, Principal principal, HttpSession httpSession, RedirectAttributes flash) {
		User loggedUser = (User) ((Authentication) principal).getPrincipal();
		model.addAttribute("userInfo", loggedUser.getUsername());
		Role singleRole = new Role();
		singleRole.setRoleId(roleId);

		String userRoleId = httpSession.getAttribute("roleId").toString(); 
		  
		 log.info("Verificando accesos a modulo roles");
			ResponseEntity<ResponseAccessTO> responseAccess = roleService.obtenerPermisos(userRoleId, CONFIG_ROL_MODULE_ID);
			
			HttpStatus statusAccess = responseAccess.getStatusCode();
			
			if (statusAccess == HttpStatus.OK) {
				
				ResponseAccessTO bodyAccess = responseAccess.getBody();
				Map<String,String> accessObject = bodyAccess.getAccess();
				log.info("accessObject: " + accessObject);
				
				if(!accessObject.isEmpty()) {
						
						try {
							
							String OBTENER_ROLES = accessObject.get(OBTENER_ROLES_ID).toString();
							String ASOCIAR_PERMISO_ROLES = accessObject.get(ASOCIAR_PERMISO_ROLES_ID).toString();
							String ACTIVAR_PERMISO_ROLES = accessObject.get(ACTIVAR_PERMISO_ROLES_ID).toString();
							String DESACTIVAR_PERMISO_ROLES = accessObject.get(DESACTIVAR_PERMISO_ROLES_ID).toString();
								
							model.addAttribute("OBTENER_ROLES", OBTENER_ROLES);
							model.addAttribute("ASOCIAR_PERMISO_ROLES", ASOCIAR_PERMISO_ROLES);
							model.addAttribute("ACTIVAR_PERMISO_ROLES", ACTIVAR_PERMISO_ROLES);
							model.addAttribute("DESACTIVAR_PERMISO_ROLES", DESACTIVAR_PERMISO_ROLES);
							
							log.info("Consumiendo API OBTENER ROL");
							ResponseEntity<ResponseRoleTO> response = roleService.obtenerRol(singleRole);
							
							HttpStatus statusCode = response.getStatusCode();
							
							if (statusCode == HttpStatus.OK) {
								
								ResponseRoleTO body = response.getBody();
								Role role = body.getRoleList().get(0);
								
								//validacion de mensajes
								if(assoc != null) {
									if(assoc.equals("true")) {
										
										model.addAttribute("success", "Access has been successfully associated");
									}else {
										
										model.addAttribute("error", "Access association is not available");
									}	
								}else {
									if (act != null) {
										if (act.equals("true")) {
											
											model.addAttribute("success", "Access has been successfully activated");
										} else {
											
											model.addAttribute("error", "Access activation is not available");
										}
										
									} else {
										if (deact != null) {
											if (deact.equals("true")) {
												
												model.addAttribute("success", "Access has been successfully deactivated");
											} else {
												
												model.addAttribute("error", "Access deactivation is not available");
											}
										} 
									}
								}
								Gson gson = new Gson();
								log.info("Consumiendo API OBTENER LISTADO DE PERMISOS ASOCIADOS");
								ResponseEntity<ResponseRoleAssocTO> responseAssocc = roleService.listarAsociados(role.getRoleId());
								log.info("responseAssocc"+gson.toJson(responseAssocc));
								
								statusCode = response.getStatusCode();
								
								if (statusCode == HttpStatus.OK) {
									
									log.info("Consumiendo API OBTENER MODULOS Y FUNCIONES");
									ResponseEntity<ResponseModFuncTO> responseModules = roleService.obtenerModulosyFunciones();
									log.info("responseModules"+gson.toJson(responseModules));
									
									statusCode = responseModules.getStatusCode();
									
									if (statusCode == HttpStatus.OK) {
										
										RoleAssoc modalObj = new RoleAssoc();
										
										model.addAttribute("newAssoc", modalObj);
										model.addAttribute("activate", modalObj);
										model.addAttribute("deactivate", modalObj);
										
										@SuppressWarnings("unchecked")
										List<String> menu = (List<String>) httpSession.getAttribute("menu");
										model.addAttribute("menu", menu);
										
										@SuppressWarnings("unchecked")
										List<String> menuModules = (List<String>) httpSession.getAttribute("menuModules");
										model.addAttribute("menuModules", menuModules);
										
										model.addAttribute("userInfo", loggedUser.getUsername());
										model.addAttribute("titulo", "Associate functions and modules to roles");
										model.addAttribute("role", role);
										
										ResponseRoleAssocTO bodyListaPermisosAssoc = responseAssocc.getBody();
										List<RoleAssoc> listaPermisosAssoc = bodyListaPermisosAssoc.getRoleAssocList();
										model.addAttribute("listaPermisosAssoc", listaPermisosAssoc);
										
										
										log.info("listaPermisosAssoc: "+gson.toJson(listaPermisosAssoc));
										
										ResponseModFuncTO bodyModFunc = responseModules.getBody();
										List<RoleAssoc> listaModulos = bodyModFunc.getRoleAssocList();
										model.addAttribute("listaModulos", listaModulos);
										
										log.info("listaModulos: "+gson.toJson(listaModulos));
										
										return "configurations/roles/assocRol";
									} else {

										userService.saveEvent(loggedUser.getUsername(), "101", "Error getting module and function list", "-1");
										flash.addFlashAttribute("error", "Modules and functions are not available");
										return "redirect:/config/role/list";
									}
								} else {

									userService.saveEvent(loggedUser.getUsername(), "101", "Error getting allowed acces to the role ID: " + roleId, "-1");
									flash.addFlashAttribute("error", "List of allowed access is not available");
									return "redirect:/config/role/list";
								}
								
							} else {
							
								userService.saveEvent(loggedUser.getUsername(), "101", "Error searching role ID " + roleId, "-1");
								flash.addFlashAttribute("error", "Role searching is not available");
								return "redirect:/config/role/list";
							}
									
						} catch (Exception e) {
							log.info("roleId: "+ roleId +" It is not possible to access");
							userService.saveEvent(loggedUser.getUsername(), "101", "roleId: "+ userRoleId +" It is not possible to access", "-1");
							flash.addFlashAttribute("error", "It is not possible to access");
							return "redirect:/dashboard";
							
						}
						
					}else {
						
						userService.saveEvent(loggedUser.getUsername(), "95", "101: "+ userRoleId +" It is not possible to access", "-1");
						flash.addFlashAttribute("error", "It is not possible to access");
						return "redirect:/dashboard";
					}
				
			} else {

				userService.saveEvent(loggedUser.getUsername(), "95", "101: "+ userRoleId +" It is not possible to access", "-1");
				flash.addFlashAttribute("error", "It is not possible to access");
				return "redirect:/dashboard";
				
			}
	}
	
	@PostMapping("/config/role/associate/new")
	public String nuevoAssocRol(@ModelAttribute("newAssoc") RoleAssoc roleAssoc, Model model, Principal principal, HttpSession httpSession, RedirectAttributes flash) {
		User loggedUser = (User) ((Authentication) principal).getPrincipal();
		model.addAttribute("userInfo", loggedUser.getUsername());
		roleAssoc.setStatusId("9");
		
		log.info("Consumiendo API ASOCIAR NUEVO PERMISO A ROL");
		ResponseEntity<ResponseRoleAssocTO> response = roleService.asociarPermisos(roleAssoc);
		
		HttpStatus statusCode = response.getStatusCode();
		
		if(statusCode == HttpStatus.OK){
			
			userService.saveEvent(loggedUser.getUsername(), "101", "Permiso " + roleAssoc.getEventId() + " de rol " + roleAssoc.getRoleName() + " asociado", "0");
			return "redirect:/config/role/associate?roleId=" + roleAssoc.getRoleId() + "&assoc=true";
		}else {
			
			userService.saveEvent(loggedUser.getUsername(), "101", "Error al asociar permiso " + roleAssoc.getEventId() + " a Rol " + roleAssoc.getRoleName(), "-1");
			return "redirect:/config/role/associate?roleId=" + roleAssoc.getRoleId() + "&assoc=false";
		}
	}
	
	@PostMapping("/config/role/associate/activate")
	public String activarAssocRol(@ModelAttribute("activate") RoleAssoc roleAssoc, Model model, Principal principal, HttpSession httpSession, RedirectAttributes flash) {
		User loggedUser = (User) ((Authentication) principal).getPrincipal();
		model.addAttribute("userInfo", loggedUser.getUsername());
		roleAssoc.setStatusId("9");
		
		log.info("Consumiendo API ACTIVAR PERMISO DE ROL");
		ResponseEntity<ResponseRoleAssocTO> response = roleService.activarAsociacion(roleAssoc);
		
		HttpStatus statusCode = response.getStatusCode();
		
		if(statusCode == HttpStatus.OK){
		
			userService.saveEvent(loggedUser.getUsername(), "102", "Permiso " + roleAssoc.getEventId() + " de rol " + roleAssoc.getRoleName() + " activado", "0");
			return "redirect:/config/role/associate?roleId=" + roleAssoc.getRoleId() + "&act=true";
		}else {
			
			userService.saveEvent(loggedUser.getUsername(), "102", "Error al activar permiso " + roleAssoc.getEventId() + " a Rol " + roleAssoc.getRoleName(), "-1");
			return "redirect:/config/role/associate?roleId=" + roleAssoc.getRoleId() + "&act=false";
		}
	}
	
	@PostMapping("/config/role/associate/deactivate")
	public String desactivarAssocRol(@ModelAttribute("deactivate") RoleAssoc roleAssoc, Model model, Principal principal, HttpSession httpSession, RedirectAttributes flash) {
		User loggedUser = (User) ((Authentication) principal).getPrincipal();
		model.addAttribute("userInfo", loggedUser.getUsername());
		roleAssoc.setStatusId("11");
		
		log.info("Consumiendo API DESACTIVAR PERMISO DE ROL");
		ResponseEntity<ResponseRoleAssocTO> response = roleService.desactivarAsociacion(roleAssoc);
		
		HttpStatus statusCode = response.getStatusCode();
		
		if(statusCode == HttpStatus.OK){
		
			userService.saveEvent(loggedUser.getUsername(), "103", "Permiso " + roleAssoc.getEventId() + " de rol " + roleAssoc.getRoleName() + " desactivado", "0");
			return "redirect:/config/role/associate?roleId=" + roleAssoc.getRoleId() + "&deact=true";
		}else {
			
			userService.saveEvent(loggedUser.getUsername(), "103", "Error al activar permiso " + roleAssoc.getEventId() + " a Rol " + roleAssoc.getRoleName(), "-1");
			return "redirect:/config/role/associate?roleId=" + roleAssoc.getRoleId() + "&deact=false";
		}
	}
	

}
