package com.novo.adminconsole.models.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="ADMCONS_CATEGORIES")
public class AdmconsCategories implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@NotNull
	@Column(name = "CATEGORY_ID")
	private String categoryId;
	
	@Column(name = "CATEGORY_NAME")
	private String categoryName;
	
	@Column(name = "CATEGORY_DESC")
	private String categoryDesc;
	
	@JoinColumn(name = "AREA_ID", referencedColumnName = "AREA_ID")
	@ManyToOne
	private AdmconsArea categoryArea;
	
	@JoinColumn(name = "CATEGORY_STATUS", referencedColumnName = "STATUS_ID")
	@ManyToOne
	private AdmconsStatus categoryStatus;

	@Column(name="CREATED")
	@Temporal(TemporalType.TIMESTAMP)
	private Date created;
	
	public String getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public String getCategoryDesc() {
		return categoryDesc;
	}

	public void setCategoryDesc(String categoryDesc) {
		this.categoryDesc = categoryDesc;
	}

	public AdmconsStatus getCategoryStatus() {
		return categoryStatus;
	}

	public void setCategoryStatus(AdmconsStatus categoryStatus) {
		this.categoryStatus = categoryStatus;
	}

	public Date getCreated() {
		return created;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public AdmconsArea getCategoryArea() {
		return categoryArea;
	}

	public void setCategoryArea(AdmconsArea categoryArea) {
		this.categoryArea = categoryArea;
	}
}
