package com.novo.adminconsole.models.dao;

import java.util.List;


public interface IModuleDao {

	public List<String> getDisabledModules();
	
	public List<Object[]> getEnabledModules(String roleId);

	public List<Object[]> getListModules(String roleId);
	
}
