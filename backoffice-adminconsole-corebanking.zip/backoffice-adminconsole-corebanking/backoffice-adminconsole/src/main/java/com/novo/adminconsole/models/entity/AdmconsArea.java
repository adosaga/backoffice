package com.novo.adminconsole.models.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="ADMCONS_AREA")
public class AdmconsArea implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Id
	@NotNull
	@Column(name="AREA_ID")
	private String areaId;
	
	@Column(name="AREA_NAME")
	private String areaName;

	@JoinColumn(name = "AREA_STATUS", referencedColumnName = "STATUS_ID")
	@ManyToOne
	private AdmconsStatus areaStatus;
	
	@Column(name="CREATED")
	@Temporal(TemporalType.TIMESTAMP)
	private Date created;

	public String getAreaId() {
		return areaId;
	}

	public void setAreaId(String areaId) {
		this.areaId = areaId;
	}

	public String getAreaName() {
		return areaName;
	}

	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}

	public AdmconsStatus getAreaStatus() {
		return areaStatus;
	}

	public void setAreaStatus(AdmconsStatus areaStatus) {
		this.areaStatus = areaStatus;
	}

	public Date getCreated() {
		return created;
	}

	public void setCreated(Date created) {
		this.created = created;
	}
	
}
