package com.novo.adminconsole.TO;

import java.util.List;

/**
* @author cagarcia
*/
public class RspReportParamsTO {
	
	String rc;
	String msg;
	String timeStamp;
	List<ReportSearchParamsTO> reportList;
	
	public String getRc() {
		return rc;
	}
	public void setRc(String rc) {
		this.rc = rc;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public List<ReportSearchParamsTO> getReportList() {
		return reportList;
	}
	public void setReportList(List<ReportSearchParamsTO> reports) {
		this.reportList = reports;
	}
	public String getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}
	
}
