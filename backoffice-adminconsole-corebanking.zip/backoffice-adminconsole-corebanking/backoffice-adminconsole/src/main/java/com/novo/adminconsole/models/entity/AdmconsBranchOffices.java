package com.novo.adminconsole.models.entity;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author dfernandez
 */
@Entity
@Table(name = "ADMCONS_BRANCH_OFFICES")
public class AdmconsBranchOffices implements Serializable {
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "admconsBranchOffices")
    private Collection<AdmconsUserBranchOffice> admconsUserBranchOfficeCollection;
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "BRANCH_ID")
    private String branchId;
    @Size(max = 3)
    @Column(name = "BRANCH_COUNTRY")
    private String branchCountry;
    @Size(max = 50)
    @Column(name = "BRANCH_CITY")
    private String branchCity;
    @Size(max = 150)
    @Column(name = "BRANCH_ADDRESS")
    private String branchAddress;
    @Column(name = "CREATED")
    @Temporal(TemporalType.TIMESTAMP)
    private Date created;
    @Column(name = "LAST_UPDATED")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdated;
    @OneToMany(mappedBy = "branchId")
    private Collection<AdmconsDataForms> admconsDataFormsCollection;
    @JoinColumn(name = "BRANCH_STATUS", referencedColumnName = "STATUS_ID")
    @ManyToOne
    private AdmconsStatus branchStatus;
    @JoinColumn(name = "ISSUER_ID", referencedColumnName = "ISSUER_ID")
    @ManyToOne
    private AdmconsIssuers issuerId;
    @JoinColumn(name = "FINANCIAL_ENT_ID", referencedColumnName = "FINANCIAL_ENT_ID")
    @ManyToOne
    private AdmconsFinancialEntities financialEntId;

    public AdmconsBranchOffices() {
    }

    public AdmconsBranchOffices(String branchId) {
        this.branchId = branchId;
    }

    public String getBranchId() {
        return branchId;
    }

    public void setBranchId(String branchId) {
        this.branchId = branchId;
    }

    public String getBranchCountry() {
        return branchCountry;
    }

    public void setBranchCountry(String branchCountry) {
        this.branchCountry = branchCountry;
    }

    public String getBranchCity() {
        return branchCity;
    }

    public void setBranchCity(String branchCity) {
        this.branchCity = branchCity;
    }

    public String getBranchAddress() {
        return branchAddress;
    }

    public void setBranchAddress(String branchAddress) {
        this.branchAddress = branchAddress;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public Date getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(Date lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    @XmlTransient
    public Collection<AdmconsDataForms> getAdmconsDataFormsCollection() {
        return admconsDataFormsCollection;
    }

    public void setAdmconsDataFormsCollection(Collection<AdmconsDataForms> admconsDataFormsCollection) {
        this.admconsDataFormsCollection = admconsDataFormsCollection;
    }

    public AdmconsStatus getBranchStatus() {
        return branchStatus;
    }

    public void setBranchStatus(AdmconsStatus branchStatus) {
        this.branchStatus = branchStatus;
    }

    public AdmconsIssuers getIssuerId() {
        return issuerId;
    }

    public void setIssuerId(AdmconsIssuers issuerId) {
        this.issuerId = issuerId;
    }

    public AdmconsFinancialEntities getFinancialEntId() {
        return financialEntId;
    }

    public void setFinancialEntId(AdmconsFinancialEntities financialEntId) {
        this.financialEntId = financialEntId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (branchId != null ? branchId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof AdmconsBranchOffices)) {
            return false;
        }
        AdmconsBranchOffices other = (AdmconsBranchOffices) object;
        if ((this.branchId == null && other.branchId != null) || (this.branchId != null && !this.branchId.equals(other.branchId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.hm.plantillawarapplication.model.AdmconsBranchOffices[ branchId=" + branchId + " ]";
    }

    @XmlTransient
    public Collection<AdmconsUserBranchOffice> getAdmconsUserBranchOfficeCollection() {
        return admconsUserBranchOfficeCollection;
    }

    public void setAdmconsUserBranchOfficeCollection(Collection<AdmconsUserBranchOffice> admconsUserBranchOfficeCollection) {
        this.admconsUserBranchOfficeCollection = admconsUserBranchOfficeCollection;
    }
    
}