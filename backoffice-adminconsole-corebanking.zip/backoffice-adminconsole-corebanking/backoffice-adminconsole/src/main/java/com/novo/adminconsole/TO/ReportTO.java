package com.novo.adminconsole.TO;

import java.util.List;

public class ReportTO 
{
    private String nombre;
    private byte[] archivo;
    private String formatoArchivo;
    private String rc;
    private Header header;
    private List<RowTO> rows;

    public String getNombre() {
            return nombre;
    }

    public void setNombre(String nombre) {
            this.nombre = nombre;
    }

    public byte[] getArchivo() {
            return archivo;
    }

    public void setArchivo(byte[] archivo) {
            this.archivo = archivo;
    }

    public String getFormatoArchivo() {
            return formatoArchivo;
    }

    public void setFormatoArchivo(String formatoArchivo) {
            this.formatoArchivo = formatoArchivo;
    }

    public String getRc() {
            return rc;
    }

    public void setRc(String rc) {
            this.rc = rc;
    }

    public Header getHeader() {
        return header;
    }

    public void setHeader(Header header) {
        this.header = header;
    }

    public List<RowTO> getRows() {
        return rows;
    }

    public void setRows(List<RowTO> rows) {
        this.rows = rows;
    }

}
