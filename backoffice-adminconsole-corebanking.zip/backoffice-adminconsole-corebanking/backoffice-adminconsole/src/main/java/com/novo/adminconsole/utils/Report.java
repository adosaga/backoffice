package com.novo.adminconsole.utils;

import org.hibernate.validator.constraints.NotEmpty;

public class Report {

	private String reportId;
	
	private String reportName;
	
	private String activeParam;
	
	private String url;

	@NotEmpty(message = "La Fecha es requerida.")
	private String fecha;

	private String fechaFormateada;

	private String tagpay;

	private String user_id;

	private String modulo_id;

	private String operation_id;

	private String emisor_id;

	private String status_id;

	private String code;

	private String tipoInstitucion;

	private String institucionFinanciera;

	private String nombre;

	private String apellido;

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getFechaFormateada() {
		return fechaFormateada;
	}

	public void setFechaFormateada(String fechaFormateada) {
		this.fechaFormateada = fechaFormateada;
	}

	public String getInstitucionFinanciera() {
		return institucionFinanciera;
	}

	public void setInstitucionFinanciera(String institucionFinanciera) {
		this.institucionFinanciera = institucionFinanciera;
	}

	public String getTipoInstitucion() {
		return tipoInstitucion;
	}

	public void setTipoInstitucion(String tipoInstitucion) {
		this.tipoInstitucion = tipoInstitucion;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getReportId() {
		return reportId;
	}

	public void setReportId(String reportId) {
		this.reportId = reportId;
	}

	public String getReportName() {
		return reportName;
	}

	public void setReportName(String reportName) {
		this.reportName = reportName;
	}

	public String getActiveParam() {
		return activeParam;
	}

	public void setActiveParam(String activeParam) {
		this.activeParam = activeParam;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getFecha() {
		return fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	public String getUserId() {
		return user_id;
	}

	public void setUserId(String userId) {
		this.user_id = userId;
	}

	public String getModuloId() {
		return modulo_id;
	}

	public void setModuloId(String moduloId) {
		this.modulo_id = moduloId;
	}

	public String getOperationId() {
		return operation_id;
	}

	public void setOperationId(String operationId) {
		this.operation_id = operationId;
	}

	public String getTagpay() {
		return tagpay;
	}

	public void setTagpay(String tagpay) {
		this.tagpay = tagpay;
	}

	public String getEmisor_id() {
		return emisor_id;
	}

	public void setEmisor_id(String emisor_id) {
		this.emisor_id = emisor_id;
	}

	public String getStatus_id() {
		return status_id;
	}

	public void setStatus_id(String status_id) {
		this.status_id = status_id;
	}
}
