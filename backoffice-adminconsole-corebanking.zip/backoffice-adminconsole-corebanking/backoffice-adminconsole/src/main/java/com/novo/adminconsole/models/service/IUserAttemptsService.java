package com.novo.adminconsole.models.service;




import com.novo.adminconsole.TO.ResponseTO;
import com.novo.adminconsole.models.entity.AdmconsBranchOffices;
import com.novo.adminconsole.models.entity.AdmconsUserBranchOffice;

import com.novo.adminconsole.models.entity.UserApp;
import com.novo.adminconsole.models.entity.UserPassword;
import com.novo.adminconsole.models.entity.UserRole;

public interface IUserAttemptsService {

	// Actualizar los intentos si ingresa correctamente
	   public void resetAttempts(String username);
	
	// Obtener el usuario y sus intentos
	   public UserPassword getUserAttempts(String id);
	   
	// Insertar los intentos fallidos
	   public void insertFailAttempts(UserApp us, String password);
	   
	//  Actualizar los intentos fallidos
	   public void updateFailAttempts(String id, int intentos);
	   
	// Bloquear usuario
	   public void blockUser(String id, int maxTry);
	
	// Encontrar el usuario bloqueado
	   public UserPassword findBlocked(String id);
	   
	// Encontrar password del usuario
	   public UserPassword findPassword(String id);
	   
	   // Encontrar usuario deshabilitado
	   public UserPassword findDisabledPassword(String id);
	   
	// Encontrar el branch_id del usuario
	   public AdmconsUserBranchOffice findBranchId(String username);
	   
	// Encontrar el issuer_id del usuario   
	   public AdmconsBranchOffices findIssuerId(String branchId);
	   
	// Encontrar el email del usuario   
	   public UserApp findEmail(String email);
	   
	// Encontrar el nationalId del usuario   
	   public UserApp findNationalId(String nationalId);
	   
	   // Encontrar las ultimas 3 contraseñas
	   public boolean lastPasswords(String username, String password, int rows);
	   
	   // Insertar nueva contraseña
	   public ResponseTO newPassword(String username, String password);
	   
	 // Cambiar contraseña del usuario
	   public ResponseTO changePassword(String username, String password);
	   
	   // Metodo para recuperar password
	   public String passwordRecovery(UserApp user);
	   
	   public UserApp findBlockedUserAccess(String username);
	   
	   public UserRole findDisabledRole(String userId);
	  
}
