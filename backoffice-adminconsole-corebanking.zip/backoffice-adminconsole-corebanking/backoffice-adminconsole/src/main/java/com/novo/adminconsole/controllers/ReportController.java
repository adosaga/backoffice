package com.novo.adminconsole.controllers;

import com.google.gson.Gson;
import java.io.IOException;
import java.security.Principal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import javax.ws.rs.QueryParam;

import com.novo.adminconsole.TO.*;
import com.novo.adminconsole.models.dao.impl.ConfigDaoImpl;
import com.novo.adminconsole.models.service.*;
import com.novo.adminconsole.utils.Report;
import com.novo.adminconsole.utils.Utils;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.MultiValueMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import static com.novo.adminconsole.utils.Constants.*;

@Controller
public class ReportController {

    private Gson gson;
    private final Logger log = Logger.getLogger(ReportController.class);
    private final Properties properties = Utils.getConfig(PROPERTIES_FILE);
    
    @Autowired
    private IReportService reportService;

    @Autowired
    private IConfigService configService;

    @Autowired
    private IUserService userService;

    @Autowired
    private IRoleService roleService;

    @Autowired
	private ConfigDaoImpl temporal;
    

    @GetMapping("/reports/audit")
    public String reportesAuditoria(
        Model model, 
        Principal principal, 
        HttpSession httpSession, 
        RedirectAttributes flash) throws IOException 
    {
        User loggedUser;
        String roleId;
        String reportId;
        ResponseEntity<ResponseAccessTO> responseAccess;
        HttpStatus statusAccess;
        Report report;
        List<Object[]> listaUsuarios;
        List<Object[]> listaModulos;
        Date date;
        DateFormat dateFormat;
        ReportFiltersTO reportFiltersTO;
        ResponseEntity<ResponseReportTO> responseReport;
        String cantidadRegistros;
        HttpStatus statusCode;
        ResponseReportTO body;
        
        loggedUser = (User) ((Authentication) principal).getPrincipal();
        model.addAttribute("userInfo", loggedUser.getUsername());
        roleId = httpSession.getAttribute("roleId").toString();
        reportId = properties.getProperty("novoreport.auditoria.id");
        responseAccess = roleService.obtenerPermisos(roleId, REPORT_MODULE_ID);
        statusAccess = responseAccess.getStatusCode();
        
        log.info("Verificando accesos a modulo reportes");
        
        String allow = responseAccess.getBody().getAccess().containsKey(GENERAR_REPORTE_ID)
        		?responseAccess.getBody().getAccess().get(GENERAR_REPORTE_ID):"";
        
        if (statusAccess == HttpStatus.OK && allow.equals("1")) {
            report = new Report();
            listaUsuarios = userService.getUsers();
            listaModulos = configService.getListModules(roleId);

            date = new Date();
            dateFormat = new SimpleDateFormat("dd/MM/yyyy");

            reportFiltersTO = new ReportFiltersTO();
            reportFiltersTO.setFecha(dateFormat.format(date));
            report.setFecha(dateFormat.format(date));
            reportFiltersTO.setModulo("");
            reportFiltersTO.setUsuario("");

            responseReport = reportService.obtenerReport(reportFiltersTO, reportId);

            model.addAttribute("titulo", "Reporte Auditoría");
            model.addAttribute("usuarios", listaUsuarios);
            model.addAttribute("modulos", listaModulos);
            model.addAttribute("report", report);
            model.addAttribute("reportId",reportId);
            
            cantidadRegistros = "0";
            statusCode = responseReport.getStatusCode();

            if (statusCode == HttpStatus.OK) 
            {
                body = responseReport.getBody();
                if (body.getReport() != null) 
                {
                    model.addAttribute("reporteAuditoriaHeader", body.getReport().getHeader());
                    model.addAttribute("reporteAuditoria", body.getReport().getRows());
                    cantidadRegistros = String.valueOf(body.getReport().getRows().size());
                } 
                else 
                {
                    model.addAttribute("cantidadRegistros", "0");
                    userService.saveEvent(loggedUser.getUsername(), "38", "roleId: " + roleId + " It is not possible to access", "-1");
                    flash.addFlashAttribute("error", "It is not possible to access");
                    return "redirect:/dashboard";
                }
            } else {
                model.addAttribute("cantidadRegistros", "0");
                userService.saveEvent(loggedUser.getUsername(), "38", "roleId: " + roleId + " It is not possible to access", "-1");
                flash.addFlashAttribute("error", "It is not possible to access");
                return "redirect:/dashboard";
            }
            @SuppressWarnings("unchecked")
            List<String> menu = (List<String>) httpSession.getAttribute("menu");
            model.addAttribute("menu", menu);
            @SuppressWarnings("unchecked")
            List<String> menuModules = (List<String>) httpSession.getAttribute("menuModules");
            model.addAttribute("menuModules", menuModules);
            model.addAttribute("cantidadRegistros", cantidadRegistros);
            return "report/listReportAuditoria";
        } 
        else 
        {
            userService.saveEvent(loggedUser.getUsername(), "38", "roleId: " + roleId + " It is not possible to access", "-1");
            flash.addFlashAttribute("error", "It is not possible to access");
            return "redirect:/dashboard";
        }
    }

    @PostMapping("/reports/audit")
    public String reportesAuditoria(
        @ModelAttribute("report") @Valid Report report, 
        BindingResult result, 
        Model model, 
        Principal principal, 
        HttpSession httpSession, 
        RedirectAttributes flash) throws IOException
    {
        User loggedUser;
        String roleId;
        String reportId;
        ReportFiltersTO reportFiltersTO;
        String cantidadRegistros;
        ResponseEntity<ResponseReportTO> responseReport;
        HttpStatus statusCode;
        ResponseReportTO body;
        
        loggedUser = (User) ((Authentication) principal).getPrincipal();
        roleId = httpSession.getAttribute("roleId").toString();
        reportId = properties.getProperty("novoreport.auditoria.id");
        model.addAttribute("reportId",reportId);
        
        //Obtener lista de usuarios
        List<Object[]> listaUsuarios = userService.getUsers();
        List<Object[]> listaModulos = configService.getListModules(roleId);

        model.addAttribute("titulo", "Reporte Auditoría");
        model.addAttribute("usuarios", listaUsuarios);
        model.addAttribute("modulos", listaModulos);

        @SuppressWarnings("unchecked")
        List<String> menu = (List<String>) httpSession.getAttribute("menu");
        model.addAttribute("menu", menu);

        @SuppressWarnings("unchecked")
        List<String> menuModules = (List<String>) httpSession.getAttribute("menuModules");
        model.addAttribute("menuModules", menuModules);

        //Si tiene algun tipo de error redirecciona al formulario
        if (result.hasErrors()) {
            model.addAttribute("cantidadRegistros", "0");
            return "report/listReportAuditoria";
        }

        reportFiltersTO = new ReportFiltersTO();
        reportFiltersTO.setFecha(report.getFecha());
        reportFiltersTO.setModulo(report.getModuloId());
        reportFiltersTO.setUsuario(report.getUserId());
        cantidadRegistros = "0";

        responseReport = reportService.obtenerReport(reportFiltersTO, reportId);
        statusCode = responseReport.getStatusCode();

        if (statusCode == HttpStatus.OK) 
        {
            body = responseReport.getBody();
            if (body.getReport() != null) 
            {
                model.addAttribute("reporteAuditoriaHeader", body.getReport().getHeader());
                model.addAttribute("reporteAuditoria", body.getReport().getRows());
                cantidadRegistros = String.valueOf(body.getReport().getRows().size());
            } 
            else 
            {
                userService.saveEvent(loggedUser.getUsername(), "38", "roleId: " + roleId + " It is not possible to access", "-1");
                flash.addFlashAttribute("error", "It is not possible to access");
                return "redirect:/dashboard";
            }
        } 
        else 
        {
            userService.saveEvent(loggedUser.getUsername(), "38", "roleId: " + roleId + " It is not possible to access", "-1");
            flash.addFlashAttribute("error", "It is not possible to access");
            return "redirect:/dashboard";
        }
        model.addAttribute("cantidadRegistros", cantidadRegistros);
        log.info("Verificando accesos a modulo reportes auditoria");
        userService.saveEvent(loggedUser.getUsername(), "38", "Módulo reportes de auditoria.", "0");
        return "report/listReportAuditoria";
    }

    @GetMapping("/reports/download")
    public ResponseEntity<ByteArrayResource> descargarReportes(
            @RequestParam(value = "fecha") String fecha, 
            @RequestParam(value = "userId", required = false) String userId, 
            @RequestParam(value = "tagpay", required = false) String tagpay, 
            @RequestParam(value = "report") String report, 
            @RequestParam(value = "moduloId", required = false) String moduloId, 
            @RequestParam(value = "code", required = false) String code, 
            @RequestParam(value = "institucionFinanciera", required = false) String institucionFinanciera, 
            @RequestParam(value = "operationId", required = false) String operation, 
            Principal principal, HttpSession httpSession, RedirectAttributes flash) 
    {
        ReportFiltersTO reportFiltersTO;
        ResponseEntity<ByteArrayResource> response;
        HttpStatus statusCode;
        
        try 
        {
            reportFiltersTO = new ReportFiltersTO();
            reportFiltersTO.setFecha(fecha);
            if (operation != "" && operation != null) 
            {
                reportFiltersTO.setOperacion(operation);
            } 
            else 
            {
                reportFiltersTO.setOperacion("");
            }

            if (!"".equals(moduloId) && moduloId != null) 
            {
                reportFiltersTO.setModulo(moduloId);
            } 
            else 
            {
                reportFiltersTO.setModulo("");
            }
            if (!"".equals(tagpay) && tagpay != null) 
            {
                reportFiltersTO.setTagpay(tagpay);
            } 
            else 
            {
                reportFiltersTO.setTagpay("");
            }
            if (!"".equals(userId) && userId != null) 
            {
                reportFiltersTO.setUsuario(userId);
            } 
            else 
            {
                reportFiltersTO.setUsuario("");
            }
            if (!"".equals(institucionFinanciera) && institucionFinanciera != null) 
            {
                reportFiltersTO.setEmisor(institucionFinanciera);
            } 
            else 
            {
                reportFiltersTO.setEmisor("");
            }
            if (!"".equals(code) && code != null) 
            {
                reportFiltersTO.setStatus(code);
            } 
            else 
            {
                reportFiltersTO.setStatus("");
            }
            response = reportService.descargarReporte(report, "Excel", reportFiltersTO);
            statusCode = response.getStatusCode();
            if (statusCode == HttpStatus.OK) 
            {
                //userService.saveEvent(loggedUser.getUsername(), "38", "Reporte " + reportId + " generado satisfactoriamente", "0");
                return response;
            } 
            else 
            {
                log.info("Error al consumir API");
                //userService.saveEvent(loggedUser.getUsername(), "38", "Error al consumir API", "-1");
                return new ResponseEntity<ByteArrayResource>(HttpStatus.NOT_FOUND);
            }
        } 
        catch (Exception e) 
        {
            e.getMessage();
            return new ResponseEntity<ByteArrayResource>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/reports")
    public String listarReportes(
            Model model, 
            Principal principal, 
            HttpSession httpSession, 
            RedirectAttributes flash) 
    {		
        User loggedUser;
        String roleId;
        ResponseEntity<ResponseAccessTO> responseAccess;
        HttpStatus statusAccess;
        HttpStatus statusCode;
        RspReportParamsTO body;

        loggedUser = (User) ((Authentication) principal).getPrincipal();
        model.addAttribute("userInfo", loggedUser.getUsername());
        
        roleId = httpSession.getAttribute("roleId").toString();
        responseAccess = roleService.obtenerPermisos(roleId, REPORT_MODULE_ID);
        statusAccess = responseAccess.getStatusCode();
        log.info("Verificando accesos a modulo reportes");
        
        String allow = responseAccess.getBody().getAccess().containsKey(GENERAR_REPORTE_ID)
        		?responseAccess.getBody().getAccess().get(GENERAR_REPORTE_ID):"";
        
        if (statusAccess == HttpStatus.OK && allow.equals("1")) 
        {
            ResponseAccessTO bodyAccess = responseAccess.getBody();
            Map<String, String> accessObject = bodyAccess.getAccess();
            log.info("accessObject: " + accessObject);

            if (!accessObject.isEmpty()) 
            {
                try 
                {
                    log.info("Listando los reportes");

                    @SuppressWarnings("unchecked")
                    List<String> menu = (List<String>) httpSession.getAttribute("menu");
                    model.addAttribute("menu", menu);

                    @SuppressWarnings("unchecked")
                    List<String> menuModules = (List<String>) httpSession.getAttribute("menuModules");
                    model.addAttribute("menuModules", menuModules);

                    //List<AdmconsReport> reportList = reportService.obtenerReportes();                
                   // model.addAttribute("reportList", reportList);
                    model.addAttribute("userInfo", loggedUser.getUsername());
                    model.addAttribute("titulo", "Reports");
                    
                    List<Object[]> docTypes = temporal.getDocTypes();
                    List<Object[]> cusStatus = temporal.getCusStatus();
                    model.addAttribute("cusStatus",cusStatus);
                    model.addAttribute("docTypes",docTypes);
                    
                    ResponseEntity<RspReportParamsTO> result = reportService.getReportParams(null);
                    statusCode = result.getStatusCode();
                    if (statusCode == HttpStatus.OK) {
                    	body = result.getBody();
                    	model.addAttribute("reportList",body.getReportList());
                    }

                    return "report/listReport";
                } 
                catch (Exception e) 
                {
                    e.printStackTrace();
                    log.info("roleId: " + roleId + " Objeto con permisos incompletos");
                    userService.saveEvent(loggedUser.getUsername(), "38", "roleId: " + roleId + " Objeto con permisos incompletos", "-1");
                    flash.addFlashAttribute("error", "It is not possible to access");
                    return "redirect:/dashboard";

                }

            } else {

                userService.saveEvent(loggedUser.getUsername(), "38", "roleId: " + roleId + " Objeto con permisos vacio", "-1");
                flash.addFlashAttribute("error", "It is not possible to access");
                return "redirect:/dashboard";
            }

        } else {

            userService.saveEvent(loggedUser.getUsername(), "38", "roleId: " + roleId + " It is not possible to access", "-1");
            flash.addFlashAttribute("error", "It is not possible to access");
            return "redirect:/dashboard";

        }

    }

    @GetMapping("/reportes/consultar/{reportId}")
    public ResponseEntity<ByteArrayResource> consultarReportes(
            @PathVariable(name = "reportId") String reportId, 
            Principal principal, 
            HttpSession httpSession, 
            RedirectAttributes flash) 
    {
        User loggedUser;
        ResponseEntity<ByteArrayResource> response;
        HttpStatus statusCode;

        log.info("Consumiendo API CONSULTA NOVOREPORT");
        loggedUser = (User) ((Authentication) principal).getPrincipal();
        try 
        {
            response = reportService.descargarReporte(reportId);
            statusCode = response.getStatusCode();
            if (statusCode == HttpStatus.OK) 
            {
                userService.saveEvent(loggedUser.getUsername(), "38", "Reporte " + reportId + " generado satisfactoriamente", "0");
                return response;
            } 
            else 
            {
                log.info("Error al consumir API");
                userService.saveEvent(loggedUser.getUsername(), "38", "Error al consumir API", "-1");
                return new ResponseEntity<ByteArrayResource>(HttpStatus.NOT_FOUND);
            }
        } 
        catch (IOException e) 
        {
            log.info("Error leyendo el archivo");
            userService.saveEvent(loggedUser.getUsername(), "38", "Error leyendo el archivo", "-2");
            return new ResponseEntity<ByteArrayResource>(HttpStatus.NOT_FOUND);
        }
    }
  

      @RequestMapping(value="/report/parameters",
    		method=RequestMethod.POST,
            consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    public Object searchReportByParamters(
    		@RequestBody MultiValueMap<String, String> formData,
    		@QueryParam("reportId") String reportId,
    		Principal principal,RedirectAttributes flash){
		
    	gson = new Gson();
    	String jsonParams = gson.toJson(formData);
    	jsonParams = jsonParams.replace("[", "");
    	jsonParams = jsonParams.replace("]", "");
    	log.info("FORM PARAMS******** "+jsonParams);
    	
    	ResponseEntity<ByteArrayResource> response = null;
        HttpStatus statusCode;
        User loggedUser = (User) ((Authentication) principal).getPrincipal();
        
        try {
        	response = reportService.exportReportParams(reportId, jsonParams);
        }catch(Exception e) {
        	log.error("error getting report from api");
        	flash.addFlashAttribute("error", "Fail to download report, please try later");
        	return "redirect:/reports";
        }
            
            statusCode = response.getStatusCode();
            if (statusCode == HttpStatus.OK) 
            {
                userService.saveEvent(loggedUser.getUsername(), "38", "Reporte " + reportId + " generado satisfactoriamente", "0");
                return response;
            } 
            else 
            {
                log.info("Error al consumir API");
                userService.saveEvent(loggedUser.getUsername(), "38", "Error al consumir API", "-1");
                
                return new ResponseEntity<ByteArrayResource>(HttpStatus.NOT_FOUND);
            }  	    	
    }
}
