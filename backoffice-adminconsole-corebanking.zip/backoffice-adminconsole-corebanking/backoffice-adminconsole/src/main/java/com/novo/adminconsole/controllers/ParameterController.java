package com.novo.adminconsole.controllers;

import java.security.Principal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.novo.adminconsole.TO.ResponseAccessTO;
import com.novo.adminconsole.TO.ResponseParameterTO;
import com.novo.adminconsole.models.entity.AdmconsConfigType;
import com.novo.adminconsole.models.entity.AdmconsIssuers;
import com.novo.adminconsole.models.entity.AdmconsStatus;
import com.novo.adminconsole.models.service.IConfigService;
import com.novo.adminconsole.models.service.IParameterService;
import com.novo.adminconsole.models.service.IRoleService;
import com.novo.adminconsole.models.service.IUserService;
import com.novo.adminconsole.utils.Parameter;

import static com.novo.adminconsole.utils.Constants.PARAMETER_MODULE_ID;
import static com.novo.adminconsole.utils.Constants.LISTAR_PARAMETRO_ID;
import static com.novo.adminconsole.utils.Constants.OBTENER_PARAMETRO_ID;
import static com.novo.adminconsole.utils.Constants.CREAR_PARAMETRO_ID;
import static com.novo.adminconsole.utils.Constants.EDITAR_PARAMETRO_ID;
import static com.novo.adminconsole.utils.Constants.ACTIVAR_PARAMETRO_ID;
import static com.novo.adminconsole.utils.Constants.DESACTIVAR_PARAMETRO_ID;
import static com.novo.adminconsole.utils.Constants.ELIMINAR_PARAMETRO_ID;

@Controller
public class ParameterController {
		
	@Autowired
	private IParameterService parameterService;
	
	@Autowired
	private IConfigService configService;
	
	@Autowired
	private IUserService userService;
	
	@Autowired
	private IRoleService roleService;
	
	private final Logger log = Logger.getLogger(ParameterController.class);
	
	@ModelAttribute("listaEstatus")
	public List<AdmconsStatus> getListaEstatus(){
		
		List<AdmconsStatus> lista = new ArrayList<>();
		AdmconsStatus habilitado = new AdmconsStatus();
		habilitado.setStatusId("9");
		habilitado.setStatusName("Activo");
		
		AdmconsStatus deshabilitado = new AdmconsStatus();
		deshabilitado.setStatusId("11");
		deshabilitado.setStatusName("Inactivo");
		
		lista.add(habilitado);
		lista.add(deshabilitado);
		
		return lista;
	}
	
	@ModelAttribute("listaTipos")
	public List<AdmconsConfigType> getListaTipos() {
		
		return this.configService.getListTypes();
	}
	
	@ModelAttribute("listaEmisores")
	public List<AdmconsIssuers> getIssuerList() {
		// Obtener la lista de emisores
		return this.configService.getIssuerList();
	}
	
	@GetMapping("/parameter/list")
	public String listarParametros(Model model, Principal principal, HttpSession httpSession, RedirectAttributes flash) {
		
		User loggedUser = (User) ((Authentication) principal).getPrincipal();
		model.addAttribute("userInfo", loggedUser.getUsername());
		String sessionId = httpSession.getAttribute("sessionId").toString();
		
		String roleId = httpSession.getAttribute("roleId").toString();
		
		log.info("Verificando accesos a modulo parametros");
		ResponseEntity<ResponseAccessTO> responseAccess = roleService.obtenerPermisos(roleId, PARAMETER_MODULE_ID);
		
		HttpStatus statusAccess = responseAccess.getStatusCode();
		
		if (statusAccess == HttpStatus.OK) {
			
			ResponseAccessTO bodyAccess = responseAccess.getBody();
			Map<String,String> accessObject = bodyAccess.getAccess();
			log.info("accessObject: " + accessObject);
			
			if(!accessObject.isEmpty()) {
				
				try {
					
					String LISTAR_PARAMETRO = accessObject.containsKey(LISTAR_PARAMETRO_ID)?accessObject.get(LISTAR_PARAMETRO_ID).toString():null;
					String OBTENER_PARAMETRO = accessObject.containsKey(OBTENER_PARAMETRO_ID)?accessObject.get(OBTENER_PARAMETRO_ID).toString():null;
					String CREAR_PARAMETRO = accessObject.containsKey(CREAR_PARAMETRO_ID)?accessObject.get(CREAR_PARAMETRO_ID).toString():null;
					String EDITAR_PARAMETRO = accessObject.containsKey(EDITAR_PARAMETRO_ID)?accessObject.get(EDITAR_PARAMETRO_ID).toString():null;
					String ACTIVAR_PARAMETRO = accessObject.containsKey(ACTIVAR_PARAMETRO_ID)?accessObject.get(ACTIVAR_PARAMETRO_ID).toString():null;
					String DESACTIVAR_PARAMETRO = accessObject.containsKey(DESACTIVAR_PARAMETRO_ID)?accessObject.get(DESACTIVAR_PARAMETRO_ID).toString():null;
					String ELIMINAR_PARAMETRO = accessObject.containsKey(ELIMINAR_PARAMETRO_ID)?accessObject.get(ELIMINAR_PARAMETRO_ID).toString():null;
					
					model.addAttribute("LISTAR_PARAMETRO", LISTAR_PARAMETRO);
					model.addAttribute("OBTENER_PARAMETRO", OBTENER_PARAMETRO);
					model.addAttribute("CREAR_PARAMETRO", CREAR_PARAMETRO);
					model.addAttribute("EDITAR_PARAMETRO", EDITAR_PARAMETRO);
					model.addAttribute("ACTIVAR_PARAMETRO", ACTIVAR_PARAMETRO);
					model.addAttribute("DESACTIVAR_PARAMETRO", DESACTIVAR_PARAMETRO);
					model.addAttribute("ELIMINAR_PARAMETRO", ELIMINAR_PARAMETRO);
					
					//Consumir API listar parametros
					log.info("Consumiendo API LISTAR PARAMETROS");
					ResponseEntity<ResponseParameterTO> response = parameterService.listarParametros(loggedUser, sessionId);
					
					HttpStatus statusCode = response.getStatusCode();
					
					if(statusCode == HttpStatus.OK) {

						ResponseParameterTO body = response.getBody();
						List<Parameter> listaParam = body.getParameters(); 
						
						model.addAttribute("listaParam", listaParam);
						
						Parameter modalObject = new Parameter();
						model.addAttribute("deactivate", modalObject);
						model.addAttribute("activate", modalObject);
						model.addAttribute("delete", modalObject);
						
						@SuppressWarnings("unchecked")
						List<String> menu = (List<String>) httpSession.getAttribute("menu");
						model.addAttribute("menu", menu);
						
						@SuppressWarnings("unchecked")
						List<String> menuModules = (List<String>) httpSession.getAttribute("menuModules");
						model.addAttribute("menuModules", menuModules);
						
						model.addAttribute("userInfo", loggedUser.getUsername());
						model.addAttribute("titulo", "Parameters");
						
						userService.saveEvent(loggedUser.getUsername(), "15", "Listing parameters", "0");
						
						return "parameters/listParameter";
					}else {
						
						userService.saveEvent(loggedUser.getUsername(), "15", "It is not possible to list the parameters", "-1");
						flash.addFlashAttribute("error", "It is not possible to list the parameters");
						return "redirect:/dashboard";
					}
						
				} catch (Exception e) {
					log.info("roleId: "+ roleId +" Objeto con permisos incompletos");
					userService.saveEvent(loggedUser.getUsername(), "15", "roleId: "+ roleId +" It is not possible to access", "-1");
					flash.addFlashAttribute("error", "It is not possible to access");
					return "redirect:/dashboard";
					
				}
				
			}else {
				
				userService.saveEvent(loggedUser.getUsername(), "15", "roleId: "+ roleId +" It is not possible to access", "-1");
				flash.addFlashAttribute("error", "It is not possible to access");
				return "redirect:/dashboard";
			}
				
		} else {

			userService.saveEvent(loggedUser.getUsername(), "15", "roleId: "+ roleId +" It is not possible to accesso", "-1");
			flash.addFlashAttribute("error", "It is not possible to access");
			return "redirect:/dashboard";
			
		}	
	}
	
	@GetMapping("/parameter/new")
	public String crearParametro(Model model, Principal principal, HttpSession httpSession) {
		
		Parameter parameter = new Parameter();
		
		@SuppressWarnings("unchecked")
		List<String> menu = (List<String>) httpSession.getAttribute("menu");
		model.addAttribute("menu", menu);
		
		@SuppressWarnings("unchecked")
		List<String> menuModules = (List<String>) httpSession.getAttribute("menuModules");
		model.addAttribute("menuModules", menuModules);
		
		User loggedUser = (User) ((Authentication) principal).getPrincipal();
		model.addAttribute("userInfo", loggedUser.getUsername());
		model.addAttribute("titulo", "New parameter");
		model.addAttribute("parametro", parameter);
		
		return "parameters/newParameter";
	}
	
	@PostMapping("/parameter/create")
	public String guardarParametro(@ModelAttribute("parametro") @Valid Parameter parameter, BindingResult result, Model model, Principal principal, HttpSession httpSession, RedirectAttributes flash) {
		
		User loggedUser = (User) ((Authentication) principal).getPrincipal();
		//String branchCountry = httpSession.getAttribute("branchCountry").toString();
		String sessionId = httpSession.getAttribute("sessionId").toString();
		
		//Consumir API listar parametros
		log.info("Consumiendo API LISTAR PARAMETROS");
		ResponseEntity<ResponseParameterTO> response = parameterService.listarParametros(loggedUser, sessionId);
				
		HttpStatus statusCode = response.getStatusCode();
				
		if(statusCode == HttpStatus.OK) {
					
			ResponseParameterTO body = response.getBody();
			List<Parameter> listaParam = body.getParameters();
			
			if (listaParam != null) {
				for (Parameter item : listaParam) {
					
					if(item.getConfigName().toUpperCase().equals(parameter.getConfigName().toUpperCase())) {
						
						userService.saveEvent(loggedUser.getUsername(), "17", "Parameter name: " + parameter.getConfigName() + " already exists", "-1");
						flash.addFlashAttribute("error", "Parameter name: " + parameter.getConfigName() + " already exists");
						return "redirect:/parameter/new";
					}
					
				}	
			}
					
			//Consumir API crear parametros 
			log.info("Consumiendo API CREAR PARAMETRO");
			ResponseEntity<ResponseParameterTO> responseCrear = parameterService.crearParametro(parameter, loggedUser, sessionId);
			
			HttpStatus codigo = responseCrear.getStatusCode();
			
			if(codigo == HttpStatus.OK){
			
				userService.saveEvent(loggedUser.getUsername(), "17", "Parameter: "+ parameter.getConfigName()+" was created successfully", "0");
				flash.addFlashAttribute("success", "Parameter: "+ parameter.getConfigName()+" was created successfully");
				return "redirect:/parameter/list";
				
			}else {
				
				userService.saveEvent(loggedUser.getUsername(), "17", "Error creating parameter: "+parameter.getConfigName(), "-1");
				flash.addFlashAttribute("error", "Error creating parameter: "+parameter.getConfigName());
				return "redirect:/parameter/new";
			}
							
		}else {
					
			userService.saveEvent(loggedUser.getUsername(), "17", "Error getting parameter list", "-1");
			flash.addFlashAttribute("error", "Error getting parameter list");
			return "redirect:/parameter/new";
		}
	
	}
	
	@GetMapping("/parameter/edit/{id}")
	public String editarParametro(@PathVariable(name = "id") String id, Model model, Principal principal, HttpSession httpSession, RedirectAttributes flash) {
		
		User loggedUser = (User) ((Authentication) principal).getPrincipal();
		model.addAttribute("userInfo", loggedUser.getUsername());
		//String branchCountry = httpSession.getAttribute("branchCountry").toString();
		String sessionId = httpSession.getAttribute("sessionId").toString();
		
		Parameter singleParameter = new Parameter();
		singleParameter.setConfigId(id);
		
		//Consumir API obtener parametro
		log.info("Consumiendo API OBTENER PARAMETRO");
		ResponseEntity<ResponseParameterTO> response = parameterService.obtenerParametro(singleParameter, loggedUser, sessionId);
		
		HttpStatus statusCode = response.getStatusCode();
		
		if(statusCode == HttpStatus.OK){
		
			ResponseParameterTO body = response.getBody();
			List<Parameter> list = body.getParameters(); 
			Parameter parameter = list.get(0);
			
			
			@SuppressWarnings("unchecked")
			List<String> menu = (List<String>) httpSession.getAttribute("menu");
			model.addAttribute("menu", menu);
			
			@SuppressWarnings("unchecked")
			List<String> menuModules = (List<String>) httpSession.getAttribute("menuModules");
			model.addAttribute("menuModules", menuModules);
			
			model.addAttribute("userInfo", loggedUser.getUsername());
			model.addAttribute("titulo", "Edit parameter");
			model.addAttribute("parametro", parameter);
			model.addAttribute("configType", parameter.getConfigType());
			
			return "parameters/editParameter";
		
		}else {
			
			userService.saveEvent(loggedUser.getUsername(), "16", "Error searching paramter " + singleParameter.getConfigId(), "-1");
			flash.addFlashAttribute("error", "Error searching parameter " + singleParameter.getConfigId());
			return "redirect:/parameter/list";
			
		}
		
	}
	
	@PostMapping("/parameter/edit")
	public String guardarEditarParametro(@ModelAttribute("parametro") @Valid Parameter parameter, BindingResult result, Model model, Principal principal, HttpSession httpSession, RedirectAttributes flash) {
		
		User loggedUser = (User) ((Authentication) principal).getPrincipal();
		model.addAttribute("userInfo", loggedUser.getUsername());
		//String branchCountry = httpSession.getAttribute("branchCountry").toString();
		String sessionId = httpSession.getAttribute("sessionId").toString();
		
		parameter.setConfigStatus("9");
		//Consumir API editar parametros 
		log.info("Consumiendo API EDITAR PARAMETROS");
		ResponseEntity<ResponseParameterTO> response = parameterService.editarParametro(parameter, loggedUser, sessionId);
		
		HttpStatus statusCode = response.getStatusCode();
		
		if(statusCode == HttpStatus.OK){
		
			userService.saveEvent(loggedUser.getUsername(), "18", "Parameter edition was successful: "+parameter.getConfigName(), "0");
			flash.addFlashAttribute("success", parameter.getConfigName()+" was updated successfully");
			return "redirect:/parameter/list";
		
		}else {
			
			userService.saveEvent(loggedUser.getUsername(), "18", "Error editing parameter " + parameter.getConfigName(), "-1");
			flash.addFlashAttribute("error", "Error editing parameter " + parameter.getConfigName());
			return "redirect:/parameter/edit/" + parameter.getConfigId(); //pasarle el id
		}

	}
	
	@PostMapping("/parameter/activate")
	public String activarParametro(@ModelAttribute("activate") Parameter parameter, Model model, Principal principal, HttpSession httpSession, RedirectAttributes flash) {
		
		User loggedUser = (User) ((Authentication) principal).getPrincipal();
		model.addAttribute("userInfo", loggedUser.getUsername());
		//String branchCountry = httpSession.getAttribute("branchCountry").toString();
		String sessionId = httpSession.getAttribute("sessionId").toString();
		
		parameter.setConfigStatus("9");
		//Consumir API activar parametros 
		log.info("Consumiendo API ACTIVAR PARAMETROS");
		ResponseEntity<ResponseParameterTO> response = parameterService.activarParametro(parameter, loggedUser, sessionId);
		
		HttpStatus statusCode = response.getStatusCode();
		
		if(statusCode == HttpStatus.OK){
		
			userService.saveEvent(loggedUser.getUsername(), "19", "Parameter " + parameter.getConfigName() + " was activated successfully", "0");
			flash.addFlashAttribute("success", "Parameter " + parameter.getConfigName() + " was activated successfully");
			return "redirect:/parameter/list";
		
		}else {
			
			userService.saveEvent(loggedUser.getUsername(), "19", "Error activating parameter " + parameter.getConfigName(), "-1");
			flash.addFlashAttribute("error", "Error activating paramter " + parameter.getConfigName());
			return "redirect:/parameter/list";
		}
		
	}
	
	@PostMapping("/parameter/deactivate")
	public String desactivarParametro(@ModelAttribute("deactivate") Parameter parameter, Model model, Principal principal, HttpSession httpSession, RedirectAttributes flash) {
		
		User loggedUser = (User) ((Authentication) principal).getPrincipal();
		model.addAttribute("userInfo", loggedUser.getUsername());
		//String branchCountry = httpSession.getAttribute("branchCountry").toString();
		String sessionId = httpSession.getAttribute("sessionId").toString();
		
		parameter.setConfigStatus("11");
		//Consumir API desactivar parametros 
		log.info("Consumiendo API DESACTIVAR PARAMETROS");
		ResponseEntity<ResponseParameterTO> response = parameterService.desactivarParametro(parameter, loggedUser, sessionId);
				
		HttpStatus statusCode = response.getStatusCode();
		
		if(statusCode == HttpStatus.OK){
			
			userService.saveEvent(loggedUser.getUsername(), "20", "Parameter " + parameter.getConfigName() + " was deactivated successfully", "0");
			flash.addFlashAttribute("success", "Parameter " + parameter.getConfigName() + " was deactivated successfully");
			return "redirect:/parameter/list";
		
		}else {
			
			userService.saveEvent(loggedUser.getUsername(), "20", "Error deactivating parameter " + parameter.getConfigName(), "-1");
			flash.addFlashAttribute("error", "Error deactivating parameter " + parameter.getConfigName());
			return "redirect:/parameter/list";
		}
		
	}
	
	@PostMapping("/parameter/delete")
	public String eliminarParametro(@ModelAttribute("delete") Parameter parameter, Model model, Principal principal, HttpSession httpSession, RedirectAttributes flash) {
		
		User loggedUser = (User) ((Authentication) principal).getPrincipal();
		model.addAttribute("userInfo", loggedUser.getUsername());
		//String branchCountry = httpSession.getAttribute("branchCountry").toString();
		String sessionId = httpSession.getAttribute("sessionId").toString();
		
		parameter.setConfigStatus("0");
		//Consumir API eliminar parametros 
		log.info("Consumiendo API ELIMINAR PARAMETROS");
		ResponseEntity<ResponseParameterTO> response = parameterService.eliminarParametro(parameter, loggedUser, sessionId);
				
		HttpStatus statusCode = response.getStatusCode();
		
		if(statusCode == HttpStatus.OK){
			
			userService.saveEvent(loggedUser.getUsername(), "21", "Parameter " + parameter.getConfigName() + " was success deleted", "0");
			flash.addFlashAttribute("success", "Parameter " + parameter.getConfigName() + " was success deleted");
			return "redirect:/parameter/list";
		
		}else {
			
			userService.saveEvent(loggedUser.getUsername(), "21", "Error deleting parameter " + parameter.getConfigName(), "-1");
			flash.addFlashAttribute("error", "Error deleting parameter " + parameter.getConfigName());
			return "redirect:/parameter/list";
		}
	}
}
