package com.novo.adminconsole.config;



import java.util.Date;


import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationEventPublisher;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.LockedException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Component;

import com.novo.adminconsole.models.entity.UserApp;
import com.novo.adminconsole.models.entity.UserPassword;
import com.novo.adminconsole.models.entity.UserRole;
import com.novo.adminconsole.models.service.IUserAttemptsService;

import com.novo.adminconsole.models.service.IUserService;

import com.novo.adminconsole.models.service.impl.UserDetailsServiceImpl;


@Component("authenticationEventListener")
public class AuthenticationEventListener implements AuthenticationEventPublisher {

	@Autowired
	private IUserAttemptsService userAttemptsService;
	 
	@Autowired
	private UserDetailsServiceImpl userDetailsService;
	
	@Autowired
	private IUserService userService;
	
	private static final int MAX_ATTEMPTS = 3;
	private static final long MAX_TIME = 86400000;

	private final Logger log = Logger.getLogger(AuthenticationEventListener.class);
	
	@Override
	public void publishAuthenticationSuccess(Authentication authentication) {

		log.info("-------------- El usuario " + authentication.getName() + " ingreso satisfactoriamente ----------------------------------------");
		//reiniciar el contador de intentos en el usuario
		
		userService.saveEvent(authentication.getName(), "0", "User has been logged successfully", "");
		

		userAttemptsService.resetAttempts(authentication.getName());
	}

	@Override
	public void publishAuthenticationFailure(AuthenticationException exception, Authentication authentication) {

		log.info("-------------- El usuario " + authentication.getName() + " ingreso credenciales incorrectas ----------------------------------------");
		
		UserPassword userBlocked;
		UserPassword userDisabled;
		UserApp userAccess;
		UserRole userRole;
		
		Date today = new Date();
		
		Long resta;
		

		String error = "";
		int intentos = 0;
		String id = null;
		
		// Obtener el username
		String username = authentication.getName();
		
		//Obtener los intentos
		UserPassword userAttempt = null;
		
		// Obtener el password
		UserPassword userPassword = null;
		
		//Obtengo el usuario por username
		UserApp usernameExists = userDetailsService.findByUsername(username); 
		
		//Obtengo el usuario por email
		UserApp emailExists = userDetailsService.findByEmail(username); 
		
		
		// Verificar si esta bloqueado
		if(usernameExists != null) {
			
			userRole = userAttemptsService.findDisabledRole(usernameExists.getId());
			
			if (userRole != null) {
				
				userService.saveEvent(authentication.getName(), "0", "User's role is inactive", "");
				error = "User's role is inactive";
				throw new LockedException(error);
			}
			
			userAccess = userAttemptsService.findBlockedUserAccess(usernameExists.getId());
			
			if(userAccess != null) {
				
				userService.saveEvent(authentication.getName(), "0", "User's access is locked", "");
				error = "User is locked";          
		    	throw new LockedException(error); 
			}
			
			userBlocked = userAttemptsService.findBlocked(usernameExists.getId());
			// Si existe un usuario bloqueado
			if(userBlocked != null) {
				

				userService.saveEvent(authentication.getName(), "0", "User is locked", "");
				error = "User is locked. Please contact your system administrator";          
		    	throw new LockedException(error); 
			}
			
			userDisabled = userAttemptsService.findDisabledPassword(usernameExists.getId());
			// Si existe un usuario deshabilitado
			if(userDisabled != null) {
				
				// calcular la cantidad de milisegundos entre dos fechas
				resta = today.getTime() - userDisabled.getFromDate().getTime();
				
				// verificar que la clave temporal no haya pasado las 24 horas
				if(resta > MAX_TIME) {
					log.info("Temporary password has more than 24 hours since its creation");
					log.info("Generate new password through 'forgot your password'");
					
					userService.saveEvent(authentication.getName(), "0", "The temporary password has expired", "");
					error = "The temporary password has expired. You can generate a new one through the option: Forgot your username or password?";          
			    	throw new LockedException(error); 
					
				}else {
					
					userService.saveEvent(authentication.getName(), "0", "User is disabled", "");
					error = "User is disabled";          
			    	throw new LockedException(error); 
					
				}
	
			}
			
			// Obtener los intentos si se ingresa username
			userAttempt = userAttemptsService.getUserAttempts(usernameExists.getId()); 

		}else if (emailExists != null) {
			
			userRole = userAttemptsService.findDisabledRole(emailExists.getId());
			
			if (userRole != null) {
				
				userService.saveEvent(authentication.getName(), "0", "User's role is inactive", "");
				error = "User's role is inactive";
				throw new LockedException(error);
			}
			
			userAccess = userAttemptsService.findBlockedUserAccess(emailExists.getId());
			
			if(userAccess != null) {
				
				userService.saveEvent(emailExists.getId(), "0", "User's access is locked", "");
				error = "User is locked";          
		    	throw new LockedException(error); 
			}
			
			userBlocked = userAttemptsService.findBlocked(emailExists.getId());
			// Si existe un usuario bloqueado
			if(userBlocked != null) {
				
				userService.saveEvent(emailExists.getId(), "0", "User is locked", "");
				error = "User is locked. Please contact your system administrator";          
		    	throw new LockedException(error); 
			}
			
			userDisabled = userAttemptsService.findDisabledPassword(emailExists.getId());
			// Si existe un usuario deshabilitado
			if(userDisabled != null) {
				
				// calcular la cantidad de milisegundos entre dos fechas
				resta = today.getTime() - userDisabled.getFromDate().getTime();
				
				// verificar que la clave temporal no haya pasado las 24 horas
				if(resta > MAX_TIME) {
					log.info("Temporary password has more than 24 hours since its creation");
					log.info("Generate a new password through: Forgot your username or password?");
					
					userService.saveEvent(emailExists.getId(), "0", "The temporary password has expired", "");
					error = "Temporary password has expired. You can generate a new one through the option: Forgot your username or password?";          
			    	throw new LockedException(error); 
					
				}else {
					
					userService.saveEvent(emailExists.getId(), "0", "User is disabled", "");
					error = "User is disabled";          
			    	throw new LockedException(error); 
					
				}
			}

			// Obtener los intentos si se ingresa correo 
			userAttempt = userAttemptsService.getUserAttempts(emailExists.getId());	
		}
		
				
		if (userAttempt == null) {     

		    if(usernameExists != null){                     
		    	// Busco la contraseña
		    	userPassword = userAttemptsService.findPassword(usernameExists.getId());
		    	
		    	//Si no tiene contraseña con status valido
		    	if(userPassword == null) {
		    		
		    		userService.saveEvent(authentication.getName(), "0", "User is locked", "");

		    		error = "User is locked. Please contact your system administrator";          
			    	throw new LockedException(error);
		    	}
		    	
		    	// Quiere decir que si existe el usuario y el password fue incorrecto, inserto en la tabla 
		    	userAttemptsService.insertFailAttempts(usernameExists, userPassword.getUserPassword());   
		    
		    } else if(emailExists != null) {
		    	// Busco la contraseña
		    	userPassword = userAttemptsService.findPassword(emailExists.getId());
		    	
		    	//Si no tiene contraseña con status valido
		    	if(userPassword == null) {
		    		
		    		userService.saveEvent(emailExists.getId(), "0", "User is locked", "");

		    		error = "User is locked. Please contact your system administrator";          
			    	throw new LockedException(error);
		    	}
		    	
		    	// Quiere decir que si existe el email y el password fue incorrecto, inserto en la tabla 
		    	userAttemptsService.insertFailAttempts(emailExists, userPassword.getUserPassword()); 
		    }      
		  } else {                
			  // Obtener intentos
		      intentos = userAttempt.getAttempts();
		      // Obtener id de usuario
		      id = userAttempt.getUserId().getId();
		      
		    if (intentos + 1 == MAX_ATTEMPTS) {
		    	
		    	// Bloquear usuario
		    	userAttemptsService.blockUser(id, MAX_ATTEMPTS);
		    	
		    	userService.saveEvent(id, "0", "User is suspend", "");

		        error = "User is suspend. Please contact your system administrator";          
		        throw new LockedException(error);           
		    }
		    
		    if (intentos + 1 == 2) {
		    	
		    	// Actualizar el campo de la bd con los intentos
			    userAttemptsService.updateFailAttempts(id, intentos + 1);
		    	
			    userService.saveEvent(id, "0", "Invalid username or password", "");

		        error = "Invalid username or password. Please remember after (3) failed attempts, user will be locked";          
		        throw new LockedException(error);           
		    } 
		    
		    if(intentos + 1 > MAX_ATTEMPTS) {
		    	
		    	userService.saveEvent(id, "0", "User is locked", "");

		    	error = "User is locked. Please contact your system administrator";          
		    	throw new LockedException(error); 
		    	
		    	}else {
		    
		    	// Actualizar el campo de la bd con los intentos
			      userAttemptsService.updateFailAttempts(id, intentos + 1); 
		    }
		  }
		
			error = "Invalid username or password, Please verify and try again";
			throw new BadCredentialsException(error);


		 }
			
	}


