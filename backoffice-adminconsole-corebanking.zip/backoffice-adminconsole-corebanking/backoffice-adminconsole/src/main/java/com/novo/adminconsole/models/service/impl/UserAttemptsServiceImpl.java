package com.novo.adminconsole.models.service.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.novo.adminconsole.TO.ResponseEmailTO;
import com.novo.adminconsole.TO.ResponseTO;
import com.novo.adminconsole.models.dao.IRoleDao;
import com.novo.adminconsole.models.dao.IUserDao;
import com.novo.adminconsole.models.dao.IUserPassDao;
import com.novo.adminconsole.models.entity.AdmconsBranchOffices;
import com.novo.adminconsole.models.entity.AdmconsUserBranchOffice;
import com.novo.adminconsole.models.entity.UserApp;
import com.novo.adminconsole.models.entity.UserPassword;
import com.novo.adminconsole.models.entity.UserRole;
import com.novo.adminconsole.models.service.IUserAttemptsService;
import com.novo.adminconsole.utils.Email;
import com.novo.adminconsole.utils.NewUser;
import com.novo.adminconsole.utils.PasswordGenerator;

@Service
public class UserAttemptsServiceImpl implements IUserAttemptsService{


	private final Logger log = Logger.getLogger(UserAttemptsServiceImpl.class);
	
	private Email email = new Email();
	
	private BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

	@Autowired
	private IUserPassDao upDao;
	
	@Autowired
	private IUserDao userDao;
	
	@Autowired
	private IRoleDao roleDao;
	
	@Override
	@Transactional
	public void resetAttempts(String username) {
		
		//Obtengo el usuario por username
		UserApp usernameExists = userDao.findByUsername(username); 
						
		//Obtengo el usuario por email
		UserApp emailExists = userDao.findByEmail(username);
		
		if(usernameExists != null) {
			
			upDao.unlockBlocked(usernameExists.getId());
		} else if(emailExists != null) {
			
			upDao.unlockBlocked(emailExists.getId());
		}
		
	}

	
	@Override
	@Transactional(readOnly = true)
	public UserPassword getUserAttempts(String id) {
		
		return upDao.findNoBlocked(id);
	}

	@Override
	@Transactional
	public void insertFailAttempts(UserApp us, String password) {
		// Insertar cuando se equivoca por primera vez
		
		upDao.saveBlocked(us, password);
		
	}

	@Override
	@Transactional
	public void updateFailAttempts(String id, int intentos) {
		// Aumentar los intentos en la BD
		
		upDao.updateBlocked(id, intentos);
	}


	@Override
	@Transactional
	public void blockUser(String id, int maxTry) {
		// Bloquear usuario al 3er intento 
		
		upDao.blockUser(id, maxTry);
		
	}


	@Override
	@Transactional(readOnly = true)
	public UserPassword findBlocked(String id) {
		// Buscar el usuario bloqueado
		
		return upDao.findBlocked(id);
	}


	@Override
	public UserPassword findPassword(String id) {
		// Buscar el password del usuario
		return upDao.findPassword(id);
	}
	
	@Override
	@Transactional(readOnly = true)
	public AdmconsUserBranchOffice findBranchId(String username) {
		// TODO Auto-generated method stub
		
		return userDao.findBranchId(username);
		
	}


	@Override
	@Transactional(readOnly = true)
	public AdmconsBranchOffices findIssuerId(String branchId) {
		// Encontrar el issuer_id del usuario 
		
		return userDao.findIssuerId(branchId);
		
	}


	@Override
	@Transactional(readOnly = true)
	public UserApp findEmail(String email) {
		
		log.info("Buscando email : " + email);
		
		return userDao.findByEmail(email);
	}

	@Override
	@Transactional(readOnly = true)
	public UserApp findNationalId(String nationalId) {
		// TODO Auto-generated method stub
		return userDao.findByNationalId(nationalId);
	}

	@Override
	@Transactional(readOnly = true)
	public UserPassword findDisabledPassword(String id) {
		
		return upDao.findDisabledPassword(id);
	}

	// Actualizar contraseña temporal creada en el modulo de creacion de usuario o en el olvido de contraseña
	@Override
	@Transactional(readOnly = true)
	public ResponseTO newPassword(String username, String password) {
			
		//Obtengo el usuario por username

		UserApp usernameExists = userDao.findByUsername(username); 
    
		final  UserApp finalUserApp = usernameExists;
		
		if(usernameExists != null) {
				
			// aqui se manda el correo
			ResponseTO response = userDao.saveUserPassword(usernameExists, password);
			
			if(response.getRc().equals("0")) {
				
				// Thread que envia el correo con confirmacion de cambio de contraseña
				Runnable regtrx = new Runnable() {
		            @Override
		            public void run() {
		            	// llamar al servicio de correo
		            	ResponseEntity<ResponseEmailTO> responseEmail = email.confirmPassword(finalUserApp.getEmail());
		            	
		            	log.info("Email");
		            	
		            	if(responseEmail.equals(null)) {
		            		
		            	}else {
		            		
		            		log.info("StatusCode: " + responseEmail.getStatusCode().toString());
			            	log.info("RC: " + responseEmail.getBody().getRc());
			            	log.info("mSG: " + responseEmail.getBody().getMsg());
			            	
		            	}
		            	
		            }
		        };
		        Thread Thregtrx = new Thread(regtrx);
		        Thregtrx.start();
		        
		        return response;
			}else {
				
				return response;
			} 
			
		}else {
			
			return null;
		}
	
	}

	// Cambiar contraseña desde perfil de usuario
	@Override
	@Transactional(readOnly = true)
	public ResponseTO changePassword(String username, String password) {
		
		NewUser newUser = new NewUser();
		newUser.setUser_password(password);
		
		//Obtengo el usuario por username
		UserApp usernameExists = userDao.findByUsername(username); 
		final  UserApp finalUserApp = usernameExists;
		
		if(usernameExists != null) {
					
			ResponseTO response = userDao.changeUserPassword(usernameExists, password);
			
			if(response.getRc().equals("0")) {
				
				// Thread que envia el correo con confirmacion de cambio de contraseña
				Runnable regtrx = new Runnable() {
		            @Override
		            public void run() {
		            	// llamar al servicio de correo
		            	ResponseEntity<ResponseEmailTO> responseEmail = email.confirmPassword(finalUserApp.getEmail());
		            	
		            	log.info("Email");
		            	
		            	if(responseEmail.equals(null)) {
		            		
		            	}else {
		            		
		            		log.info("StatusCode: " + responseEmail.getStatusCode().toString());
			            	log.info("RC: " + responseEmail.getBody().getRc());
			            	log.info("mSG: " + responseEmail.getBody().getMsg());
			            	
		            	}
		            	
		            }
		        };
		        Thread Thregtrx = new Thread(regtrx);
		        Thregtrx.start();
		        
		        return response;
			}else {
				
				return response;
			}     
			
		} else {
			
			return null;
		}
	
	}
	
	
	@Override
	@Transactional(readOnly = true)
	public String passwordRecovery(UserApp user) {
		
		final String finalPassword = PasswordGenerator.getPassword(6);
		ResponseTO responsePassword = userDao.saveDisableUserPassword(user, finalPassword);
		
		if(responsePassword.getRc().equals("0")) {
		// La contraseña se insertó satisfactoriamente
			final  UserApp finalUserApp = user;
			
			// Thread que envia el correo con el password temporal
			Runnable regtrx = new Runnable() {
				
				
				
	            @Override
	            public void run() {
	            	// llamar al servicio de correo
	            	ResponseEntity<ResponseEmailTO> responseEmail = email.recuperarPassword(finalUserApp.getId(), finalPassword, finalUserApp.getEmail());
	            	
	            	log.info("Email");
	            	
	            	if(responseEmail.equals(null)) {
	            		
	            	}else {
	            		
	            		log.info("StatusCode: " + responseEmail.getStatusCode().toString());
		            	log.info("RC: " + responseEmail.getBody().getRc());
		            	log.info("mSG: " + responseEmail.getBody().getMsg());
		            	
	            	}
	            	
	            }
	        };
	        Thread Thregtrx = new Thread(regtrx);
	        Thregtrx.start();
			
			return "0";
		
		}else {
			
			return "-1";
	
		}
		
	}


	@Override
	@Transactional(readOnly = true)
	public boolean lastPasswords(String username, String password, int rows) {
		
		boolean match;
		
		List<Object[]> lista = upDao.lastPasswords(username, rows);
		
		for (Object[] objects : lista) {
			
			//log.info("Password Actual: " + password);
			//log.info("Password Historica: " + objects[1].toString());
			
			match = passwordEncoder.matches(password, objects[1].toString());
			
			if(match) {
				
				log.info("La nueva contraseña coincide con alguna de las ultimas 3");
				return true;	
			}
				
		}
		
		log.info("La nueva contraseña es válida");
		return false;
	}


	@Override
	@Transactional
	public UserApp findBlockedUserAccess(String username) {
		
		return userDao.findBlockedUserAccess(username);
	}


	@Override
	public UserRole findDisabledRole(String userId) {
		
		return roleDao.findDisabledRole(userId);
	}

}
