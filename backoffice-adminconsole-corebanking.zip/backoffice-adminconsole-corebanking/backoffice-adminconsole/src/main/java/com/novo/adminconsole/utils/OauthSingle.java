package com.novo.adminconsole.utils;

import javax.annotation.PostConstruct;
import javax.ejb.Singleton;
import javax.ejb.Startup;

import org.springframework.web.client.RestTemplate;

@Startup
@Singleton
public class OauthSingle {
	
	private String refreshToken;
	
	@PostConstruct
    public void init() {
        this.refreshToken="++++refreshToken";
        System.out.println(refreshToken);
        
        getToken();
    }
    
    private void getToken() {
        RestTemplate restTemplate = new RestTemplate();
    }

    public String getRefreshedToken() {
        System.out.println("workss");
        return this.refreshToken;
    }  

}
