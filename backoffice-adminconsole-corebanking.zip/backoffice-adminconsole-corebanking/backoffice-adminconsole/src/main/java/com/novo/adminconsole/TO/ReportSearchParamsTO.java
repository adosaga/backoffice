package com.novo.adminconsole.TO;

import java.util.List;

/**
* @author cagarcia
*/
public class ReportSearchParamsTO {
	
	private String reportId;
	private String reportName;
	private String reportTypeId;
	private String reportTypeName;
	private String reportTypeDesc;
	private List<ReportParamsTO> params;
	
	public String getReportId() {
		return reportId;
	}
	public void setReportId(String reportId) {
		this.reportId = reportId;
	}
	public String getReportName() {
		return reportName;
	}
	public void setReportName(String reportName) {
		this.reportName = reportName;
	}
	public String getReportTypeId() {
		return reportTypeId;
	}
	public void setReportTypeId(String reportTypeId) {
		this.reportTypeId = reportTypeId;
	}
	public String getReportTypeName() {
		return reportTypeName;
	}
	public void setReportTypeName(String reportTypeName) {
		this.reportTypeName = reportTypeName;
	}
	public String getReportTypeDesc() {
		return reportTypeDesc;
	}
	public void setReportTypeDesc(String reportTypeDesc) {
		this.reportTypeDesc = reportTypeDesc;
	}
	public List<ReportParamsTO> getParams() {
		return params;
	}
	public void setParams(List<ReportParamsTO> params) {
		this.params = params;
	}
	
}
