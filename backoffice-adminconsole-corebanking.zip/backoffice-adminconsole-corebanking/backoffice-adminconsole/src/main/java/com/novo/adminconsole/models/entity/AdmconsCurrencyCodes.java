package com.novo.adminconsole.models.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="ADMCONS_CURRENCY_CODES")
public class AdmconsCurrencyCodes implements Serializable{

	private static final long serialVersionUID = 1L;

	@Column(name="MONEDA")
	private String moneda;
	
	@Id
	@NotNull
	@Column(name="ISO_NUM")
	private String isoNum;
	
	@Column(name="ISO_NAME")
	private String isoName;
	
	@Column(name="ISO_DESC")
	private String isoDesc;

	public String getMoneda() {
		return moneda;
	}

	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}

	public String getIsoNum() {
		return isoNum;
	}

	public void setIsoNum(String isoNum) {
		this.isoNum = isoNum;
	}

	public String getIsoName() {
		return isoName;
	}

	public void setIsoName(String isoName) {
		this.isoName = isoName;
	}

	public String getIsoDesc() {
		return isoDesc;
	}

	public void setIsoDesc(String isoDesc) {
		this.isoDesc = isoDesc;
	}
}
