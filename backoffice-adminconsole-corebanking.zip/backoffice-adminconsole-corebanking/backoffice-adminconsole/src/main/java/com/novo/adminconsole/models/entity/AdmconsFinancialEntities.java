package com.novo.adminconsole.models.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name = "ADMCONS_FINANCIAL_ENTITIES")
public class AdmconsFinancialEntities implements Serializable{

	private static final long serialVersionUID = 1L;
    
	@Id
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "FINANCIAL_ENT_ID")
    private String financialEntId;
    
    @Size(max = 50)
    @Column(name = "FINANCIAL_ENT_NAME")
    private String financialEntName;
    
    @Size(max = 3)
    @Column(name = "FINANCIAL_ENT_COUNTRY")
    private String financialEntCountry;
    
    @Column(name = "CREATED")
    @Temporal(TemporalType.TIMESTAMP)
    private Date created;
    
    @Column(name = "LAST_UPDATED")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdated;
    
    @JoinColumn(name = "FINANCIAL_ENT_STATUS", referencedColumnName = "STATUS_ID")
    @ManyToOne
    private AdmconsStatus financialEntStatus;

	public String getFinancialEntId() {
		return financialEntId;
	}

	public void setFinancialEntId(String financialEntId) {
		this.financialEntId = financialEntId;
	}

	public String getFinancialEntName() {
		return financialEntName;
	}

	public void setFinancialEntName(String financialEntName) {
		this.financialEntName = financialEntName;
	}

	public String getFinancialEntCountry() {
		return financialEntCountry;
	}

	public void setFinancialEntCountry(String financialEntCountry) {
		this.financialEntCountry = financialEntCountry;
	}

	public Date getCreated() {
		return created;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public Date getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public AdmconsStatus getFinancialEntStatus() {
		return financialEntStatus;
	}

	public void setFinancialEntStatus(AdmconsStatus financialEntStatus) {
		this.financialEntStatus = financialEntStatus;
	}

}
