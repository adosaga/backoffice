package com.novo.adminconsole.models.service.impl;

import java.util.ArrayList;

import java.util.Date;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.novo.adminconsole.models.dao.IRoleDao;
import com.novo.adminconsole.models.dao.IUserDao;
import com.novo.adminconsole.models.dao.IUserPassDao;
import com.novo.adminconsole.models.entity.UserApp;
import com.novo.adminconsole.models.entity.UserPassword;
import com.novo.adminconsole.models.entity.UserRole;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {

	@Autowired
	private IRoleDao roleDao;
	
	@Autowired
	private IUserDao userDao;
	
	@Autowired
	private IUserPassDao upDao;
	
	private final Logger log = Logger.getLogger(UserDetailsServiceImpl.class);
	
	private static final long MAX_TIME = 86400000;

	
	@Override
	@Transactional(readOnly = true)
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
		log.info("------------------------- AUTENTICACION DE USUARIO--------------------------------");
		
		
		UserApp user;
		UserApp userAccess;
		UserPassword userPassword;
		UserRole userRole;
		Date today = new Date();
		Long resta;
				
		// Patrón para validar el email
        Pattern pattern = Pattern.compile("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@" + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
 
        Matcher mather = pattern.matcher(username);
 
        if (mather.find() == true) {
            
            log.info("El email ingresado por el usuario es valido");

            
	         // Buscar el usuario por email
	         log.info("Buscando por email ------> " + username);
	          user = this.userDao.findByEmail(username);
            
	         if (user == null) {
					
	        	 log.info("No se encontro el email ------> " + username);

					throw new UsernameNotFoundException("Usuario " + username + " no se encontró");
		
				}
	         
	         //Verificar si el rol del usuario esta inactivo
	         userRole = roleDao.findDisabledRole(user.getId());
	         
	         if(userRole != null) {
	        	 log.info("Este Usuario tiene el rol inactivo ------> " + username);
	        	 
	        	 throw new UsernameNotFoundException("Usuario " + username + " con rol inactivo");
	         }
	         
	         //Verificar si el usuario tiene el acceso bloqueado
	         userAccess = userDao.findBlockedUserAccess(user.getId());
	         
	         if( userAccess != null) {
	        	 log.info("Este Usuario tiene el acceso bloqueado ------> " + username);
	        	 
	        	 throw new UsernameNotFoundException("Usuario " + username + " con acceso bloqueado");
	         }
	         
	         // Verificar si el usuario esta bloqueado
	         userPassword = upDao.findBlocked(user.getId());
	         
	         if(userPassword != null) {
	        	 log.info("Este Usuario se encuentra Bloqueado ------> " + username);
	    			
	    		 throw new UsernameNotFoundException("Usuario " + username + " esta bloqueado");		
	    	}
	        
	      // Verificar si el usuario esta deshabilitado
	      userPassword = upDao.findDisabledPassword(user.getId());
	    		
	      if(userPassword != null) {
	    		log.info("Este Usuario se encuentra Deshabilitado ------>" + username);
	    		
	    		// calcular la cantidad de milisegundos entre dos fechas
				resta = today.getTime() - userPassword.getFromDate().getTime();
				
				// verificar que la clave temporal no haya pasado las 24 horas
				if(resta > MAX_TIME) {
					log.info("Clave temporal con mas de 24 Horas de creacion");
					log.info("Generar nueva clave temporal mediante olvido de contraseña");
					       
			    	throw new UsernameNotFoundException("Usuario " + username + " esta bloqueado"); 
					
				}else {
				
	    		log.info("Iniciando sesion de usuario deshabilitado");
	    		
	    		//Obtengo los roles del usuario 
	    		String roles = this.roleDao.getRoleName(user.getId());
	    		
	    		List<GrantedAuthority> grantList = new ArrayList<GrantedAuthority>();
	    		
	    		if(roles != null) {
	    			
	    				log.info("rol del usuario -----------> " + roles);
	    				//Obtengo cada rol de la lista de roles
	    				GrantedAuthority authority = new SimpleGrantedAuthority(roles);
	                    grantList.add(authority);	
	    				
	    		}
	
	    		UserDetails userDetails = (UserDetails) new User(user.getId(), userPassword.getUserPassword(), grantList);
	    		
	    		return userDetails;
				}		
	    	} 
	         
        } else {
        	
        	// Buscar por username
        	 log.info("Buscando por username -->" + username);
        	 user = this.userDao.findByUsername(username);
        	
        	// No se encuentra el usuario por username
    		if (user == null) {
    			
    			log.info("No se encontro el username ------->" + username);

    			throw new UsernameNotFoundException("Usuario " + username + " no se encontró");
    	
    		}
    		
    		//Verificar si el rol del usuario esta inactivo
	         userRole = roleDao.findDisabledRole(user.getId());
	         
	         if(userRole != null) {
	        	 log.info("Este Usuario tiene el rol inactivo ------> " + username);
	        	 
	        	 throw new UsernameNotFoundException("Usuario " + username + " con rol inactivo");
	         }
    		
    		 //Verificar si el usuario tiene el acceso bloqueado
	         userAccess = userDao.findBlockedUserAccess(user.getId());
	         
	         if( userAccess != null) {
	        	 log.info("Este Usuario tiene el acceso bloqueado ------> " + username);
	        	 
	        	 throw new UsernameNotFoundException("Usuario " + username + " con acceso bloqueado");
	         }
    		
    		// Verificar si el usuario esta bloqueado
    		userPassword = upDao.findBlocked(user.getId());
    		
    		if(userPassword != null) {
    			log.info("Este Usuario se encuentra Bloqueado ------>" + username);
    			
    			throw new UsernameNotFoundException("Usuario " + username + " esta bloqueado");
    			
    		}
    		
    		// Verificar si el usuario esta deshabilitado
    		userPassword = upDao.findDisabledPassword(user.getId());
    		
    		if(userPassword != null) {
    			log.info("Este Usuario se encuentra Deshabilitado ------>" + username);
	    		
	    		// calcular la cantidad de milisegundos entre dos fechas
				resta = today.getTime() - userPassword.getFromDate().getTime();
				
				// verificar que la clave temporal no haya pasado las 24 horas
				if(resta > MAX_TIME) {
					log.info("Clave temporal con mas de 24 Horas de creacion");
					log.info("Generar nueva clave temporal mediante olvido de contraseña");
					       
			    	throw new UsernameNotFoundException("Usuario " + username + " esta bloqueado"); 
					
				}else {
				
	    		log.info("Iniciando sesion de usuario deshabilitado");
	    		
	    		//Obtengo los roles del usuario [ROLE_USER]
	    		String roles = this.roleDao.getRoleName(user.getId());
	    		
	    		List<GrantedAuthority> grantList = new ArrayList<GrantedAuthority>();
	    		
	    		if(roles != null) {

	    				log.info("rol del usuario -----------> " + roles);
	    				//Obtengo cada rol de la lista de roles
	    				GrantedAuthority authority = new SimpleGrantedAuthority(roles);
	                    grantList.add(authority);	
	    				
	    		}
	
	    		UserDetails userDetails = (UserDetails) new User(user.getId(), userPassword.getUserPassword(), grantList);
	    		
	    		return userDetails;
				}	
    			
    		}
    		
    	}
        
       
        log.info("Usuario encontrado! ------->" + username);
		
		//Obtengo los roles del usuario [ROLE_USER]
		String roles = this.roleDao.getRoleName(user.getId());
		
		List<GrantedAuthority> grantList = new ArrayList<GrantedAuthority>();
		
		if(roles != null) {

				log.info("rol del usuario -----------> " + roles);
				//Obtengo cada rol de la lista de roles
				GrantedAuthority authority = new SimpleGrantedAuthority(roles);
                grantList.add(authority);	
	
		}
		
		
		// Buscar la contraseña del usuario
		UserPassword password = this.upDao.findPassword(user.getId());
		
		
		UserDetails userDetails = (UserDetails) new User(user.getId(), password.getUserPassword(), grantList);
		
		
		return userDetails;
	}
	
	@Transactional(readOnly = true)
	public UserApp findByUsername(String username) {
		
		return this.userDao.findByUsername(username);
		
	}
	
	@Transactional(readOnly = true)
	public UserApp findByEmail(String username) {
		
		return this.userDao.findByEmail(username);
		
	}
	

}
