package com.novo.adminconsole.models.service;

import com.novo.adminconsole.TO.ReportFiltersTO;
import com.novo.adminconsole.TO.ResponseReportTO;
import com.novo.adminconsole.TO.RspReportParamsTO;

import java.io.IOException;
import java.util.List;

import com.novo.adminconsole.utils.Report;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.ResponseEntity;

import com.novo.adminconsole.models.entity.AdmconsReport;
import com.novo.adminconsole.utils.MultiReport;

public interface IReportService {

	public ResponseEntity<ByteArrayResource> descargarReporte(String reportId) throws IOException;

	public ResponseEntity<ByteArrayResource> descargarReporte(String reportId,String format, ReportFiltersTO reportFiltersTO) throws IOException;
		
	public ResponseEntity<ByteArrayResource> exportReportParams(String reportId, String params);
	
	public List<AdmconsReport> obtenerReportes();
	
	public ResponseEntity<ByteArrayResource> descargarReporteParam(MultiReport multi) throws IOException;

	public List<String> obtenerReportAuditoria(Report report) throws  IOException;

	public ResponseEntity<ResponseReportTO> obtenerReport(ReportFiltersTO reportFiltersTO, String reportId) throws  IOException;

	public ResponseEntity<ResponseReportTO> obtenerReport(ReportFiltersTO reportFiltersTO, String reportId,String format) throws  IOException;
	
	public ResponseEntity<ResponseReportTO> getReportParams(String reportId, String params);
	
	public ResponseEntity<RspReportParamsTO> getReportParams(String reportId);
	
}
