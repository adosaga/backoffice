package com.novo.adminconsole.models.dao;

import com.novo.adminconsole.TO.ReportSearchParamsTO;
import com.novo.adminconsole.models.entity.*;

import java.util.List;

public interface IConfigDao {

	public List<AdmconsConfigType> getListTypes();
	
	public List<AdmconsCategories> getListCategories(String areaId);
	
	public List<Object[]> getListProducts(String issuerId);
	
	public List<AdmconsBranchOffices> getBranchOfficeListByIssuer(String issuerId);
	
	public List<AdmconsIssuers> getIssuerListByIssuer(String issuerId);
	
	public List<AdmconsReport> obtenerReportes();
	
	public List<AdmconsCurrencyCodes> obtenerCurrencies();
	
	public List<AdmconsFinancialEntities> obtenerInstituciones();

	public List<String> obtenerInstitucionesByMember(String memberId);
	
	public List<AdmconsBrands> obtenerBrands();

	public List<Object[]> getMemberByFinancial(String financial);
	
	public List<AdmconsIssuers> obtenerEmisores();
	
	public List<AdmconsProductTypes> obtenerTipoProducto();
	
	public List<AdmconsOperations> obtenerOperaciones();
	
	public List<Object[]> obtenerOperacionesAsociadas(String productId);
	
	public List<Object[]> obtenerOperacionesNoAsociadas(String productId);

	public void saveFinancialAtrributes(String financialId,String isMember);
}
