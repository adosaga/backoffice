package com.novo.adminconsole.models.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="ADMCONS_CONFIG_TYPE")
public class AdmconsConfigType implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@NotNull
	@Column(name = "CONFIG_TYPE_ID")
	private String configTypeId;
	
	@Column(name = "CONFIG_NAME")
	private String configName;
	
	@JoinColumn(name = "CONFIG_STATUS", referencedColumnName = "STATUS_ID")
	@ManyToOne
	private AdmconsStatus configStatus;

	public String getConfigTypeId() {
		return configTypeId;
	}

	public void setConfigTypeId(String configTypeId) {
		this.configTypeId = configTypeId;
	}

	public String getConfigName() {
		return configName;
	}

	public void setConfigName(String configName) {
		this.configName = configName;
	}

	public AdmconsStatus getConfigStatus() {
		return configStatus;
	}

	public void setConfigStatus(AdmconsStatus configStatus) {
		this.configStatus = configStatus;
	}

}
