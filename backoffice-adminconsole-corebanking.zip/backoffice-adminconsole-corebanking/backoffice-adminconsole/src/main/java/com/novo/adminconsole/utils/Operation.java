package com.novo.adminconsole.utils;

public class Operation {

	private String operationId;
	
	private String operationName;
	
	private String operationDescription;
	
	private String operationStatus;
	
	private String currencyCode;

	private String maxLimMonth;
	
	private String minLimMonth;
	
	private String maxLimkWeek;
	
	private String minLimWeek;
	
	private String maxLimDay;
	
	private String minLimDay;
	
	private String maxTransDay;
	
	private String maxTransWeek;
	
	private String maxTransMonth;
	
	private String lastUpdated;
	
	private String comission;
	
	public String getOperationId() {
		return operationId;
	}

	public void setOperationId(String operationId) {
		this.operationId = operationId;
	}

	public String getOperationName() {
		return operationName;
	}

	public void setOperationName(String operationName) {
		this.operationName = operationName;
	}

	public String getOperationDescription() {
		return operationDescription;
	}

	public void setOperationDescription(String operationDescription) {
		this.operationDescription = operationDescription;
	}

	public String getOperationStatus() {
		return operationStatus;
	}

	public void setOperationStatus(String operationStatus) {
		this.operationStatus = operationStatus;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public String getMaxLimMonth() {
		return maxLimMonth;
	}

	public void setMaxLimMonth(String maxLimMonth) {
		this.maxLimMonth = maxLimMonth;
	}

	public String getMinLimMonth() {
		return minLimMonth;
	}

	public void setMinLimMonth(String minLimMonth) {
		this.minLimMonth = minLimMonth;
	}

	public String getMaxLimkWeek() {
		return maxLimkWeek;
	}

	public void setMaxLimkWeek(String maxLimkWeek) {
		this.maxLimkWeek = maxLimkWeek;
	}

	public String getMinLimWeek() {
		return minLimWeek;
	}

	public void setMinLimWeek(String minLimWeek) {
		this.minLimWeek = minLimWeek;
	}

	public String getMaxLimDay() {
		return maxLimDay;
	}

	public void setMaxLimDay(String maxLimDay) {
		this.maxLimDay = maxLimDay;
	}

	public String getMinLimDay() {
		return minLimDay;
	}

	public void setMinLimDay(String minLimDay) {
		this.minLimDay = minLimDay;
	}

	public String getMaxTransDay() {
		return maxTransDay;
	}

	public void setMaxTransDay(String maxTransDay) {
		this.maxTransDay = maxTransDay;
	}

	public String getMaxTransWeek() {
		return maxTransWeek;
	}

	public void setMaxTransWeek(String maxTransWeek) {
		this.maxTransWeek = maxTransWeek;
	}

	public String getMaxTransMonth() {
		return maxTransMonth;
	}

	public void setMaxTransMonth(String maxTransMonth) {
		this.maxTransMonth = maxTransMonth;
	}

	public String getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(String lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public String getComission() {
		return comission;
	}

	public void setComission(String comission) {
		this.comission = comission;
	}
}
