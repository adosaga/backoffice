package com.novo.adminconsole.utils;

import static com.novo.adminconsole.utils.Constants.PROPERTIES_FILE;

import java.util.Properties;

import org.apache.log4j.Logger;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.novo.adminconsole.TO.RequestEmailTO;
import com.novo.adminconsole.TO.ResponseEmailTO;


public class Email {

	private final Logger log = Logger.getLogger(Email.class);
	
	// Metodo para enviar email de recuperacion de password
	public ResponseEntity<ResponseEmailTO> recuperarPassword(String usuario, String clave, String email) {
		
		  log.info("Enviando email de RECUPERACION a usuario: " + usuario + " con email: " + email);
		  
		  Properties properties = Utils.getConfig(PROPERTIES_FILE);
		  String urlEmail = properties.getProperty("app.api.mail");
		  String bodyRecuperarPassword = properties.getProperty("body.email.recuperarpassword");
		  
		  String bodyFinal = bodyRecuperarPassword.replace("$usuario$", usuario).replace("$clave$", clave);
		  
		  RequestEmailTO body = new RequestEmailTO();
		  body.setBodyMail(bodyFinal);
		  body.setProcessName("AdminConsole");
		  body.setRecipients(email);
		  body.setSender("info@novopayment.com");
		  body.setSenderName("AdminConsole");
		  body.setSubject("Envío de Contraseña");
		  
		//Headers de la peticion
		  HttpHeaders headers = new HttpHeaders();
		  headers.setContentType(MediaType.APPLICATION_JSON);
	      headers.add("country", "Co");
	      headers.add("language", "En");
	      headers.add("channel", "ADM");
	      
		//Data enviada en el request
		HttpEntity<RequestEmailTO> requestBody = new HttpEntity<>(body, headers);
		
		try {
			RestTemplate restTemplate = new RestTemplate();
			return restTemplate.postForEntity(urlEmail, requestBody, ResponseEmailTO.class);
			
		} catch (RestClientException e) {
			
			log.info("Error llamando al API: " + e.getMessage());
			
			return null;
		}
		
	}
	
	// Metodo para enviar email de nuevo usuario
	public ResponseEntity<ResponseEmailTO> nuevoUsuario(String usuario, String clave, String email) {
		
		  log.info("Enviando email de NUEVO USUARIO a usuario: " + usuario + " con email: " + email);
		
		  Properties properties = Utils.getConfig(PROPERTIES_FILE);
		  String urlEmail = properties.getProperty("app.api.mail");
		  String bodyNuevoUsuario = properties.getProperty("body.email.nuevousuario");
		  
		  String bodyFinal = bodyNuevoUsuario.replace("$usuario$", usuario).replace("$clave$", clave);
  
		  RequestEmailTO body = new RequestEmailTO();
		  body.setBodyMail(bodyFinal);
		  body.setProcessName("AdminConsole");
		  body.setRecipients(email);
		  body.setSender("info@novopayment.com");
		  body.setSenderName("AdminConsole");
		  body.setSubject("Envío de Contraseña");
		  
		//Headers de la peticion
		  HttpHeaders headers = new HttpHeaders();
		  headers.setContentType(MediaType.APPLICATION_JSON);
	      headers.add("country", "Co");
	      headers.add("language", "En");
	      headers.add("channel", "ADM");
	      
	      
		//Data enviada en el request
		HttpEntity<RequestEmailTO> requestBody = new HttpEntity<>(body, headers);
		
		try {
			RestTemplate restTemplate = new RestTemplate();
			return restTemplate.postForEntity(urlEmail, requestBody, ResponseEmailTO.class);
		} catch (RestClientException e) {
			
			log.info("Error llamando al API: " + e.getMessage());
			return null;
		}
	
	}
	
	// Metodo para enviar email de nuevo usuario
		public ResponseEntity<ResponseEmailTO> confirmPassword(String email) {
			
			  log.info("Enviando email de confirmacion a email: " + email);
	  
			  Properties properties = Utils.getConfig(PROPERTIES_FILE);
			  String urlEmail = properties.getProperty("app.api.mail");
			  String bodyConfirmPassword = properties.getProperty("body.email.confirmpassword");
			  
			  RequestEmailTO body = new RequestEmailTO();
			  body.setBodyMail(bodyConfirmPassword);
			  body.setProcessName("AdminConsole");
			  body.setRecipients(email);
			  body.setSender("info@novopayment.com");
			  body.setSenderName("AdminConsole");
			  body.setSubject("Cambio de contraseña");
			  
			//Headers de la peticion
			  HttpHeaders headers = new HttpHeaders();
			  headers.setContentType(MediaType.APPLICATION_JSON);
		      headers.add("country", "Co");
		      headers.add("language", "En");
		      headers.add("channel", "ADM");
		      
			//Data enviada en el request
			HttpEntity<RequestEmailTO> requestBody = new HttpEntity<>(body, headers);
			
			try {
				RestTemplate restTemplate = new RestTemplate();
				return restTemplate.postForEntity(urlEmail, requestBody, ResponseEmailTO.class);
			} catch (RestClientException e) {
				
				log.info("Error llamando al API: " + e.getMessage());
				return null;
			}
	
		}
	
}
