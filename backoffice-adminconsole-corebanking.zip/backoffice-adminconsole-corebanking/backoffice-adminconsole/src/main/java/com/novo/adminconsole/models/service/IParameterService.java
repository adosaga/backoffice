package com.novo.adminconsole.models.service;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.User;

import com.novo.adminconsole.TO.ResponseParameterTO;
import com.novo.adminconsole.utils.Parameter;

public interface IParameterService {

	public ResponseEntity<ResponseParameterTO> listarParametros(User userLogged, String sessionId);
	
	public ResponseEntity<ResponseParameterTO> crearParametro(Parameter parameter,User userLogged, String sessionId); 
	
	public ResponseEntity<ResponseParameterTO> obtenerParametro(Parameter parameter, User userLogged, String sessionId); 	
	
	public ResponseEntity<ResponseParameterTO> editarParametro(Parameter parameter, User userLogged, String sessionId); 
		
	public ResponseEntity<ResponseParameterTO> activarParametro(Parameter parameter, User userLogged, String sessionId); 
		
	public ResponseEntity<ResponseParameterTO> desactivarParametro(Parameter parameter, User userLogged, String sessionId); 
	
	public ResponseEntity<ResponseParameterTO> eliminarParametro(Parameter parameter, User userLogged, String sessionId); 
	
}
