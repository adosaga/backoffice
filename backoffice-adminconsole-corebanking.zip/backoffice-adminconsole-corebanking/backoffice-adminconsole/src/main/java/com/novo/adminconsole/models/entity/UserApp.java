package com.novo.adminconsole.models.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import org.hibernate.validator.constraints.Email;

@Entity
@Table(name = "ADMCONS_USERS")
public class UserApp implements Serializable{
	
	private static final long serialVersionUID = 1L;

	@Id // Este es el username
	@Column(name="User_Id", nullable=false, length=25)
	private String id;
	
	@Column(name="National_Id", nullable=false, length=15)
	private String nationalId;
	
	@Email
	@Column(name="User_email", nullable=false)
	private String email;
	
	@JoinColumn(name = "USER_STATUS", referencedColumnName = "STATUS_ID")
    @ManyToOne
    private AdmconsStatus userStatus;
	
	@Column(name="User_firstname", length=100)
	private String firstName;
	
	@Column(name="User_middlename", length=100)
	private String middleName;
	
	@Column(name="User_lastname", length=100)
	private String lastName;
	
	@Column(name="User_secondsurname", length=100)
	private String surName;
	
	@Column(name="User_phone_code", length=4)
	private String phoneCode;
	
	@Column(name="User_telephone", length=50)
	private String telephone;
	
	@Column(name="User_job", length=100)
	private String job;
	
	@Column(name="User_job_area", length=100)
	private String jobArea;
	
	@Column(name="Is_admin", length=1)
	private String isAdmin;
	
	@Column(name="created")
	@Temporal(TemporalType.TIMESTAMP)
	private Date created;
	
	@Column(name="dropped_out")
	@Temporal(TemporalType.TIMESTAMP)
	private Date droppedOut;
	
	@Column(name="last_connection")
	@Temporal(TemporalType.TIMESTAMP)
	private Date lastConnection;
	
	@Column(name="last_updated")
	@Temporal(TemporalType.TIMESTAMP)
	private Date lastUpdated;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getNationalId() {
		return nationalId;
	}

	public void setNationalId(String nationalId) {
		this.nationalId = nationalId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public AdmconsStatus getUserStatus() {
		return userStatus;
	}

	public void setUserStatus(AdmconsStatus userStatus) {
		this.userStatus = userStatus;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getSurName() {
		return surName;
	}

	public void setSurName(String surName) {
		this.surName = surName;
	}

	public String getPhoneCode() {
		return phoneCode;
	}

	public void setPhoneCode(String phoneCode) {
		this.phoneCode = phoneCode;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public String getJobArea() {
		return jobArea;
	}

	public void setJobArea(String jobArea) {
		this.jobArea = jobArea;
	}

	public String getIsAdmin() {
		return isAdmin;
	}

	public void setIsAdmin(String isAdmin) {
		this.isAdmin = isAdmin;
	}

	public Date getCreated() {
		return created;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public Date getDroppedOut() {
		return droppedOut;
	}

	public void setDroppedOut(Date droppedOut) {
		this.droppedOut = droppedOut;
	}

	public Date getLastConnection() {
		return lastConnection;
	}

	public void setLastConnection(Date lastConnection) {
		this.lastConnection = lastConnection;
	}

	public Date getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	
	

}

