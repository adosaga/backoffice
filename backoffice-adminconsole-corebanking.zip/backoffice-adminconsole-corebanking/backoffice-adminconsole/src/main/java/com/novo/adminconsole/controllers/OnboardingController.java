package com.novo.adminconsole.controllers;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.Principal;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpSession;
import javax.ws.rs.QueryParam;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.google.gson.Gson;
import com.novo.adminconsole.TO.ResponseAccessTO;
import com.novo.adminconsole.TO.ResponseUserCoreTO;
import com.novo.adminconsole.constants.ApplicationHeader;
import com.novo.adminconsole.models.dao.impl.ConfigDaoImpl;
import com.novo.adminconsole.models.service.IConfigService;
import com.novo.adminconsole.models.service.IOnboardingService;
import com.novo.adminconsole.models.service.IRoleService;
import com.novo.adminconsole.models.service.IUserService;
import com.novo.adminconsole.utils.Utils;

import static com.novo.adminconsole.utils.Constants.*;

@Controller
public class OnboardingController {

	@Autowired
	private IRoleService roleService;
	@Autowired
	private IUserService userService;
	@Autowired
	private IConfigService configService;
	@Autowired
	private ConfigDaoImpl temporal;
	@Autowired
	private IOnboardingService iOnboardingService;
	
	private final Logger log = Logger.getLogger(OnboardingController.class);
	
	@GetMapping("/onboarding/customers")
	public String onboardingList(Model model, Principal principal, HttpSession httpSession, RedirectAttributes flash) {

		log.info("====ONBOARDING====");
		
		User loggedUser;
        String roleId;
        ResponseEntity<ResponseAccessTO> responseAccess;
        HttpStatus statusAccess;
        List<Object[]> listaUsuarios;
        List<Object[]> listaModulos;
        List<Object[]> customers = null;
        ResponseUserCoreTO responseUserCore;	            
        
        loggedUser = (User) ((Authentication) principal).getPrincipal();
        model.addAttribute("userInfo", loggedUser.getUsername());
        roleId = httpSession.getAttribute("roleId").toString();        
        responseAccess = roleService.obtenerPermisos(roleId, ONBOARDING_MODULE_ID);
        statusAccess = responseAccess.getStatusCode();

        log.info("Verificando accesos a modulo Onboarding");

        if (statusAccess == HttpStatus.OK) {
        	
        	ResponseAccessTO bodyAccess = responseAccess.getBody();
			Map<String,String> accessObject = bodyAccess.getAccess();
			log.info("accessObject: " + accessObject);
			
			if(!accessObject.isEmpty()) {
				
	            listaUsuarios = userService.getUsers();
	            listaModulos = configService.getListModules(roleId);
	
	            model.addAttribute("titulo", "Onboarding");
	            model.addAttribute("usuarios", listaUsuarios);
	            model.addAttribute("modulos", listaModulos);
	           
	            @SuppressWarnings("unchecked")
	            List<String> menu = (List<String>) httpSession.getAttribute("menu");
	            model.addAttribute("menu", menu);
	            @SuppressWarnings("unchecked")
	            List<String> menuModules = (List<String>) httpSession.getAttribute("menuModules");
	            model.addAttribute("menuModules", menuModules);
	            	            
	            List<Object[]> docTypes = temporal.getDocTypes();
	            List<Object[]> cusStatus = temporal.getCusStatus();
	              	            
	            ResponseEntity<ResponseUserCoreTO> re= iOnboardingService.getOnboardingCustomers(null, null, null);   
	            if(re.getStatusCode()==HttpStatus.OK) {
	            	responseUserCore = re.getBody();
	            	Map<String,Object> data = (Map<String, Object>) responseUserCore.getData();
		            customers = (List<Object[]>) data.get("onboardingList");
	            }
	            
	            model.addAttribute("customers",customers);	       
	            model.addAttribute("docTypes",docTypes);
	            model.addAttribute("cusStatus",cusStatus);
	            
	            userService.saveEvent(loggedUser.getUsername(), "115", "List onboarding customers", "0");
	            
	            return "onboarding/OnboardingList";
			}
			else {
				userService.saveEvent(loggedUser.getUsername(), "115", "roleId: " + roleId + " It is not possible to access", "-1");
	            flash.addFlashAttribute("error", "It is not possible to access");
	            return "redirect:/dashboard";
			}
        } 
        else 
        {
            userService.saveEvent(loggedUser.getUsername(), "115", "roleId: " + roleId + " It is not possible to access", "-1");
            flash.addFlashAttribute("error", "It is not possible to access");
            return "redirect:/dashboard";
        }	
	}
	
	@RequestMapping(value="/onboarding/search",
    		method=RequestMethod.POST,
            consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    public String searchOnboarding(Model model,HttpSession httpSession,RedirectAttributes flash,
    		@RequestBody MultiValueMap<String, String> formData,
    		Principal principal){
		
		User loggedUser;
        String roleId;
        ResponseEntity<ResponseAccessTO> responseAccess;
        HttpStatus statusAccess;
        List<Object[]> listaUsuarios;
        List<Object[]> listaModulos;
        ResponseUserCoreTO responseUserCore;	            
        Object customers = null;
        Gson gson = new Gson();
        
        loggedUser = (User) ((Authentication) principal).getPrincipal();
        model.addAttribute("userInfo", loggedUser.getUsername());
        roleId = httpSession.getAttribute("roleId").toString();        
        responseAccess = roleService.obtenerPermisos(roleId, ONBOARDING_MODULE_ID);
        statusAccess = responseAccess.getStatusCode();

        log.info("Verificando accesos a modulo Onboarding");

        if (statusAccess == HttpStatus.OK) {
        	
        	ResponseAccessTO bodyAccess = responseAccess.getBody();
			Map<String,String> accessObject = bodyAccess.getAccess();
			log.info("accessObject: " + accessObject);
			
			if(!accessObject.isEmpty()) {
				
	            listaUsuarios = userService.getUsers();
	            listaModulos = configService.getListModules(roleId);
	
	            model.addAttribute("titulo", "Onboarding");
	            model.addAttribute("usuarios", listaUsuarios);
	            model.addAttribute("modulos", listaModulos);
	           
	            @SuppressWarnings("unchecked")
	            List<String> menu = (List<String>) httpSession.getAttribute("menu");
	            model.addAttribute("menu", menu);
	            @SuppressWarnings("unchecked")
	            List<String> menuModules = (List<String>) httpSession.getAttribute("menuModules");
	            model.addAttribute("menuModules", menuModules);
	            
	            
	            List<Object[]> docTypes = temporal.getDocTypes();
	            List<Object[]> cusStatus = temporal.getCusStatus();
	            	            
	            ResponseEntity<ResponseUserCoreTO> re= iOnboardingService.getOnboardingCustomers(formData.getFirst("docType"), formData.getFirst("createdDate"), formData.getFirst("cusStatus"));
	                      
	            if(re.getStatusCode()==HttpStatus.OK) {
	            	responseUserCore = re.getBody();
	            	Map<String,Object> data = (Map<String, Object>) responseUserCore.getData();
		            customers = (List<Object[]>) data.get("onboardingList");
	            }
	            
	            model.addAttribute("customers",(List<Object[]>) customers);	            
	            model.addAttribute("docTypes",docTypes);
	            model.addAttribute("cusStatus",cusStatus);
	            
	            userService.saveEvent(loggedUser.getUsername(), "115", "List onboarding customers given a filter", "0");
	            
	            return "onboarding/OnboardingList";
			}
			else {
				userService.saveEvent(loggedUser.getUsername(), "115", "roleId: " + roleId + " It is not possible to access", "-1");
	            flash.addFlashAttribute("error", "It is not possible to access");
	            return "redirect:/dashboard";
			}
        } 
        else 
        {
            userService.saveEvent(loggedUser.getUsername(), "115", "roleId: " + roleId + " It is not possible to access", "-1");
            flash.addFlashAttribute("error", "It is not possible to access");
            return "redirect:/dashboard";
        }	

    }
	
	@GetMapping("/onboarding/customerDetails")
	public String customerDetail(@QueryParam("cus") String cus,@QueryParam("tab") String tab,
			Model model, Principal principal, HttpSession httpSession, RedirectAttributes flash) {

		log.info("====ONBOARDING / details ====");
		
		User loggedUser;
        String roleId;
        ResponseEntity<ResponseAccessTO> responseAccess;
        HttpStatus statusAccess;
        List<Object[]> listaUsuarios;
        List<Object[]> listaModulos;
        
        loggedUser = (User) ((Authentication) principal).getPrincipal();
        model.addAttribute("userInfo", loggedUser.getUsername());
        roleId = httpSession.getAttribute("roleId").toString();        
        responseAccess = roleService.obtenerPermisos(roleId, ONBOARDING_MODULE_ID);
        statusAccess = responseAccess.getStatusCode();

        log.info("Verificando accesos a modulo Onboarding");

        if (statusAccess == HttpStatus.OK) {
            
            listaUsuarios = userService.getUsers();
            listaModulos = configService.getListModules(roleId);

            model.addAttribute("tittle", "Onboarding: ");
            model.addAttribute("usuarios", listaUsuarios);
            model.addAttribute("modulos", listaModulos);
           
            @SuppressWarnings("unchecked")
            List<String> menu = (List<String>) httpSession.getAttribute("menu");
            model.addAttribute("menu", menu);
            @SuppressWarnings("unchecked")
            List<String> menuModules = (List<String>) httpSession.getAttribute("menuModules");
            model.addAttribute("menuModules", menuModules);
            
            try
            {
                getConnectivity(cus, model);
            }
            catch(Exception e)
            {
                log.info("Error getting customer details: "+e);
                e.printStackTrace();
                flash.addFlashAttribute("error", "Error has occurred, Please try later");
            }
            
            userService.saveEvent(loggedUser.getUsername(), "115", "see customer detail", "0");
            	            
            return "onboarding/customerDetail";
        } 
        else 
        {
            userService.saveEvent(loggedUser.getUsername(), "115", "roleId: " + roleId + " Error obteniendo accesos al modulo", "-1");
            flash.addFlashAttribute("error", "It is not possible to access");
            return "redirect:/dashboard";
        }	
	}
	
	private void getConnectivity(String cus, Model model) {
		
		ResponseEntity<ResponseUserCoreTO> re=null;		
		ResponseUserCoreTO responseUserCore;
		Map<String, Object> rsp=null;
		
		try
        {
			re= iOnboardingService.getCusConnectivity(cus);
			if(re!=null) {
				if(re.getStatusCode()==HttpStatus.OK) {
					responseUserCore = re.getBody();	            
					rsp = (Map<String, Object>) responseUserCore.getData();	
					model.addAttribute("cus",cus);
		            model.addAttribute("connectivity",rsp.get("connectivity"));
	            }			
			}
        }
        catch(Exception e)
        {
            log.error("Error getting connectivity: "+e);
            e.printStackTrace();
        }
		
	}
	
	@GetMapping("/onboarding/personalInfo")
	public String getPersonalInfo(@QueryParam("cus") String cus, Model model) {
		
		ResponseEntity<ResponseUserCoreTO> re=null;		
		ResponseUserCoreTO responseUserCore;
		Map<String, Object> rsp=null;
		
		try {
			re= iOnboardingService.getPersonalInfo(cus);
			if(re.getStatusCode()==HttpStatus.OK) {
				responseUserCore = re.getBody();	            
				rsp = (Map<String, Object>) responseUserCore.getData();	
				
	            model.addAttribute("profileInfo",rsp.get("profile"));
	            model.addAttribute("identifiers",rsp.get("identifiers"));
	            model.addAttribute("addressInfo",rsp.get("address"));
	            model.addAttribute("contactInfo",rsp.get("contact"));
	        }
			
		}catch (Exception e) {
			log.error("Error getting personal info: "+e);
            e.printStackTrace();
		}
						
		return "onboarding/customerDetail-personalInfo";
	}
	
	@GetMapping("/onboarding/occupation")
	public String getOccupation(@QueryParam("cus") String cus, Model model) {
		
		ResponseEntity<ResponseUserCoreTO> re=null;		
		ResponseUserCoreTO responseUserCore;
		Map<String, Object> rsp=null;
		
		try {
			re= iOnboardingService.getOccupation(cus);
			if(re.getStatusCode()==HttpStatus.OK) {
				responseUserCore = re.getBody();	            
				rsp = (Map<String, Object>) responseUserCore.getData();	
				
	            model.addAttribute("occupation",rsp.get("occupation"));
	            model.addAttribute("jobAddress",rsp.get("jobAddress"));
	            model.addAttribute("incomeSource",rsp.get("incomeSource"));
	        }
			
		}catch (Exception e) {
			log.error("Error getting occupation: "+e);
            e.printStackTrace();
		}
						
		return "onboarding/customerDetail-occupation";
	}
	
	@GetMapping("/onboarding/assessment")
	public String getAssessment(@QueryParam("cus") String cus, Model model) {
		
		ResponseEntity<ResponseUserCoreTO> re=null;		
		ResponseUserCoreTO responseUserCore;
		Map<String, Object> rsp=null;
		
		try {
			re= iOnboardingService.getAssessment(cus);
			if(re.getStatusCode()==HttpStatus.OK) {
				responseUserCore = re.getBody();         
				 			
	            model.addAttribute("assessment",responseUserCore.getData());            
	        }
			
		}catch (Exception e) {
			log.error("Error getting assessment: "+e);
            e.printStackTrace();
		}
						
		return "onboarding/customerDetail-assessment";
	}
	
	@GetMapping("/onboarding/documents")
	public String getDocuments(@QueryParam("cus") String cus, Model model) {
		
		ResponseEntity<ResponseUserCoreTO> re=null;		
		ResponseUserCoreTO responseUserCore;
		Map<String, Object> rsp=null;
		Properties properties = Utils.getConfig(PROPERTIES_FILE);
		
		try {
			re= iOnboardingService.getDocuments(cus);
			if(re.getStatusCode()==HttpStatus.OK) {
				responseUserCore = re.getBody();	            
				rsp = (Map<String, Object>) responseUserCore.getData();	
				
	            model.addAttribute("documents",(List<Object>)rsp.get("DOCUMENT"));
	            model.addAttribute("url", properties.get("onboarding.doc.location"));
	        }
			
		}catch (Exception e) {
			log.error("Error getting documents: "+e);
            e.printStackTrace();
		}
						
		return "onboarding/customerDetail-documents";
	}
	@GetMapping("/onboarding/payments")
	public String getPayments(@QueryParam("cus") String cus, Model model) {
		
		ResponseEntity<ResponseUserCoreTO> re=null;		
		ResponseUserCoreTO responseUserCore;
		Map<String, Object> rsp=null;
		Properties properties = Utils.getConfig(PROPERTIES_FILE);
		
		try { 
			re= iOnboardingService.getPayments(cus);
			if(re.getStatusCode()==HttpStatus.OK) {
				responseUserCore = re.getBody();	            
				rsp = (Map<String, Object>) responseUserCore.getData();	
				
	            model.addAttribute("payments",rsp.get("payments"));
	        }
			
		}catch (Exception e) {
			log.error("Error getting payments: "+e);
            e.printStackTrace();
		}
						
		return "onboarding/customerDetail-payments";
	}
	
	@GetMapping("/onboarding/logs")
	public String getLogs(@QueryParam("cus") String cus, Model model) {
		
		ResponseEntity<ResponseUserCoreTO> re=null;		
		ResponseUserCoreTO responseUserCore;
		Map<String, Object> rsp=null;
		Properties properties = Utils.getConfig(PROPERTIES_FILE);
		
		try {
			re= iOnboardingService.getEventLog(cus);
			if(re.getStatusCode()==HttpStatus.OK) {
				responseUserCore = re.getBody();	            
				rsp = (Map<String, Object>) responseUserCore.getData();	
				
	            model.addAttribute("logs",rsp.get("event_logs"));
	            model.addAttribute("eventlog_cus_var",properties.get("event.log.cus.var"));
	            model.addAttribute("eventlog_report_id",properties.get("event.log.report.id"));
	        }
			
		}catch (Exception e) {
			log.error("Error getting logs: "+e);
            e.printStackTrace();
		}
						
		return "onboarding/customerDetail-activity";
	}
	
	@GetMapping("/onboarding/summary")
	public String getSummary(@QueryParam("cus") String cus, Model model) {
		
		ResponseEntity<ResponseUserCoreTO> re=null;		
		ResponseUserCoreTO responseUserCore;
		Map<String, Object> rsp=null;
		
		try {
			re= iOnboardingService.getSummary(cus);
			if(re.getStatusCode()==HttpStatus.OK) {
				responseUserCore = re.getBody();	            
				rsp = (Map<String, Object>) responseUserCore.getData();	
				model.addAttribute("customerID",cus);
	            model.addAttribute("summPI",rsp.get("personalInfo"));
	        }
			
		}catch (Exception e) {
			log.error("Error getting summary: "+e);
            e.printStackTrace();
		}
						
		return "onboarding/customerDetail-summary";
	}
			
	@GetMapping("/onboarding/file")
	public ResponseEntity<byte[]> getUploadedDocument(@QueryParam("doc") String doc,@QueryParam("ext") String ext) {
		
		log.info("Downloading uploaded file: "+doc);
		
		Properties properties = Utils.getConfig(PROPERTIES_FILE);
		
		String filename = properties.getProperty("local_deploy").equals("true")?
				properties.getProperty("onboarding.doc.path")+doc
				:System.getProperty("catalina.home", ".")+ properties.getProperty("onboarding.doc.path")+doc;
				
		byte[] bytesFile = null;
		try {
			bytesFile = Files.readAllBytes(Paths.get(filename));
		} catch (IOException e) {
			log.error("error parsing file to bytes: "+filename);
			e.printStackTrace();
		}

	    HttpHeaders headers = new HttpHeaders();
	    //headers.setContentDispositionFormData(filename, filename);
	    log.info("content type: "+ApplicationHeader.getById(ext));
	    headers.setContentType(MediaType.parseMediaType(ApplicationHeader.getById(ext)));	    
	    headers.add("content-disposition", "inline;filename=" + filename);
	    headers.setCacheControl("must-revalidate, post-check=0, pre-check=0");
	    
	    ResponseEntity<byte[]> response = new ResponseEntity<byte[]>(bytesFile, headers, HttpStatus.OK);
	    return response;
	}
}
