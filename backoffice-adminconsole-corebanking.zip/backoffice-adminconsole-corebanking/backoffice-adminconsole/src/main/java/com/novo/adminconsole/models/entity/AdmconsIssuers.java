package com.novo.adminconsole.models.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;


@Entity
@Table(name="ADMCONS_ISSUERS")
public class AdmconsIssuers implements Serializable{

	
	private static final long serialVersionUID = 1L;

	@Id
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "ISSUER_ID")
    private String issuerId;
	
    @Size(max = 50)
    @Column(name = "ISSUER_NAME")
    private String issuerName;
    
    @Column(name = "CREATED")
    @Temporal(TemporalType.TIMESTAMP)
    private Date created;
    
    @Column(name = "LAST_UPDATED")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdated;
    
    @JoinColumn(name = "ISSUER_STATUS", referencedColumnName = "STATUS_ID")
    @ManyToOne
    private AdmconsStatus issuerStatus;
    
    @JoinColumn(name = "FINANCIAL_ENT_ID", referencedColumnName = "FINANCIAL_ENT_ID")
    @ManyToOne
    private AdmconsFinancialEntities financialEntId;

	public String getIssuerId() {
		return issuerId;
	}

	public void setIssuerId(String issuerId) {
		this.issuerId = issuerId;
	}

	public String getIssuerName() {
		return issuerName;
	}

	public void setIssuerName(String issuerName) {
		this.issuerName = issuerName;
	}

	public Date getCreated() {
		return created;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public Date getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public AdmconsStatus getIssuerStatus() {
		return issuerStatus;
	}

	public void setIssuerStatus(AdmconsStatus issuerStatus) {
		this.issuerStatus = issuerStatus;
	}

	public AdmconsFinancialEntities getFinancialEntId() {
		return financialEntId;
	}

	public void setFinancialEntId(AdmconsFinancialEntities financialEntId) {
		this.financialEntId = financialEntId;
	}
	
}
