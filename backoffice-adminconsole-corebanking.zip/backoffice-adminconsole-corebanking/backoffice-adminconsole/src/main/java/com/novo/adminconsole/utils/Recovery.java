package com.novo.adminconsole.utils;

import org.hibernate.validator.constraints.NotEmpty;

public class Recovery {

	@NotEmpty(message="El email es requerido")
	private String email;

	@NotEmpty(message="El N° de identificación es requerido")
	private String nationalId;
	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getNationalId() {
		return nationalId;
	}

	public void setNationalId(String nationalId) {
		this.nationalId = nationalId;
	}
	
}
