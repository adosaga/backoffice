package com.novo.adminconsole.models.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="ADMCONS_ROLES"/*, uniqueConstraints = {@UniqueConstraint(name="ROLE_UK", columnNames="role_name")}*/)
public class Role implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="Role_Id", length = 3, nullable = false)
	private String id;
	
	@Column(name="role_name", length = 50)
	private String roleName;

	@Column(name="role_description", length = 200)
	private String roleDescription;
	
	@Column(name="created")
	@Temporal(TemporalType.TIMESTAMP)
	private Date created;

	@Column(name="last_updated")
	@Temporal(TemporalType.TIMESTAMP)
	private Date lastUpdate;
	
	@JoinColumn(name = "ROLE_STATUS", referencedColumnName = "STATUS_ID")
	@ManyToOne
	private AdmconsStatus roleStatus;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}


	public String getRoleName() {
		return roleName;
	}


	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	
	public String getRoleDescription() {
		return roleDescription;
	}


	public void setRoleDescription(String roleDescription) {
		this.roleDescription = roleDescription;
	}


	public Date getCreated() {
		return created;
	}


	public void setCreated(Date created) {
		this.created = created;
	}


	public Date getLastUpdate() {
		return lastUpdate;
	}

	public void setLastUpdate(Date lastUpdate) {
		this.lastUpdate = lastUpdate;
	}

	
	public AdmconsStatus getRoleStatus() {
		return roleStatus;
	}

	public void setRoleStatus(AdmconsStatus roleStatus) {
		this.roleStatus = roleStatus;
	}
}
