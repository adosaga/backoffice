package com.novo.adminconsole.models.dao.impl;

import com.google.gson.Gson;
import com.novo.adminconsole.models.dao.IConfigDao;
import com.novo.adminconsole.models.entity.*;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;

@Repository
public class ConfigDaoImpl implements IConfigDao {

	@PersistenceContext
	private EntityManager entitymanager;

	@PersistenceContext
	private EntityManager entityManager;
	
	private final Logger log = Logger.getLogger(ConfigDaoImpl.class);

	@SuppressWarnings("unchecked")
	@Override
	public List<AdmconsConfigType> getListTypes() {
		
		log.info("Listando tipos");
		
		try {
			String sql = "Select t from " + AdmconsConfigType.class.getName() + " t ";
			Query query = entitymanager.createQuery(sql, AdmconsConfigType.class);
			
			return (List<AdmconsConfigType>) query.getResultList();
			
		} catch (Exception e) {
			
			log.info("error: " + e);
			return null;
		}	
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<AdmconsCategories> getListCategories(String areaId) {
		
		try {
			
			String sql = "Select c from " + AdmconsCategories.class.getName() + " c where c.categoryArea.areaId = :areaId";
			Query query = entitymanager.createQuery(sql, AdmconsCategories.class);
			query.setParameter("areaId", areaId);
			
			return (List<AdmconsCategories>) query.getResultList();
			
		} catch (Exception e) {
			
			log.info("error: " + e);
			return null;
		}
	
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getListProducts(String issuerId) {
		
		try {
			
			String sql = "Select product_id, product_name from ADMCONS_PRODUCTS WHERE issuer_id = :issuerId and product_status = '1'";
			Query query = entitymanager.createNativeQuery(sql);
			query.setParameter("issuerId", issuerId);
			
			return (List<Object[]>) query.getResultList();
			
		} catch (Exception e) {
			
			log.info("error: " + e);
			return null;
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<AdmconsBranchOffices> getBranchOfficeListByIssuer(String issuerId) {
		
		try {
			
			String sql = "Select b from " + AdmconsBranchOffices.class.getName() + " b where issuer_id = :issuerId and branch_status = '1'";
			Query query = entitymanager.createQuery(sql, AdmconsBranchOffices.class);
			query.setParameter("issuerId", issuerId);
			
			return (List<AdmconsBranchOffices>) query.getResultList();
		} catch (Exception e) {
			
			log.info("error: " + e);
			return null;
		}
		
		
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<AdmconsIssuers> getIssuerListByIssuer(String issuerId) {
		
		try {
			String sql = "Select i from " + AdmconsIssuers.class.getName() + " i where issuer_id = :issuerId and issuer_status = '1'";
			Query query = entitymanager.createQuery(sql, AdmconsIssuers.class);
			query.setParameter("issuerId", issuerId);
			
			return (List<AdmconsIssuers>) query.getResultList();
		} catch (Exception e) {
			
			log.info("error: " + e);
			return null;
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<AdmconsReport> obtenerReportes() {
		
		try {
			String sql = "Select r from " + AdmconsReport.class.getName() + " r";
			Query query = entitymanager.createQuery(sql, AdmconsReport.class);
			
			return (List<AdmconsReport>) query.getResultList();
		} catch (Exception e) {
			log.info("error: " + e);
			return null;
		}		
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<AdmconsCurrencyCodes> obtenerCurrencies() {
		
		try {
			String sql = "Select c from " + AdmconsCurrencyCodes.class.getName() + " c";
			Query query = entitymanager.createQuery(sql, AdmconsCurrencyCodes.class);
			
			return (List<AdmconsCurrencyCodes>) query.getResultList();
		} catch (Exception e) {
			log.info("error: " + e);
			return null;
		}	
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<AdmconsFinancialEntities> obtenerInstituciones() {
		
		try {
			String sql = "Select f from " + AdmconsFinancialEntities.class.getName() + " f where financialEntStatus = '9'";
			Query query = entitymanager.createQuery(sql, AdmconsFinancialEntities.class);
			
			return (List<AdmconsFinancialEntities>) query.getResultList();
		} catch (Exception e) {
			log.info("error: " + e);
			return null;
		}	
	}

	@Override
	public List<String> obtenerInstitucionesByMember(String memberId) {
		try {
			String sql = "select afe.financial_ent_name from admcons_financial_entities afe\n" +
					"JOIN admcons_financial_attributes afa on afe.financial_ent_id=afa.financial_ent_id\n" +
					"where afa.is_member= :memberId  ORDER BY  afe.financial_ent_name ASC";
			Query query = entitymanager.createNativeQuery(sql);
			query.setParameter("memberId", memberId);

			return (List<String>) query.getResultList();
		} catch (Exception e) {
			log.info("error: " + e);
			return null;
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<AdmconsBrands> obtenerBrands() {
		
		try {
			
			String sql = "Select b from " + AdmconsBrands.class.getName() + " b";
			Query query = entitymanager.createQuery(sql, AdmconsBrands.class);
			
			return (List<AdmconsBrands>) query.getResultList();
		} catch (Exception e) {
			log.info("error: " + e);
			return null;
		}
		
		
	}

	@Override
	public List<Object[]> getMemberByFinancial(String financialId) {
		try {
			String sql = "select is_Member from admcons_financial_attributes WHERE financial_ent_id= :id ";
			Query query = this.entityManager.createNativeQuery(sql);
			query.setParameter("id",financialId);
			return (List<Object[]>) query.getResultList();
		} catch (Exception e) {
			log.info("error: " + e);
			return null;
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<AdmconsIssuers> obtenerEmisores() {
		
		try {
			
			String sql = "Select i from " + AdmconsIssuers.class.getName() + " i where issuerStatus = '9'";
			Query query = entitymanager.createQuery(sql, AdmconsIssuers.class);

			return (List<AdmconsIssuers>) query.getResultList();
			
		} catch (Exception e) {
			log.info("error: " + e);
			return null;
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<AdmconsProductTypes> obtenerTipoProducto() {
		
		try {
			
			String sql = "Select p from " + AdmconsProductTypes.class.getName() + " p";
			Query query = entitymanager.createQuery(sql, AdmconsProductTypes.class);
			
			return (List<AdmconsProductTypes>) query.getResultList();
			
		} catch (Exception e) {
			log.info("error: " + e);
			return null;
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> obtenerOperacionesAsociadas(String productId) {
		
		try {
			String sql = "SELECT o.operation_id, o.operation_name FROM ADMCONS_OPERATIONS o INNER JOIN ADMCONS_TRANS_LIMITS po ON o.operation_id = po.operation_id WHERE po.product_id = :productId";
			Query query = entitymanager.createNativeQuery(sql);
			query.setParameter("productId", productId);
			
			return (List<Object[]>) query.getResultList();
		} catch (Exception e) {
			log.info("error: " + e);
			return null;
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> obtenerOperacionesNoAsociadas(String productId) {
		
		try {
			String sql = "SELECT operation_id, operation_name FROM ADMCONS_OPERATIONS WHERE operation_id NOT IN (SELECT operation_id FROM ADMCONS_TRANS_LIMITS WHERE product_id = :productId) AND operation_status = '9'";
			Query query = entitymanager.createNativeQuery(sql);
			query.setParameter("productId", productId);
			
			return (List<Object[]>) query.getResultList();
		} catch (Exception e) {
			log.info("error: " + e);
			return null;
		}
	}

	@Override
	public void saveFinancialAtrributes(String financialId, String isMember) {
		log.info("FinancialID: " + financialId+" ,isMember: "+isMember);
		try {
			String sql = "UPDATE admcons_financial_attributes set IS_MEMBER= :isMember WHERE FINANCIAL_ENT_ID= :id ";
			Query query = entityManager.createNativeQuery(sql);
			query.setParameter("isMember", isMember);
			query.setParameter("id", financialId);
			query.executeUpdate();
		} catch (Exception e) {
			log.info("error: " + e);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<AdmconsOperations> obtenerOperaciones() {
		
		try {
			String sql = "Select OPERATION_ID, OPERATION_NAME from ADMCONS_OPERATIONS where operation_status = '9'";
			Query query = this.entityManager.createNativeQuery(sql);
			return (List<AdmconsOperations>) query.getResultList();
		} catch (Exception e) {
			log.info("error: " + e);
			return null;
		}	
	}
	
	
	/////////////////////////////////////////// 		TEMPORAL CODE FOR ONBOARDING. remove after get api endpoints of customer module
	
	
	public List<Object[]> getDocTypes() {
		log.info("getDocTypes");
		try {
			
			String sql = "SELECT document_type_id, name FROM document_type";
			Query query = entitymanager.createNativeQuery(sql);
			Gson gson = new Gson();
			List<Object[]> obj = (List<Object[]>) query.getResultList();
			
			return obj;
			
		} catch (Exception e) {
			
			log.info("error: " + e);
			return null;
		}
	}
	
	public List<Object[]> getCusStatus() {
		log.info("getCusStatus");
		try {
			
			String sql = "SELECT customer_status_id, name FROM customer_status where customer_status_id in('4','5')";
			Query query = entitymanager.createNativeQuery(sql);
			Gson gson = new Gson();
			List<Object[]> obj = (List<Object[]>) query.getResultList();
			
			return obj;
			
		} catch (Exception e) {
			
			log.info("error: " + e);
			return null;
		}
	}

}
