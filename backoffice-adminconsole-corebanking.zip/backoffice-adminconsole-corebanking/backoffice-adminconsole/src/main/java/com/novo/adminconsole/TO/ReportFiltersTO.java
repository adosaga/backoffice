/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.novo.adminconsole.TO;

/**
 *
 * @author frosales
 */
public class ReportFiltersTO 
{
    private String fecha = "";
    private String modulo = "";
    private String usuario = "";
    private String operacion = "";
    private String tagpay = "";
    private String emisor = "";
    private String status = "";
    private String nombre = "";
    private String apellido = "";

    public ReportFiltersTO(){
        modulo = "";
        usuario = "";
        operacion ="";
        tagpay="";
        emisor="";
        status="";
        nombre="";
        apellido="";
        fecha="";
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getModulo() {
        return modulo;
    }

    public void setModulo(String modulo) {
        this.modulo = modulo;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getOperacion() {
        return operacion;
    }

    public void setOperacion(String operacion) {
        this.operacion = operacion;
    }

    public String getTagpay() {
        return tagpay;
    }

    public void setTagpay(String tagpay) {
        this.tagpay = tagpay;
    }

    public String getEmisor() {
        return emisor;
    }

    public void setEmisor(String emisor) {
        this.emisor = emisor;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
}
