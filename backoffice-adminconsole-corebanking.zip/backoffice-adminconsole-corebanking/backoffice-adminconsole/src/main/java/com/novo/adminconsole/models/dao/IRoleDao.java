package com.novo.adminconsole.models.dao;

import java.util.List;


import com.novo.adminconsole.models.entity.Role;
import com.novo.adminconsole.models.entity.UserRole;



public interface IRoleDao {
	
	public String getRoleName(String userId);
	
	public List<Role> getRoleList();
	
	public Role getRole(String roleId);
	
	public String getRoleId(String userId);
	
	public UserRole findDisabledRole(String userId);
	
}
