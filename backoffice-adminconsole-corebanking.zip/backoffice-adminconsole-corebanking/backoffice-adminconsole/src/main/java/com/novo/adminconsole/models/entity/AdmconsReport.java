package com.novo.adminconsole.models.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "ADMCONS_REPORTS")
public class AdmconsReport implements Serializable{
 	
	private static final long serialVersionUID = 1L;
 	
	@Id
	@NotNull
	@Column(name = "REPORT_ID")
	private String reportId;
	
	@Column(name = "REPORT_TYPE_COD")
	private String reportTypeCod;
	
	@Column(name = "REPORT_TYPE_DESC")
	private String reportTypeDesc;
	
	@Column(name = "CREATED")
    @Temporal(TemporalType.TIMESTAMP)
	private Date created;
	
	@Column(name = "LAST_UPDATED")
    @Temporal(TemporalType.TIMESTAMP)
	private Date lastUpdated;
	
	@Column(name = "REPORT_NAME")
	private String reportName;
	
 	public String getReportId() {
		return reportId;
	}
 	
 	public void setReportId(String reportId) {
		this.reportId = reportId;
	}
 	
 	public String getReportTypeCod() {
		return reportTypeCod;
	}
 	
 	public void setReportTypeCod(String reportTypeCod) {
		this.reportTypeCod = reportTypeCod;
	}
 	
 	public String getReportTypeDesc() {
		return reportTypeDesc;
	}
 	
 	public void setReportTypeDesc(String reportTypeDesc) {
		this.reportTypeDesc = reportTypeDesc;
	}
 	
 	public Date getCreated() {
		return created;
	}
 	
 	public void setCreated(Date created) {
		this.created = created;
	}
 	
 	public Date getLastUpdated() {
		return lastUpdated;
	}
 	
 	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}
 	
 	public String getReportName() {
		return reportName;
	}
 	
 	public void setReportName(String reportName) {
		this.reportName = reportName;
	}
}

