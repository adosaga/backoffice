package com.novo.adminconsole.TO;

import org.springframework.stereotype.Component;

@Component
public class RefreshTokenTO {

	private String old_refresh;
	
	private String access_token;
	
	private String refresh_token;
	
	private String status_Id;
	
	private String application_id;

	private String grant_type_id;

	public String getOld_refresh() {
		return old_refresh;
	}

	public void setOld_refresh(String old_refresh) {
		this.old_refresh = old_refresh;
	}

	public String getAccess_token() {
		return access_token;
	}

	public void setAccess_token(String access_token) {
		this.access_token = access_token;
	}

	public String getRefresh_token() {
		return refresh_token;
	}

	public void setRefresh_token(String refresh_token) {
		this.refresh_token = refresh_token;
	}

	public String getStatus_Id() {
		return status_Id;
	}

	public void setStatus_Id(String status_Id) {
		this.status_Id = status_Id;
	}

	public String getApplication_id() {
		return application_id;
	}

	public void setApplication_id(String application_id) {
		this.application_id = application_id;
	}

	public String getGrant_type_id() {
		return grant_type_id;
	}

	public void setGrant_type_id(String grant_type_id) {
		this.grant_type_id = grant_type_id;
	}
	
}

