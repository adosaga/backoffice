package com.novo.adminconsole.models.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name="ADMCONS_DATA_FORMS")
public class AdmconsDataForms implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "DATA_FORM_ID")
    private String dataFormId;
	
    @Size(max = 200)
    @Column(name = "REJECTION_OBSERVATIONS")
    private String rejectionObservations;
    
    @Column(name = "CREATED")
    @Temporal(TemporalType.TIMESTAMP)
    private Date created;
    
    @Column(name = "LAST_UPDATED")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdated;
    
    @JoinColumn(name = "USER_CREATOR", referencedColumnName = "USER_ID")
    @ManyToOne
    private UserApp userCreator;
    
    @JoinColumn(name = "USER_APPROVED", referencedColumnName = "USER_ID")
    @ManyToOne
    private UserApp userApproved;
    
    @JoinColumn(name = "CUST_HOLDER", referencedColumnName = "CUSTOMER_ID")
    @ManyToOne
    private AdmconsTempCustomers custHolder;
    
    @JoinColumn(name = "CUST_AUTHORIZED_3", referencedColumnName = "CUSTOMER_ID")
    @ManyToOne
    private AdmconsTempCustomers custAuthorized3;
    
    @JoinColumn(name = "CUST_AUTHORIZED_2", referencedColumnName = "CUSTOMER_ID")
    @ManyToOne
    private AdmconsTempCustomers custAuthorized2;
    
    @JoinColumn(name = "CUST_AUTHORIZED_1", referencedColumnName = "CUSTOMER_ID")
    @ManyToOne
    private AdmconsTempCustomers custAuthorized1;
    
    @JoinColumn(name = "ACCOUNT_ID", referencedColumnName = "ACCOUNT_ID")
    @ManyToOne
    private AdmconsTempAccounts accountId;
    
    @JoinColumn(name = "DATA_FORM_STATUS", referencedColumnName = "STATUS_ID")
    @ManyToOne
    private AdmconsStatus dataFormStatus;
    
    @JoinColumn(name = "ISSUER_ID", referencedColumnName = "ISSUER_ID")
    @ManyToOne
    private AdmconsIssuers issuerId;
    
    @JoinColumn(name = "BRANCH_ID", referencedColumnName = "BRANCH_ID")
    @ManyToOne
    private AdmconsBranchOffices branchId;
    
    @JoinColumn(name = "ACCOUNT_TYPE", referencedColumnName = "ACCOUNT_TYPE_ID")
    @ManyToOne
    private AdmconsAccountTypes accountType;
	

}
