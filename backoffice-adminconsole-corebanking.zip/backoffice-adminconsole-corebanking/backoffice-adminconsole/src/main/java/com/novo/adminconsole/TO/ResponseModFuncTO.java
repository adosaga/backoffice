package com.novo.adminconsole.TO;

import java.util.List;

import com.novo.adminconsole.utils.RoleAssoc;

public class ResponseModFuncTO {

	private String rc;
	
	private String msg;
	
	private List<RoleAssoc> roleAssocList;
	
	private String dttimestamp;

	public String getRc() {
		return rc;
	}

	public void setRc(String rc) {
		this.rc = rc;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public List<RoleAssoc> getRoleAssocList() {
		return roleAssocList;
	}

	public void setRoleAssocList(List<RoleAssoc> roleAssocList) {
		this.roleAssocList = roleAssocList;
	}

	public String getDttimestamp() {
		return dttimestamp;
	}

	public void setDttimestamp(String dttimestamp) {
		this.dttimestamp = dttimestamp;
	}
}
