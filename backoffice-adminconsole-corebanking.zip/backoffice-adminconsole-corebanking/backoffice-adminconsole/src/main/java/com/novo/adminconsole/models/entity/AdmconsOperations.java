package com.novo.adminconsole.models.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "ADMCONS_OPERATIONS")
public class AdmconsOperations implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@NotNull
	@Column(name = "OPERATION_ID")
	private String operationId;
	
	@Column(name = "OPERATION_NAME")
	private String operationName;
	
	@Column(name = "OPERATION_DESCRIPTION")
	private String operationDescription;
	
	@JoinColumn(name = "CURRENCY_CODE", referencedColumnName = "ISO_NUM")
	@ManyToOne
	private AdmconsCurrencyCodes currencyCode;
	
	@JoinColumn(name = "OPERATION_STATUS", referencedColumnName = "STATUS_ID")
	@ManyToOne
	private AdmconsStatus operationStatus;

	public String getOperationId() {
		return operationId;
	}

	public void setOperationId(String operationId) {
		this.operationId = operationId;
	}

	public String getOperationName() {
		return operationName;
	}

	public void setOperationName(String operationName) {
		this.operationName = operationName;
	}

	public String getOperationDescription() {
		return operationDescription;
	}

	public void setOperationDescription(String operationDescription) {
		this.operationDescription = operationDescription;
	}

	public AdmconsCurrencyCodes getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(AdmconsCurrencyCodes currencyCode) {
		this.currencyCode = currencyCode;
	}

	public AdmconsStatus getOperationStatus() {
		return operationStatus;
	}

	public void setOperationStatus(AdmconsStatus operationStatus) {
		this.operationStatus = operationStatus;
	}
}
