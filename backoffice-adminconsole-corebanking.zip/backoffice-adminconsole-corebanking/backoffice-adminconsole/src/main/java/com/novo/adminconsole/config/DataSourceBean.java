package com.novo.adminconsole.config;


import static com.novo.adminconsole.utils.Constants.PROPERTIES_FILE;

import java.sql.SQLException;
import java.util.Properties;

import javax.naming.NamingException;
import javax.persistence.EntityManagerFactory;

import org.apache.tomcat.jdbc.pool.DataSource;
import org.apache.tomcat.jdbc.pool.PoolProperties;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.novo.adminconsole.utils.Utils;


@Configuration
@EnableTransactionManagement
public class DataSourceBean {

	private Properties properties = Utils.getConfig(PROPERTIES_FILE);

		@Bean(name="dataSource",destroyMethod="")
		public DataSource dataSource() throws NamingException, SQLException {
			  PoolProperties  p = new PoolProperties();
			  p.setUrl(properties.getProperty("oracle_url"));
	          p.setDriverClassName(properties.getProperty("oracle_driver"));
	          p.setUsername(properties.getProperty("oracle_username"));
	          p.setPassword(properties.getProperty("oracle_password"));
	          p.setJmxEnabled(true);
	          p.setTestWhileIdle(true);
	          p.setTestOnBorrow(true);
	          p.setValidationQuery("SELECT 1 FROM DUAL");
	          p.setTestOnReturn(false);
	          p.setValidationInterval(30000);
	          p.setTimeBetweenEvictionRunsMillis(5000);
	          p.setMaxActive(100);
	          p.setInitialSize(10);
	          p.setMaxWait(10000);
	          p.setRemoveAbandonedTimeout(60);
	          p.setMinEvictableIdleTimeMillis(60000);
	          p.setMaxIdle(5);
	          p.setMinIdle(1);
	          p.setLogAbandoned(true);
	          p.setRemoveAbandoned(true);
	          p.setJdbcInterceptors(
	                  "org.apache.tomcat.jdbc.pool.interceptor.ConnectionState;"
	                  + "org.apache.tomcat.jdbc.pool.interceptor.StatementFinalizer;"
	                  + "org.apache.tomcat.jdbc.pool.interceptor.ResetAbandonedTimer");
	           
	          DataSource datasource = new DataSource();
	          datasource.setPoolProperties(p);
	          return datasource;
		}

		@Bean(name="entityManagerFactory",destroyMethod="")
		public LocalContainerEntityManagerFactoryBean entityManagerFactory(EntityManagerFactoryBuilder builder, @Qualifier("dataSource") DataSource dataSource) {
			return builder.dataSource(dataSource).packages("com.novo.adminconsole.models.entity").persistenceUnit("xe").build();
		}
		
		@Bean(name="transactionManager",destroyMethod="")
		public PlatformTransactionManager transactionManager(@Qualifier("entityManagerFactory") EntityManagerFactory entityManagerFactory) {
			return new JpaTransactionManager(entityManagerFactory);
		}
	
}
