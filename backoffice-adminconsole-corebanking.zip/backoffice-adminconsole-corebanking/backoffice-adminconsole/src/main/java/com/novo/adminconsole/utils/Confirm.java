package com.novo.adminconsole.utils;

import org.hibernate.validator.constraints.NotEmpty;

public class Confirm {

	@NotEmpty(message = "La contraseña es requerida.")
	private String password;
	
	private String dataFormId;

	private String status;

	private String statusNew;

	public String getStatusNew() {
		return statusNew;
	}

	public void setStatusNew(String statusNew) {
		this.statusNew = statusNew;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getDataFormId() {
		return dataFormId;
	}

	public void setDataFormId(String dataFormId) {
		this.dataFormId = dataFormId;
	}

}
