package com.novo.adminconsole.models.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;


@Entity
@Table(name="ADMCONS_TEMP_CUSTOMERS")
public class AdmconsTempCustomers implements Serializable{

	private static final long serialVersionUID = 1L;
    
    @NotNull
    @Size(min = 1, max = 1)
    @Column(name = "LOAD_ACTION")
    private String loadAction;
    
    @Id
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "CUSTOMER_ID")
    private String customerId;
    
    @NotNull
    @Size(min = 1, max = 15)
    @Column(name = "NATIONAL_ID")
    private String nationalId;
    
    @Size(max = 10)
    @Column(name = "CUST_TITLE")
    private String custTitle;
    
    @Size(max = 100)
    @Column(name = "CUST_FIRSTNAME")
    private String custFirstname;
    
    @Size(max = 100)
    @Column(name = "CUST_MIDDLENAME")
    private String custMiddlename;
    
    @Size(max = 100)
    @Column(name = "CUST_LASTNAME")
    private String custLastname;
    
    @Size(max = 100)
    @Column(name = "CUST_SECONDSURNAME")
    private String custSecondsurname;
    
    @Size(max = 10)
    @Column(name = "CUST_INITIALS")
    private String custInitials;
    
    @Size(max = 100)
    @Column(name = "CUST_NAMEONCARD")
    private String custNameoncard;
    
    @Size(max = 4)
    @Column(name = "COUNTRY_PHONE_CODE")
    private String countryPhoneCode;
    
    @Size(max = 50)
    @Column(name = "TELEPHONE_NUMBER")
    private String telephoneNumber;
    
    @Size(max = 50)
    @Column(name = "MOBILE_NUMBER")
    private String mobileNumber;
    
    @Size(max = 50)
    @Column(name = "FAX_NUMBER")
    private String faxNumber;
    
    @Size(max = 200)
    @Column(name = "EMAIL_ADDRESS")
    private String emailAddress;
    
    @Size(max = 100)
    @Column(name = "POSTAL_ADDRESS1")
    private String postalAddress1;
    
    @Size(max = 100)
    @Column(name = "POSTAL_ADDRESS2")
    private String postalAddress2;
    
    @Size(max = 40)
    @Column(name = "POSTAL_CITY")
    private String postalCity;
    
    @Size(max = 20)
    @Column(name = "POSTAL_REGION")
    private String postalRegion;
    
    @Size(max = 20)
    @Column(name = "POSTAL_CODE")
    private String postalCode;
    
    @Size(max = 3)
    @Column(name = "POSTAL_COUNTRY")
    private String postalCountry;
    
    @Size(max = 100)
    @Column(name = "OTHER_ADDRESS1")
    private String otherAddress1;
    
    @Size(max = 100)
    @Column(name = "OTHER_ADDRESS2")
    private String otherAddress2;
    
    @Size(max = 40)
    @Column(name = "OTHER_CITY")
    private String otherCity;
    
    @Size(max = 20)
    @Column(name = "OTHER_REGION")
    private String otherRegion;
    
    @Size(max = 20)
    @Column(name = "OTHER_POSTAL_CODE")
    private String otherPostalCode;
    
    @Size(max = 8)
    @Column(name = "OTHER_COUNTRY")
    private String otherCountry;
    
    @Size(max = 26)
    @Column(name = "COMPANY_NAME")
    private String companyName;
    
    @NotNull
    @Size(min = 1, max = 1)
    @Column(name = "VIP")
    private String vip;
    
    @Size(max = 19)
    @Column(name = "VIP_LAPSE_DATE")
    private String vipLapseDate;
    
    @Size(max = 200)
    @Column(name = "EXTENDED_FIELDS")
    private String extendedFields;
    
    public String getLoadAction() {
        return loadAction;
    }

    public void setLoadAction(String loadAction) {
        this.loadAction = loadAction;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getNationalId() {
        return nationalId;
    }

    public void setNationalId(String nationalId) {
        this.nationalId = nationalId;
    }

    public String getCustTitle() {
        return custTitle;
    }

    public void setCustTitle(String custTitle) {
        this.custTitle = custTitle;
    }

    public String getCustFirstname() {
        return custFirstname;
    }

    public void setCustFirstname(String custFirstname) {
        this.custFirstname = custFirstname;
    }

    public String getCustMiddlename() {
        return custMiddlename;
    }

    public void setCustMiddlename(String custMiddlename) {
        this.custMiddlename = custMiddlename;
    }

    public String getCustLastname() {
        return custLastname;
    }

    public void setCustLastname(String custLastname) {
        this.custLastname = custLastname;
    }

    public String getCustSecondsurname() {
        return custSecondsurname;
    }

    public void setCustSecondsurname(String custSecondsurname) {
        this.custSecondsurname = custSecondsurname;
    }

    public String getCustInitials() {
        return custInitials;
    }

    public void setCustInitials(String custInitials) {
        this.custInitials = custInitials;
    }

    public String getCustNameoncard() {
        return custNameoncard;
    }

    public void setCustNameoncard(String custNameoncard) {
        this.custNameoncard = custNameoncard;
    }

    public String getCountryPhoneCode() {
        return countryPhoneCode;
    }

    public void setCountryPhoneCode(String countryPhoneCode) {
        this.countryPhoneCode = countryPhoneCode;
    }

    public String getTelephoneNumber() {
        return telephoneNumber;
    }

    public void setTelephoneNumber(String telephoneNumber) {
        this.telephoneNumber = telephoneNumber;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getFaxNumber() {
        return faxNumber;
    }

    public void setFaxNumber(String faxNumber) {
        this.faxNumber = faxNumber;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getPostalAddress1() {
        return postalAddress1;
    }

    public void setPostalAddress1(String postalAddress1) {
        this.postalAddress1 = postalAddress1;
    }

    public String getPostalAddress2() {
        return postalAddress2;
    }

    public void setPostalAddress2(String postalAddress2) {
        this.postalAddress2 = postalAddress2;
    }

    public String getPostalCity() {
        return postalCity;
    }

    public void setPostalCity(String postalCity) {
        this.postalCity = postalCity;
    }

    public String getPostalRegion() {
        return postalRegion;
    }

    public void setPostalRegion(String postalRegion) {
        this.postalRegion = postalRegion;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getPostalCountry() {
        return postalCountry;
    }

    public void setPostalCountry(String postalCountry) {
        this.postalCountry = postalCountry;
    }

    public String getOtherAddress1() {
        return otherAddress1;
    }

    public void setOtherAddress1(String otherAddress1) {
        this.otherAddress1 = otherAddress1;
    }

    public String getOtherAddress2() {
        return otherAddress2;
    }

    public void setOtherAddress2(String otherAddress2) {
        this.otherAddress2 = otherAddress2;
    }

    public String getOtherCity() {
        return otherCity;
    }

    public void setOtherCity(String otherCity) {
        this.otherCity = otherCity;
    }

    public String getOtherRegion() {
        return otherRegion;
    }

    public void setOtherRegion(String otherRegion) {
        this.otherRegion = otherRegion;
    }

    public String getOtherPostalCode() {
        return otherPostalCode;
    }

    public void setOtherPostalCode(String otherPostalCode) {
        this.otherPostalCode = otherPostalCode;
    }

    public String getOtherCountry() {
        return otherCountry;
    }

    public void setOtherCountry(String otherCountry) {
        this.otherCountry = otherCountry;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getVip() {
        return vip;
    }

    public void setVip(String vip) {
        this.vip = vip;
    }

    public String getVipLapseDate() {
        return vipLapseDate;
    }

    public void setVipLapseDate(String vipLapseDate) {
        this.vipLapseDate = vipLapseDate;
    }

    public String getExtendedFields() {
        return extendedFields;
    }

    public void setExtendedFields(String extendedFields) {
        this.extendedFields = extendedFields;
    }

}
