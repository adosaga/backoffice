package com.novo.adminconsole.utils;

public class Parameter {

	private String configId;
	
	private String configName;
	
	private String configValor;
	
	private String configTypeDesc;
	
	private String created;
	
	private String lastUpdated;
	
	private String configStatus;
	
	private String configType;
	
	private String issuerId;

	public String getConfigId() {
		return configId;
	}

	public void setConfigId(String configId) {
		this.configId = configId;
	}
	
	public String getConfigName() {
		return configName;
	}

	public void setConfigName(String configName) {
		this.configName = configName;
	}

	public String getConfigValor() {
		return configValor;
	}

	public void setConfigValor(String configValor) {
		this.configValor = configValor;
	}

	public String getConfigTypeDesc() {
		return configTypeDesc;
	}

	public void setConfigTypeDesc(String configTypeDesc) {
		this.configTypeDesc = configTypeDesc;
	}

	public String getCreated() {
		return created;
	}

	public void setCreated(String created) {
		this.created = created;
	}

	public String getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(String lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public String getConfigStatus() {
		return configStatus;
	}

	public void setConfigStatus(String configStatus) {
		this.configStatus = configStatus;
	}

	public String getConfigType() {
		return configType;
	}

	public void setConfigType(String configType) {
		this.configType = configType;
	}

	public String getIssuerId() {
		return issuerId;
	}

	public void setIssuerId(String issuerId) {
		this.issuerId = issuerId;
	}

}
