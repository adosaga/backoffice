package com.novo.adminconsole.models.entity;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;

@Entity
@Table(name = "ADMCONS_FINANCIAL_ATTRIBUTES")
public class AdmconsFinancialAttributes implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "FINANCIAL_ATTR_ID")
    private String financialAttrId;

    @Size(max = 3)
    @Column(name = "IS_MEMBER")
    private String isMember;

    @JoinColumn(name = "FINANCIAL_ENT_ID", referencedColumnName = "FINANCIAL_ENT_ID")
    @ManyToOne
    private AdmconsFinancialEntities admconsFinancialEntities;

    public String getFinancialAttrId() {
        return financialAttrId;
    }

    public void setFinancialAttrId(String financialAttrId) {
        this.financialAttrId = financialAttrId;
    }

    public String getIsMember() {
        return isMember;
    }

    public void setIsMember(String isMember) {
        this.isMember = isMember;
    }
}
