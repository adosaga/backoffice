package com.novo.adminconsole.TO;

import java.util.ArrayList;
import java.util.Map;


public class ResponseAccessTO {

	private String rc;
	
	private String msg;
	
	private Map<String,String> access;
	
	private ArrayList<Map<String,String>> accessList;
	
	private String dttimestamp;

	public String getRc() {
		return rc;
	}

	public void setRc(String rc) {
		this.rc = rc;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public Map<String, String> getAccess() {
		return access;
	}

	public void setAccess(Map<String, String> access) {
		this.access = access;
	}

	public ArrayList<Map<String, String>> getAccessList() {
		return accessList;
	}

	public void setAccessList(ArrayList<Map<String, String>> accessList) {
		this.accessList = accessList;
	}

	public String getDttimestamp() {
		return dttimestamp;
	}

	public void setDttimestamp(String dttimestamp) {
		this.dttimestamp = dttimestamp;
	}
}
