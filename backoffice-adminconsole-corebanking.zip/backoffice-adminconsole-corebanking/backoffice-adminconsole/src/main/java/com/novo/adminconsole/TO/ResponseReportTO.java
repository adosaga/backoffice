package com.novo.adminconsole.TO;

public class ResponseReportTO 
{
    private String bean;

    private String className;

    private String logAcceso;

    private String rc;

    private ReportTO report;

    public String getBean() {
            return bean;
    }

    public void setBean(String bean) {
            this.bean = bean;
    }

    public String getClassName() {
            return className;
    }

    public void setClassName(String className) {
            this.className = className;
    }

    public String getLogAcceso() {
            return logAcceso;
    }

    public void setLogAcceso(String logAcceso) {
            this.logAcceso = logAcceso;
    }

    public String getRc() {
            return rc;
    }

    public void setRc(String rc) {
            this.rc = rc;
    }

    public ReportTO getReport() {
        return report;
    }

    public void setReport(ReportTO report) {
        this.report = report;
    }

}
