package com.novo.adminconsole.models.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;


@Entity
@Table(name="ADMCONS_TEMP_ACCOUNTS")
public class AdmconsTempAccounts implements Serializable{

	private static final long serialVersionUID = 1L;
    
    @NotNull
    @Size(min = 1, max = 1)
    @Column(name = "LOAD_ACTION")
    private String loadAction;
    
	@Id
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "ACCOUNT_ID")
    private String accountId;
    
    @NotNull
    @Size(min = 1, max = 2)
    @Column(name = "ACCOUNT_TYPE")
    private String accountType;
    
    @NotNull
    @Size(min = 1, max = 3)
    @Column(name = "CURRENCY_CODE")
    private String currencyCode;
    
	@Size(max = 50)
    @Column(name = "ACCOUNT_PRODUCT")
    private String accountProduct;
    
	@Size(max = 200)
    @Column(name = "EXTENDED_FIELDS")
    private String extendedFields;
    
	@Size(max = 12)
    @Column(name = "OVERDRAFT_LIMIT")
    private String overdraftLimit;

	public String getLoadAction() {
		return loadAction;
	}

	public void setLoadAction(String loadAction) {
		this.loadAction = loadAction;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public String getAccountProduct() {
		return accountProduct;
	}

	public void setAccountProduct(String accountProduct) {
		this.accountProduct = accountProduct;
	}

	public String getExtendedFields() {
		return extendedFields;
	}

	public void setExtendedFields(String extendedFields) {
		this.extendedFields = extendedFields;
	}

	public String getOverdraftLimit() {
		return overdraftLimit;
	}

	public void setOverdraftLimit(String overdraftLimit) {
		this.overdraftLimit = overdraftLimit;
	}
	
}
